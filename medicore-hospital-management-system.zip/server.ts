import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const PORT = 3000;

// =========================================================================
// CLINICAL TRIAGE KNOWLEDGE ENGINE & FALLBACK ICD-10 MATRICES
// =========================================================================
interface TriageRequestPayload {
  patientName?: string;
  patientAge: number;
  patientGender: 'Male' | 'Female' | 'Other';
  chiefComplaint: string;
  symptomDuration: string;
  vitalSigns?: {
    bloodPressure?: string;
    heartRate?: number;
    spo2?: number;
    temperature?: number;
    respiratoryRate?: number;
    painLevel?: number;
  };
  knownAllergies?: string[];
  chronicConditions?: string[];
}

function calculateClinicalFallbackTriage(data: TriageRequestPayload) {
  const text = (data.chiefComplaint || '').toLowerCase();
  const vitals = data.vitalSigns || {};
  const age = data.patientAge || 45;
  const pain = vitals.painLevel || 0;
  const spo2 = vitals.spo2 || 98;
  const hr = vitals.heartRate || 75;
  const temp = vitals.temperature || 37.0;

  // Check critical red flags
  let acuityLevel: 'ESI_1_RESUSCITATION' | 'ESI_2_EMERGENT' | 'ESI_3_URGENT' | 'ESI_4_SEMI_URGENT' | 'ESI_5_NON_URGENT' = 'ESI_3_URGENT';
  let acuityTitle = 'Level 3 - Urgent (Requires multiple diagnostic resources / <30m)';
  const redFlags: string[] = [];
  const immediateProtocols: string[] = [];
  const diagnosticOrders: string[] = [];

  if (
    text.includes('unconscious') ||
    text.includes('cardiac arrest') ||
    text.includes('not breathing') ||
    (spo2 < 85 && text.includes('gasping'))
  ) {
    acuityLevel = 'ESI_1_RESUSCITATION';
    acuityTitle = 'Level 1 - Resuscitation (Immediate Life Threat / 0m STAT)';
    redFlags.push('Impending respiratory or hemodynamic collapse');
    immediateProtocols.push('Activate STAT Code Blue / Resuscitation Team');
    immediateProtocols.push('Bag-Valve-Mask oxygenation & High-flow FiO2');
    immediateProtocols.push('STAT bedside 12-lead ECG, Dual 18G IV access, Defibrillator on standby');
  } else if (
    text.includes('crushing chest pain') ||
    text.includes('radiating to left arm') ||
    text.includes('radiating to jaw') ||
    text.includes('slurred speech') ||
    text.includes('facial droop') ||
    text.includes('hemiparesis') ||
    text.includes('thunderclap headache') ||
    spo2 < 90 ||
    hr > 140 ||
    hr < 45 ||
    pain >= 9
  ) {
    acuityLevel = 'ESI_2_EMERGENT';
    acuityTitle = 'Level 2 - Emergent (High Risk / Confusion / Lethargy / Severe Pain / <15m)';
    if (text.includes('chest') || text.includes('angina')) {
      redFlags.push('Suspected Acute Coronary Syndrome (ACS / STEMI / NSTEMI)');
      immediateProtocols.push('STAT 12-Lead Electrocardiogram within 10 minutes of arrival');
      immediateProtocols.push('Administer Chewable Aspirin 324mg (unless contraindicated) + Sublingual Nitroglycerin');
      diagnosticOrders.push('STAT High-Sensitivity Cardiac Troponin I (0h / 2h serial)');
      diagnosticOrders.push('STAT 12-Lead Electrocardiogram (ECG)');
      diagnosticOrders.push('Serum Electrolytes, Renal Profile, and Lipid Panel');
    } else if (text.includes('slurred') || text.includes('facial') || text.includes('weakness')) {
      redFlags.push('Suspected Acute Ischemic Stroke / Cerebrovascular Accident (CVA)');
      immediateProtocols.push('Initiate FAST Stroke Protocol and calculate Last Known Well (LKW)');
      immediateProtocols.push('Emergency Non-Contrast Cranial Head CT within 20 minutes');
      diagnosticOrders.push('STAT Non-Contrast Brain CT / CT Angiography');
      diagnosticOrders.push('Point-of-Care Blood Glucose & Coagulation INR/PTT');
    }
  }

  // Department & ICD-10 matching matrix
  let recommendedDepartment = 'Cardiovascular & Internal Medicine';
  let secondaryDepartment = 'Emergency Medicine & Critical Care';
  let specialistName = 'Dr. Elena Vance, MD';
  let specialistRole = 'Cardiologist & Outpatient Specialist';
  let primaryIcd10 = {
    code: 'I20.9',
    name: 'Angina Pectoris, Unspecified',
    category: 'Diseases of the circulatory system (I00-I99)',
    confidenceScore: 0.93,
    clinicalRationale: 'Patient reports characteristic precordial discomfort, necessitating immediate exclusion of myocardial ischemia under ICD-10 guidelines.'
  };
  let secondaryIcd10List = [
    {
      code: 'I10',
      name: 'Essential (primary) hypertension',
      category: 'Hypertensive diseases (I10-I15)',
      confidenceScore: 0.88,
      clinicalRationale: 'Elevated systolic BP readings with secondary cardiovascular risk assessment indicated.'
    },
    {
      code: 'R07.9',
      name: 'Chest pain, unspecified',
      category: 'Symptoms, signs and abnormal clinical findings (R00-R99)',
      confidenceScore: 0.85,
      clinicalRationale: 'Symptom-level diagnostic coding pending serial troponin and ECG confirmation.'
    }
  ];

  let differentialDiagnoses = [
    { condition: 'Acute Coronary Syndrome / Angina Pectoris', icd10: 'I20.0', probability: 0.72, rationale: 'Substernal pressure and clinical presentation.' },
    { condition: 'Gastroesophageal Reflux Disease with Esophageal Spasm', icd10: 'K21.9', probability: 0.18, rationale: 'Potential non-cardiac etiology if postprandial.' },
    { condition: 'Costochondritis / Musculoskeletal Chest Wall Strain', icd10: 'M94.0', probability: 0.10, rationale: 'Palpable chest wall tenderness considerations.' }
  ];

  // Pulmonology / Respiratory
  if (text.includes('cough') || text.includes('breath') || text.includes('wheez') || text.includes('asthma') || text.includes('pneumonia') || text.includes('sputum') || text.includes('dyspnea')) {
    recommendedDepartment = 'Pulmonology & Respiratory Medicine';
    secondaryDepartment = 'Internal Medicine';
    specialistName = 'Dr. Evelyn Reed, MD';
    specialistRole = 'Lead Pulmonologist & Critical Care Specialist';
    primaryIcd10 = {
      code: 'J44.1',
      name: 'Chronic Obstructive Pulmonary Disease with (acute) exacerbation',
      category: 'Chronic lower respiratory diseases (J40-J47)',
      confidenceScore: 0.95,
      clinicalRationale: 'Progressive exertional dyspnea with cough and wheezing matches ICD-10 respiratory classification.'
    };
    secondaryIcd10List = [
      { code: 'J45.901', name: 'Unspecified asthma with (acute) exacerbation', category: 'Asthma (J45)', confidenceScore: 0.89, clinicalRationale: 'Reversible bronchospasm with wheezing on auscultation.' },
      { code: 'J18.9', name: 'Pneumonia, unspecified organism', category: 'Influenza and pneumonia (J09-J18)', confidenceScore: 0.82, clinicalRationale: 'Fever with productive purulent sputum.' }
    ];
    differentialDiagnoses = [
      { condition: 'Acute Bronchospastic Exacerbation', icd10: 'J45.901', probability: 0.65, rationale: 'Wheezing and responsive to bronchodilators.' },
      { condition: 'Community-Acquired Bacterial Pneumonia', icd10: 'J18.9', probability: 0.25, rationale: 'Fever and focal consolidation suspected.' },
      { condition: 'Acute Bronchitis', icd10: 'J20.9', probability: 0.10, rationale: 'Viral etiology in non-hypoxic patients.' }
    ];
    if (diagnosticOrders.length === 0) {
      diagnosticOrders.push('Chest Radiography (PA & Lateral Views)');
      diagnosticOrders.push('Complete Blood Count (CBC) with Differential');
      diagnosticOrders.push('Peak Expiratory Flow Rate (PEFR) / Spirometry');
      diagnosticOrders.push('Serum C-Reactive Protein (hs-CRP)');
    }
  }

  // Neurology
  else if (text.includes('headache') || text.includes('migraine') || text.includes('dizz') || text.includes('vertigo') || text.includes('seizure') || text.includes('numb') || text.includes('tingl') || text.includes('speech')) {
    recommendedDepartment = 'Neurology & Neurosciences';
    secondaryDepartment = 'Internal Medicine';
    specialistName = 'Dr. Aris Sterling, MD';
    specialistRole = 'Senior Neurologist';
    primaryIcd10 = {
      code: 'G43.909',
      name: 'Migraine, unspecified, not intractable, without status migrainosus',
      category: 'Episodic and paroxysmal disorders (G40-G47)',
      confidenceScore: 0.92,
      clinicalRationale: 'Unilateral pulsating headache with photophobia/nausea aligns with ICD-10 diagnostic criteria.'
    };
    secondaryIcd10List = [
      { code: 'R42', name: 'Dizziness and giddiness (Benign Paroxysmal Vertigo)', category: 'Symptoms and signs (R00-R99)', confidenceScore: 0.86, clinicalRationale: 'Vestibular imbalance and positional nystagmus.' },
      { code: 'G40.909', name: 'Epilepsy, unspecified, not intractable', category: 'Episodic disorders (G40)', confidenceScore: 0.79, clinicalRationale: 'Paroxysmal electrical cerebral activity history.' }
    ];
    differentialDiagnoses = [
      { condition: 'Classic Migraine with Aura', icd10: 'G43.109', probability: 0.60, rationale: 'Visual scotoma and hemicranial throbbing.' },
      { condition: 'Tension-Type Cephalea', icd10: 'G44.209', probability: 0.25, rationale: 'Band-like non-pulsatile bilateral pressure.' },
      { condition: 'Secondary Headache / Intracranial Pathology', icd10: 'R51.9', probability: 0.15, rationale: 'Requires red-flag screening (SNOOP criteria).' }
    ];
    if (diagnosticOrders.length === 0) {
      diagnosticOrders.push('Comprehensive Cranial Nerve Neurological Exam');
      diagnosticOrders.push('Brain MRI / Non-Contrast CT if refractory or atypical');
      diagnosticOrders.push('Serum Basic Metabolic Panel & Magnesium');
    }
  }

  // Endocrinology / Diabetes
  else if (text.includes('diabet') || text.includes('sugar') || text.includes('glucose') || text.includes('thirst') || text.includes('thyroid') || text.includes('fatigue') || text.includes('weight loss')) {
    recommendedDepartment = 'Endocrinology & Metabolic Disorders';
    secondaryDepartment = 'Internal Medicine';
    specialistName = 'Dr. Sarah Lin, MD';
    specialistRole = 'Endocrinologist & Diabetologist';
    primaryIcd10 = {
      code: 'E11.65',
      name: 'Type 2 diabetes mellitus with hyperglycemia',
      category: 'Diabetes mellitus (E08-E13)',
      confidenceScore: 0.96,
      clinicalRationale: 'Metabolic deregulation with elevated fasting glucose and polyuria meets ICD-10 endocrine classification.'
    };
    secondaryIcd10List = [
      { code: 'E03.9', name: 'Hypothyroidism, unspecified', category: 'Thyroid disorders (E00-E07)', confidenceScore: 0.84, clinicalRationale: 'Cold intolerance, fatigue, and bradycardia signs.' },
      { code: 'E66.01', name: 'Morbid (severe) obesity due to excess calories', category: 'Overweight and obesity (E66)', confidenceScore: 0.78, clinicalRationale: 'BMI > 35 with metabolic co-morbidities.' }
    ];
    differentialDiagnoses = [
      { condition: 'Type 2 Diabetes Mellitus - Uncontrolled', icd10: 'E11.65', probability: 0.75, rationale: 'Polyuria, polydipsia, and elevated blood glucose.' },
      { condition: 'Diabetic Ketoacidosis / HHS Risk', icd10: 'E11.10', probability: 0.15, rationale: 'Ketonuria and metabolic acidosis evaluation needed.' },
      { condition: 'Primary Hypothyroidism', icd10: 'E03.9', probability: 0.10, rationale: 'Generalized lethargy and sluggish metabolism.' }
    ];
    if (diagnosticOrders.length === 0) {
      diagnosticOrders.push('Point-of-Care Blood Glucose & Serum HbA1c');
      diagnosticOrders.push('Urinalysis for Microalbuminuria & Ketones');
      diagnosticOrders.push('Comprehensive Metabolic Panel (CMP) + Lipid Profile');
    }
  }

  // Orthopedics / Musculoskeletal
  else if (text.includes('knee') || text.includes('back') || text.includes('fracture') || text.includes('joint') || text.includes('bone') || text.includes('sprain') || text.includes('fall') || text.includes('shoulder')) {
    recommendedDepartment = 'Orthopedic Surgery & Sports Medicine';
    secondaryDepartment = 'Physical Medicine & Rehabilitation';
    specialistName = 'Dr. Arthur Sterling, MD';
    specialistRole = 'Orthopedic Surgeon';
    primaryIcd10 = {
      code: 'M17.11',
      name: 'Unilateral primary osteoarthritis, right knee',
      category: 'Arthropathies (M00-M25)',
      confidenceScore: 0.94,
      clinicalRationale: 'Weight-bearing articular pain with crepitus adheres to ICD-10 musculoskeletal taxonomy.'
    };
    secondaryIcd10List = [
      { code: 'M54.50', name: 'Low back pain, unspecified', category: 'Dorsopathies (M40-M54)', confidenceScore: 0.91, clinicalRationale: 'Lumbosacral mechanical tenderness without cauda equina red flags.' },
      { code: 'S83.511A', name: 'Sprain of anterior cruciate ligament of right knee, initial encounter', category: 'Injuries (S00-T88)', confidenceScore: 0.83, clinicalRationale: 'Acute rotational sports injury with effusion.' }
    ];
    differentialDiagnoses = [
      { condition: 'Degenerative Joint Osteoarthritis', icd10: 'M17.9', probability: 0.70, rationale: 'Chronic mechanical stiffness and joint space narrowing.' },
      { condition: 'Internal Derangement / Meniscal Tear', icd10: 'M23.20', probability: 0.20, rationale: 'Joint line tenderness and locking sensation.' },
      { condition: 'Gouty Arthritis / Crystal Arthropathy', icd10: 'M10.9', probability: 0.10, rationale: 'Erythematous periarticular swelling with hyperuricemia.' }
    ];
    if (diagnosticOrders.length === 0) {
      diagnosticOrders.push('Weight-Bearing Plain Film Radiography (X-Ray)');
      diagnosticOrders.push('Serum Uric Acid & ESR / CRP');
      diagnosticOrders.push('Targeted Musculoskeletal Physical Assessment (Lachman / McMurray)');
    }
  }

  // Gastroenterology
  else if (text.includes('abdomin') || text.includes('stomach') || text.includes('nausea') || text.includes('vomit') || text.includes('diarrhea') || text.includes('bowel') || text.includes('bleed') || text.includes('constipat')) {
    recommendedDepartment = 'Gastroenterology & Digestive Health';
    secondaryDepartment = 'General Surgery';
    specialistName = 'Dr. Sarah Lin, MD';
    specialistRole = 'Gastroenterologist';
    primaryIcd10 = {
      code: 'K21.9',
      name: 'Gastro-esophageal reflux disease without esophagitis',
      category: 'Diseases of the digestive system (K00-K95)',
      confidenceScore: 0.93,
      clinicalRationale: 'Postprandial epigastric burning and acid regurgitation ICD-10 categorization.'
    };
    secondaryIcd10List = [
      { code: 'K58.0', name: 'Irritable bowel syndrome with diarrhea', category: 'Functional gastrointestinal disorders (K58)', confidenceScore: 0.87, clinicalRationale: 'Cramping relieved by defecation with altered stool consistency.' },
      { code: 'K29.70', name: 'Gastritis, unspecified, without bleeding', category: 'Gastritis and duodenitis (K29)', confidenceScore: 0.81, clinicalRationale: 'Dyspepsia and epigastric discomfort.' }
    ];
    differentialDiagnoses = [
      { condition: 'Gastroesophageal Reflux Disease (GERD)', icd10: 'K21.9', probability: 0.65, rationale: 'Typical heartburn and responsive to PPI therapy.' },
      { condition: 'Peptic Ulcer Disease / Gastritis', icd10: 'K27.9', probability: 0.25, rationale: 'Fasting epigastric gnawing pain.' },
      { condition: 'Biliary Colic / Cholelithiasis', icd10: 'K80.20', probability: 0.10, rationale: 'Right upper quadrant postprandial pain.' }
    ];
    if (diagnosticOrders.length === 0) {
      diagnosticOrders.push('Complete Blood Count (CBC) & Liver Function Tests (LFTs)');
      diagnosticOrders.push('H. Pylori Stool Antigen / Breath Test');
      diagnosticOrders.push('Abdominal Ultrasound for Gallbladder / Pancreas');
    }
  }

  // General fallback
  if (diagnosticOrders.length === 0) {
    diagnosticOrders.push('Vital Signs Re-assessment & Core Temp');
    diagnosticOrders.push('Complete Blood Count (CBC) with Diff');
    diagnosticOrders.push('Basic Metabolic Panel (BMP)');
  }

  return {
    id: `trg-${Date.now()}`,
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    patientName: data.patientName || 'Outpatient Registration',
    patientAge: age,
    patientGender: data.patientGender || 'Male',
    chiefComplaint: data.chiefComplaint,
    symptomDuration: data.symptomDuration || 'Acute (<24 hours)',
    vitalSigns: vitals,
    knownAllergies: data.knownAllergies || [],
    chronicConditions: data.chronicConditions || [],
    acuityLevel,
    acuityTitle,
    recommendedDepartment,
    secondaryDepartment,
    recommendedSpecialistName: specialistName,
    recommendedSpecialistRole: specialistRole,
    primaryIcd10,
    secondaryIcd10List,
    differentialDiagnoses,
    redFlags: redFlags.length > 0 ? redFlags : ['No immediate life-threatening instability detected on initial intake vitals.'],
    immediateActionProtocols: immediateProtocols.length > 0 ? immediateProtocols : [
      'Standard outpatient intake verification',
      'Confirm photo identification & health insurance card',
      'Escort to designated specialty clinic consultation room'
    ],
    suggestedDiagnosticOrders: diagnosticOrders,
    clinicalSummary: `Patient presented with ${data.chiefComplaint || 'unspecified complaints'}. Based on presenting clinical symptoms, age (${age}), and vital parameters, patient is prioritized under ${acuityTitle}. Recommended referral to ${recommendedDepartment} under ICD-10 diagnostic category: ${primaryIcd10.code} (${primaryIcd10.name}).`,
    guidelineReference: 'WHO International Statistical Classification of Diseases and Related Health Problems (ICD-10 2026 Edition) & Emergency Severity Index (ESI v4 Implementation Guide)',
    appliedToRegistration: false
  };
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // -----------------------------------------------------------------------
  // HEALTH CHECK
  // -----------------------------------------------------------------------
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'MediCore Enterprise Clinical Backend',
      timestamp: new Date().toISOString(),
      hasGeminiApiKey: Boolean(process.env.GEMINI_API_KEY)
    });
  });

  // -----------------------------------------------------------------------
  // AI-POWERED CLINICAL TRIAGE ASSISTANT (ICD-10 & SPECIALIST DEPARTMENT)
  // -----------------------------------------------------------------------
  app.post('/api/triage/analyze', async (req, res) => {
    try {
      const payload: TriageRequestPayload = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!payload.chiefComplaint || payload.chiefComplaint.trim().length === 0) {
        return res.status(400).json({ error: 'Chief complaint and symptoms are required for clinical triage.' });
      }

      // If Gemini API key is configured, use Gemini 3.7 Flash with structured schema
      if (apiKey && apiKey.trim().length > 0) {
        try {
          const ai = new GoogleGenAI({
            apiKey: apiKey,
            httpOptions: {
              headers: {
                'User-Agent': 'aistudio-build'
              }
            }
          });

          const prompt = `You are the Lead Medical Triage Officer and Clinical Coding Expert at MediCore General Hospital.
Analyze the following outpatient registration symptoms according to the World Health Organization (WHO) ICD-10 Clinical Coding Guidelines and the Emergency Severity Index (ESI v4).

PATIENT REGISTRATION DETAILS:
- Name: ${payload.patientName || 'Anonymous Outpatient'}
- Age: ${payload.patientAge} years old
- Gender: ${payload.patientGender}
- Chief Complaint & Symptoms: "${payload.chiefComplaint}"
- Symptom Duration: "${payload.symptomDuration || 'Not specified'}"
- Vital Signs:
  * Blood Pressure: ${payload.vitalSigns?.bloodPressure || '120/80 mmHg'}
  * Heart Rate: ${payload.vitalSigns?.heartRate || 75} bpm
  * SpO2: ${payload.vitalSigns?.spo2 || 98}%
  * Temperature: ${payload.vitalSigns?.temperature || 37.0}°C
  * Respiratory Rate: ${payload.vitalSigns?.respiratoryRate || 16} breaths/min
  * Pain Level (0-10): ${payload.vitalSigns?.painLevel ?? 'None reported'}
- Known Allergies: ${payload.knownAllergies?.join(', ') || 'NKDA (No Known Drug Allergies)'}
- Chronic Medical History: ${payload.chronicConditions?.join(', ') || 'None reported'}

AVAILABLE HOSPITAL SPECIALTY DEPARTMENTS & PHYSICIANS AT MEDICORE:
1. Cardiovascular & Internal Medicine (Dr. Elena Vance, MD - Cardiologist & Internist)
2. Pulmonology & Respiratory Medicine (Dr. Evelyn Reed, MD - Pulmonologist)
3. Neurology & Neurosciences (Dr. Aris Sterling, MD - Neurologist)
4. Endocrinology & Metabolic Disorders (Dr. Sarah Lin, MD - Endocrinologist)
5. Orthopedic Surgery & Sports Medicine (Dr. Arthur Sterling, MD - Orthopedic Surgeon)
6. Gastroenterology & Digestive Health (Dr. Sarah Lin, MD - Gastroenterologist)
7. Emergency Medicine & Critical Care (Dr. Elena Vance, MD / Critical Care Team)
8. Dermatology & Allergy Immunology (Dr. Evelyn Reed, MD)
9. Nephrology & Renal Care (Dr. Sarah Lin, MD)
10. Ophthalmology & ENT (Dr. Arthur Sterling, MD)

Provide an exhaustive clinical triage recommendation with:
- Exact ESI Acuity Level (ESI_1_RESUSCITATION, ESI_2_EMERGENT, ESI_3_URGENT, ESI_4_SEMI_URGENT, ESI_5_NON_URGENT)
- Primary Recommended Department & Specialist Doctor
- Primary ICD-10 Code & Diagnostic Name with confidence score (0.0 to 1.0) and clinical justification
- Top 2-3 secondary ICD-10 codes
- Top 3 Differential Diagnoses with probabilities and rationale
- Red flag warnings / Emergency precautions
- Suggested initial diagnostic lab tests and imaging orders
- Clinical summary paragraph and ICD-10 guideline citations.`;

          const response = await ai.models.generateContent({
            model: 'gemini-3.7-flash',
            contents: prompt,
            config: {
              systemInstruction: 'You are an enterprise hospital clinical decision support system. Return accurate ICD-10-CM codes and ESI triage recommendations in strictly valid JSON format.',
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  acuityLevel: {
                    type: Type.STRING,
                    description: 'ESI_1_RESUSCITATION, ESI_2_EMERGENT, ESI_3_URGENT, ESI_4_SEMI_URGENT, or ESI_5_NON_URGENT'
                  },
                  acuityTitle: {
                    type: Type.STRING,
                    description: 'Formatted title e.g. "Level 2 - Emergent (High Risk / <15m)"'
                  },
                  recommendedDepartment: {
                    type: Type.STRING,
                    description: 'The specific MediCore hospital department'
                  },
                  secondaryDepartment: {
                    type: Type.STRING,
                    description: 'Alternative department if co-morbidities exist'
                  },
                  recommendedSpecialistName: {
                    type: Type.STRING,
                    description: 'Name of the attending physician'
                  },
                  recommendedSpecialistRole: {
                    type: Type.STRING,
                    description: 'Physician title and sub-specialty'
                  },
                  primaryIcd10: {
                    type: Type.OBJECT,
                    properties: {
                      code: { type: Type.STRING },
                      name: { type: Type.STRING },
                      category: { type: Type.STRING },
                      confidenceScore: { type: Type.NUMBER },
                      clinicalRationale: { type: Type.STRING }
                    },
                    required: ['code', 'name', 'category', 'confidenceScore', 'clinicalRationale']
                  },
                  secondaryIcd10List: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        code: { type: Type.STRING },
                        name: { type: Type.STRING },
                        category: { type: Type.STRING },
                        confidenceScore: { type: Type.NUMBER },
                        clinicalRationale: { type: Type.STRING }
                      },
                      required: ['code', 'name', 'category', 'confidenceScore', 'clinicalRationale']
                    }
                  },
                  differentialDiagnoses: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        condition: { type: Type.STRING },
                        icd10: { type: Type.STRING },
                        probability: { type: Type.NUMBER },
                        rationale: { type: Type.STRING }
                      },
                      required: ['condition', 'icd10', 'probability', 'rationale']
                    }
                  },
                  redFlags: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  immediateActionProtocols: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  suggestedDiagnosticOrders: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  clinicalSummary: {
                    type: Type.STRING
                  },
                  guidelineReference: {
                    type: Type.STRING
                  }
                },
                required: [
                  'acuityLevel',
                  'acuityTitle',
                  'recommendedDepartment',
                  'primaryIcd10',
                  'secondaryIcd10List',
                  'differentialDiagnoses',
                  'redFlags',
                  'immediateActionProtocols',
                  'suggestedDiagnosticOrders',
                  'clinicalSummary',
                  'guidelineReference'
                ]
              }
            }
          });

          const rawText = response.text;
          if (rawText) {
            const parsed = JSON.parse(rawText);
            const fullTriageResult = {
              id: `trg-ai-${Date.now()}`,
              timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
              patientName: payload.patientName || 'Walk-in Registration',
              patientAge: payload.patientAge,
              patientGender: payload.patientGender,
              chiefComplaint: payload.chiefComplaint,
              symptomDuration: payload.symptomDuration || 'Recent',
              vitalSigns: payload.vitalSigns,
              knownAllergies: payload.knownAllergies || [],
              chronicConditions: payload.chronicConditions || [],
              ...parsed,
              isAiGenerated: true
            };
            return res.json(fullTriageResult);
          }
        } catch (geminiError) {
          console.warn('[Gemini Triage Error - Fallback triggered]:', geminiError);
          // Seamlessly proceed to clinical fallback engine
        }
      }

      // Fallback Engine
      const fallbackResult = calculateClinicalFallbackTriage(payload);
      return res.json(fallbackResult);
    } catch (err: any) {
      console.error('[Triage Handler Exception]:', err);
      res.status(500).json({
        error: 'Failed to complete clinical triage analysis.',
        details: err?.message || String(err)
      });
    }
  });

  // -----------------------------------------------------------------------
  // VITE DEV SERVER / STATIC ASSET SERVING
  // -----------------------------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MediCore Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
