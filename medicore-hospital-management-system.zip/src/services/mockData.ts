import { 
  Patient, 
  Ward, 
  Appointment, 
  BillingInvoice, 
  StaffAlert, 
  MedicationAdherenceReminder, 
  ChatMessage, 
  HipaaAuditLog, 
  User, 
  CloudBackupSnapshot,
  LabTestDefinition,
  LabOrder,
  PharmacyPrescription,
  MedicationAdministrationRecord,
  PatientCareJourney,
  TriageAssessment
} from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'usr-admin-1',
    name: 'Dr. Arthur Sterling',
    email: 'admin.sterling@medicore.health',
    role: 'ADMIN',
    avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80',
    department: 'Hospital Administration & Governance',
    licenseNumber: 'MD-MED-889104',
    mfaEnabled: true,
    mfaVerified: true,
  },
  {
    id: 'usr-doc-1',
    name: 'Dr. Elena Vance, MD',
    email: 'e.vance@medicore.health',
    role: 'PHYSICIAN',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&auto=format&fit=crop&q=80',
    department: 'Cardiovascular & Internal Medicine',
    licenseNumber: 'MD-CARD-44219',
    mfaEnabled: true,
    mfaVerified: true,
  },
  {
    id: 'usr-nurse-1',
    name: 'Nurse Marcus Holloway, RN',
    email: 'm.holloway@medicore.health',
    role: 'NURSE',
    avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
    department: 'Critical Care & ICU Ward',
    licenseNumber: 'RN-ICU-99201',
    mfaEnabled: true,
    mfaVerified: true,
  },
  {
    id: 'usr-recep-1',
    name: 'Chloe Rodriguez',
    email: 'c.rodriguez@medicore.health',
    role: 'RECEPTIONIST',
    avatar: 'https://images.unsplash.com/photo-1594824813596-f9479bbf8a5e?w=150&auto=format&fit=crop&q=80',
    department: 'Central Patient Reception & Triage Intake',
    licenseNumber: 'REC-ADM-40192',
    mfaEnabled: true,
    mfaVerified: true,
  },
  {
    id: 'usr-lab-1',
    name: 'David Okafor, MLS',
    email: 'd.okafor@medicore.health',
    role: 'LAB_TECHNICIAN',
    avatar: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&auto=format&fit=crop&q=80',
    department: 'Department of Pathology & Clinical Diagnostics',
    licenseNumber: 'MLS-ASCP-77402',
    mfaEnabled: true,
    mfaVerified: true,
  },
  {
    id: 'usr-pharm-1',
    name: 'PharmD. Maya Lin',
    email: 'm.lin@medicore.health',
    role: 'PHARMACIST',
    avatar: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=150&auto=format&fit=crop&q=80',
    department: 'Central Clinical Pharmacy & Dispensing',
    licenseNumber: 'RPH-PHARM-31908',
    mfaEnabled: true,
    mfaVerified: true,
  },
  {
    id: 'usr-bill-1',
    name: 'Sarah Chen, CPC',
    email: 's.chen@medicore.health',
    role: 'BILLING',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    department: 'Revenue Cycle & Health Plans',
    licenseNumber: 'CPC-HIM-10294',
    mfaEnabled: true,
    mfaVerified: true,
  },
  {
    id: 'usr-patient-1',
    name: 'Eleanor Roosevelt-Bennett',
    email: 'eleanor.bennett@gmail.com',
    role: 'PATIENT',
    avatar: 'https://images.unsplash.com/photo-1581579438747-1dc8d17bbce4?w=150&auto=format&fit=crop&q=80',
    department: 'Cardiology Outpatient',
    mfaEnabled: true,
    mfaVerified: true,
  }
];

export const INITIAL_PATIENTS: Patient[] = [
  {
    id: 'pat-101',
    mrn: 'MC-2026-88910',
    name: 'Eleanor Roosevelt-Bennett',
    dob: '1952-04-12',
    age: 74,
    gender: 'Female',
    bloodType: 'A+',
    phone: '+1 (555) 382-9011',
    email: 'eleanor.bennett@gmail.com',
    address: '4582 Oakridge Meadows Blvd, Suite 4B, Boston, MA 02115',
    emergencyContact: {
      name: 'James Bennett (Son)',
      relationship: 'Primary Caregiver / Son',
      phone: '+1 (555) 382-9019',
    },
    insurance: {
      provider: 'Medicare Advantage Platinum Plus',
      policyNumber: 'MED-99401284-B',
      groupNumber: 'GRP-BOS-771',
      coveragePercentage: 85,
      copayAmount: 25,
      deductibleMet: true,
    },
    allergies: [
      { id: 'alg-1', allergen: 'Penicillin', reaction: 'Anaphylaxis, Urticaria', severity: 'LIFE_THREATENING' },
      { id: 'alg-2', allergen: 'Sulfa Drugs', reaction: 'Skin rash, fever', severity: 'MODERATE' },
      { id: 'alg-3', allergen: 'Contrast Dye (Iodine)', reaction: 'Bronchospasm', severity: 'SEVERE' }
    ],
    chronicConditions: [
      'Hypertensive Heart Disease (I11.9)',
      'Type 2 Diabetes Mellitus with Neuropathy (E11.40)',
      'Osteoarthritis of Both Knees (M17.0)'
    ],
    vitals: [
      {
        id: 'vit-1',
        bloodPressure: '128/82',
        heartRate: 72,
        temperature: 36.8,
        spo2: 98,
        respiratoryRate: 16,
        heightCm: 162,
        weightKg: 68.5,
        bmi: 26.1,
        recordedAt: '2026-08-31 08:15',
        recordedBy: 'Nurse Marcus Holloway, RN'
      },
      {
        id: 'vit-2',
        bloodPressure: '136/88',
        heartRate: 78,
        temperature: 37.0,
        spo2: 97,
        respiratoryRate: 18,
        heightCm: 162,
        weightKg: 69.1,
        bmi: 26.3,
        recordedAt: '2026-08-29 14:30',
        recordedBy: 'Nurse Chloe Ramirez, RN'
      }
    ],
    medications: [
      {
        id: 'med-1',
        name: 'Lisinopril',
        dosage: '20 mg',
        frequency: 'Once Daily (Morning with Food)',
        route: 'Oral',
        startDate: '2025-01-10',
        prescribingDoctor: 'Dr. Elena Vance, MD',
        active: true,
        instructions: 'Take in morning with full glass of water. Monitor blood pressure weekly.'
      },
      {
        id: 'med-2',
        name: 'Metformin Extended Release',
        dosage: '1000 mg',
        frequency: 'Twice Daily (Morning & Evening with meals)',
        route: 'Oral',
        startDate: '2024-06-15',
        prescribingDoctor: 'Dr. Elena Vance, MD',
        active: true,
        instructions: 'Do not crush or chew. Take with evening dinner.'
      },
      {
        id: 'med-3',
        name: 'Atorvastatin',
        dosage: '40 mg',
        frequency: 'Nightly at Bedtime',
        route: 'Oral',
        startDate: '2024-11-20',
        prescribingDoctor: 'Dr. Elena Vance, MD',
        active: true,
        instructions: 'Take at bedtime. Report any muscle pain immediately.'
      }
    ],
    labResults: [
      {
        id: 'lab-1',
        testName: 'Hemoglobin A1c (HbA1c)',
        category: 'Biochemistry',
        date: '2026-08-25',
        resultValue: '6.4',
        unit: '%',
        referenceRange: '4.0 - 5.6',
        status: 'ABNORMAL',
        orderingDoctor: 'Dr. Elena Vance, MD',
        notes: 'Target under 7.0 achieved. Glycemic control is improving.'
      },
      {
        id: 'lab-2',
        testName: 'Lipid Panel - LDL Cholesterol',
        category: 'Biochemistry',
        date: '2026-08-25',
        resultValue: '88',
        unit: 'mg/dL',
        referenceRange: '< 100',
        status: 'NORMAL',
        orderingDoctor: 'Dr. Elena Vance, MD'
      },
      {
        id: 'lab-3',
        testName: 'Comprehensive Metabolic Panel (eGFR)',
        category: 'Biochemistry',
        date: '2026-08-25',
        resultValue: '78',
        unit: 'mL/min/1.73m²',
        referenceRange: '> 60',
        status: 'NORMAL',
        orderingDoctor: 'Dr. Elena Vance, MD'
      }
    ],
    clinicalNotes: [
      {
        id: 'note-1',
        date: '2026-08-31 08:30',
        authorName: 'Dr. Elena Vance, MD',
        authorRole: 'Chief Physician',
        category: 'Consultation',
        content: '74yo female presenting for bi-monthly hypertension and diabetes review. Patient reports consistent adherence to Lisinopril and Metformin. Bilateral lower extremity edema is trace (+1), significantly improved from previous visit. EKG shows normal sinus rhythm at 72 bpm. Will maintain current pharmaceutical regimen and recheck renal panel in 3 months.',
        icdCodes: ['I11.9 (Hypertensive heart disease)', 'E11.40 (Type 2 diabetes mellitus)']
      }
    ],
    assignedWard: 'Cardiology Ward (3rd Floor)',
    assignedBed: 'Bed C-302',
    admissionStatus: 'Observation',
    admissionDate: '2026-08-30 19:40',
    isOfflineCached: true
  },
  {
    id: 'pat-102',
    mrn: 'MC-2026-77341',
    name: 'Mateo Alejandro Gomez',
    dob: '1988-11-03',
    age: 37,
    gender: 'Male',
    bloodType: 'O+',
    phone: '+1 (555) 890-3342',
    email: 'm.gomez88@outlook.com',
    address: '1120 Beacon St, Brookline, MA 02446',
    emergencyContact: {
      name: 'Sofia Gomez (Spouse)',
      relationship: 'Spouse',
      phone: '+1 (555) 890-3349',
    },
    insurance: {
      provider: 'BlueCross BlueShield Premier Choice',
      policyNumber: 'BCBS-MA-8849102',
      groupNumber: 'GRP-CORP-440',
      coveragePercentage: 90,
      copayAmount: 35,
      deductibleMet: true,
    },
    allergies: [
      { id: 'alg-4', allergen: 'Latex', reaction: 'Contact dermatitis, erythema', severity: 'MODERATE' }
    ],
    chronicConditions: [
      'Post-Operative Acute Fracture Repair Right Tibia (S82.201A)',
      'Mild Asthma (J45.20)'
    ],
    vitals: [
      {
        id: 'vit-3',
        bloodPressure: '122/76',
        heartRate: 68,
        temperature: 36.6,
        spo2: 99,
        respiratoryRate: 14,
        heightCm: 180,
        weightKg: 82.0,
        bmi: 25.3,
        recordedAt: '2026-08-31 07:45',
        recordedBy: 'Nurse Marcus Holloway, RN'
      }
    ],
    medications: [
      {
        id: 'med-4',
        name: 'Enoxaparin (Lovenox)',
        dosage: '40 mg / 0.4 mL',
        frequency: 'Subcutaneous Once Daily',
        route: 'Subcutaneous',
        startDate: '2026-08-28',
        prescribingDoctor: 'Dr. Kevin Zhao, MD',
        active: true,
        instructions: 'DVT prophylaxis post-op tibia ORIF.'
      },
      {
        id: 'med-5',
        name: 'Acetaminophen / Oxycodone (Percocet)',
        dosage: '5/325 mg',
        frequency: 'Every 6 hours PRN for severe pain',
        route: 'Oral',
        startDate: '2026-08-28',
        prescribingDoctor: 'Dr. Kevin Zhao, MD',
        active: true,
        instructions: 'Take only as needed for breakthrough pain score > 6.'
      }
    ],
    labResults: [
      {
        id: 'lab-4',
        testName: 'Complete Blood Count (Hemoglobin)',
        category: 'Hematology',
        date: '2026-08-30',
        resultValue: '14.2',
        unit: 'g/dL',
        referenceRange: '13.8 - 17.2',
        status: 'NORMAL',
        orderingDoctor: 'Dr. Kevin Zhao, MD'
      }
    ],
    clinicalNotes: [
      {
        id: 'note-2',
        date: '2026-08-30 16:00',
        authorName: 'Dr. Kevin Zhao, MD',
        authorRole: 'Orthopedic Surgeon',
        category: 'Progress Note',
        content: 'Post-op Day 2 right tibia open reduction internal fixation. Incision clean, intact without drainage. Distal pulses 2+ palpable, sensation intact in deep peroneal nerve distribution. Physical Therapy ambulated patient 30 feet with walker today. Target discharge tomorrow morning.',
        icdCodes: ['S82.201A (Fracture of shaft of right tibia)']
      }
    ],
    assignedWard: 'Surgical & Orthopedic Ward (4th Floor)',
    assignedBed: 'Bed S-405',
    admissionStatus: 'Inpatient',
    admissionDate: '2026-08-28 11:20',
    isOfflineCached: true
  },
  {
    id: 'pat-103',
    mrn: 'MC-2026-90412',
    name: 'Aisha Al-Mansoor',
    dob: '1965-09-24',
    age: 60,
    gender: 'Female',
    bloodType: 'B+',
    phone: '+1 (555) 441-2900',
    email: 'aisha.almansoor@healthnet.org',
    address: '77 Commonwealth Ave, Cambridge, MA 02138',
    emergencyContact: {
      name: 'Tariq Al-Mansoor (Brother)',
      relationship: 'Brother',
      phone: '+1 (555) 441-2905',
    },
    insurance: {
      provider: 'UnitedHealthcare Global Elite',
      policyNumber: 'UHC-GLB-9021884',
      groupNumber: 'GRP-UN-901',
      coveragePercentage: 90,
      copayAmount: 20,
      deductibleMet: true,
    },
    allergies: [
      { id: 'alg-5', allergen: 'Aspirin (NSAIDs)', reaction: 'Severe wheezing, angioedema', severity: 'SEVERE' }
    ],
    chronicConditions: [
      'Acute Myocardial Infarction - Post Stent Placement (I21.09)',
      'Hyperlipidemia (E78.5)'
    ],
    vitals: [
      {
        id: 'vit-4',
        bloodPressure: '118/74',
        heartRate: 64,
        temperature: 36.7,
        spo2: 99,
        respiratoryRate: 15,
        heightCm: 168,
        weightKg: 64.0,
        bmi: 22.7,
        recordedAt: '2026-08-31 08:00',
        recordedBy: 'Nurse Marcus Holloway, RN'
      }
    ],
    medications: [
      {
        id: 'med-6',
        name: 'Ticagrelor (Brilinta)',
        dosage: '90 mg',
        frequency: 'Twice Daily with water',
        route: 'Oral',
        startDate: '2026-08-29',
        prescribingDoctor: 'Dr. Elena Vance, MD',
        active: true,
        instructions: 'Dual antiplatelet therapy. Strict compliance required.'
      },
      {
        id: 'med-7',
        name: 'Metoprolol Succinate ER',
        dosage: '50 mg',
        frequency: 'Once Daily in Morning',
        route: 'Oral',
        startDate: '2026-08-29',
        prescribingDoctor: 'Dr. Elena Vance, MD',
        active: true,
        instructions: 'Do not discontinue abruptly.'
      }
    ],
    labResults: [
      {
        id: 'lab-5',
        testName: 'High-Sensitivity Troponin I',
        category: 'Biochemistry',
        date: '2026-08-30 22:00',
        resultValue: '0.04',
        unit: 'ng/mL',
        referenceRange: '< 0.03',
        status: 'CRITICAL',
        orderingDoctor: 'Dr. Elena Vance, MD',
        notes: 'Downward trending from peak 4.8 ng/mL post-PCI.'
      }
    ],
    clinicalNotes: [
      {
        id: 'note-3',
        date: '2026-08-31 07:30',
        authorName: 'Dr. Elena Vance, MD',
        authorRole: 'Chief Physician',
        category: 'Progress Note',
        content: 'Post-STEMI Day 2 status post successful drug-eluting stent to LAD. Patient is pain-free. Continuous telemetry shows normal sinus rhythm without ventricular ectopy. Echocardiogram shows preserved LVEF 55%. Transferring from ICU to Step-down telemetry unit.',
        icdCodes: ['I21.09 (ST elevation myocardial infarction)']
      }
    ],
    assignedWard: 'Intensive Care Unit (ICU - 2nd Floor)',
    assignedBed: 'Bed ICU-201',
    admissionStatus: 'Inpatient',
    admissionDate: '2026-08-29 03:15',
    isOfflineCached: true
  },
  {
    id: 'pat-104',
    mrn: 'MC-2026-11840',
    name: 'Samuel Lucas Sterling-Miller',
    dob: '2019-06-18',
    age: 7,
    gender: 'Male',
    bloodType: 'O-',
    phone: '+1 (555) 902-1847',
    email: 'miller.family@gmail.com',
    address: '891 Pine Tree Way, Newton, MA 02458',
    emergencyContact: {
      name: 'Rachel Sterling-Miller (Mother)',
      relationship: 'Mother',
      phone: '+1 (555) 902-1847',
    },
    insurance: {
      provider: 'MassHealth Premium Child Health Plus',
      policyNumber: 'MH-PED-110482',
      groupNumber: 'GRP-STATE-01',
      coveragePercentage: 100,
      copayAmount: 0,
      deductibleMet: true,
    },
    allergies: [
      { id: 'alg-6', allergen: 'Peanuts & Tree Nuts', reaction: 'Anaphylaxis', severity: 'LIFE_THREATENING' }
    ],
    chronicConditions: [
      'Acute Viral Bronchiolitis with Wheezing (J21.9)'
    ],
    vitals: [
      {
        id: 'vit-5',
        bloodPressure: '98/62',
        heartRate: 104,
        temperature: 37.8,
        spo2: 96,
        respiratoryRate: 24,
        heightCm: 122,
        weightKg: 23.5,
        bmi: 15.8,
        recordedAt: '2026-08-31 08:20',
        recordedBy: 'Nurse Marcus Holloway, RN'
      }
    ],
    medications: [
      {
        id: 'med-8',
        name: 'Albuterol Sulfate Inhalation Aerosol',
        dosage: '90 mcg / actuation (2 puffs)',
        frequency: 'Every 4 hours PRN for wheeze',
        route: 'Inhalation',
        startDate: '2026-08-30',
        prescribingDoctor: 'Dr. Clara Thorne, MD',
        active: true,
        instructions: 'Use with pediatric spacer mask.'
      }
    ],
    labResults: [
      {
        id: 'lab-6',
        testName: 'Respiratory Pathogen PCR Panel',
        category: 'Microbiology',
        date: '2026-08-30',
        resultValue: 'POSITIVE: RSV A',
        unit: 'Qualitative',
        referenceRange: 'Negative',
        status: 'ABNORMAL',
        orderingDoctor: 'Dr. Clara Thorne, MD'
      }
    ],
    clinicalNotes: [
      {
        id: 'note-4',
        date: '2026-08-30 20:00',
        authorName: 'Dr. Clara Thorne, MD',
        authorRole: 'Pediatric Specialist',
        category: 'Admission Note',
        content: '7yo boy admitted with tachypnea, subcostal retractions, and RSV-positive viral bronchiolitis. Hydration maintained via oral fluids and supplemental low-flow nasal cannula at 1 L/min. Tolerating well.',
        icdCodes: ['J21.9 (Acute bronchiolitis)']
      }
    ],
    assignedWard: 'Pediatric Care Ward (5th Floor)',
    assignedBed: 'Bed P-503',
    admissionStatus: 'Inpatient',
    admissionDate: '2026-08-30 18:30',
    isOfflineCached: true
  }
];

export const INITIAL_WARDS: Ward[] = [
  {
    id: 'ward-icu',
    name: 'Intensive Care Unit (ICU)',
    code: 'ICU-2F',
    department: 'Critical Care Medicine',
    floor: 2,
    headNurse: 'Nurse Marcus Holloway, RN',
    capacity: 6,
    color: '#ef4444',
    beds: [
      {
        id: 'bed-icu-201',
        bedNumber: 'ICU-201',
        roomNumber: 'Room 201-A',
        status: 'Occupied',
        patientId: 'pat-103',
        patientName: 'Aisha Al-Mansoor',
        patientMrn: 'MC-2026-90412',
        admissionDate: '2026-08-29 03:15',
        acuityLevel: 'Critical',
        assignedNurse: 'Nurse Marcus Holloway, RN',
        notes: 'Post-STEMI continuous telemetry monitoring.'
      },
      {
        id: 'bed-icu-202',
        bedNumber: 'ICU-202',
        roomNumber: 'Room 202-A',
        status: 'Occupied',
        patientId: 'pat-105',
        patientName: 'David K. Hoffman',
        patientMrn: 'MC-2026-33910',
        admissionDate: '2026-08-30 14:10',
        acuityLevel: 'Critical',
        assignedNurse: 'Nurse Marcus Holloway, RN',
        notes: 'Severe sepsis secondary to pyelonephritis.'
      },
      {
        id: 'bed-icu-203',
        bedNumber: 'ICU-203',
        roomNumber: 'Room 203-A',
        status: 'Cleaning',
        assignedNurse: 'Nurse Marcus Holloway, RN',
        notes: 'Discharged at 06:30. Terminal sanitation in progress.'
      },
      {
        id: 'bed-icu-204',
        bedNumber: 'ICU-204',
        roomNumber: 'Room 204-A',
        status: 'Available',
        assignedNurse: 'Nurse Marcus Holloway, RN',
        notes: 'Equipped with Servo-u Ventilator.'
      },
      {
        id: 'bed-icu-205',
        bedNumber: 'ICU-205',
        roomNumber: 'Room 205-A',
        status: 'Occupied',
        patientId: 'pat-106',
        patientName: 'Maria Santos',
        patientMrn: 'MC-2026-88129',
        admissionDate: '2026-08-31 04:00',
        acuityLevel: 'Critical',
        assignedNurse: 'Nurse Chloe Ramirez, RN',
        notes: 'DKA on insulin drip.'
      },
      {
        id: 'bed-icu-206',
        bedNumber: 'ICU-206',
        roomNumber: 'Room 206-A',
        status: 'Available',
        assignedNurse: 'Nurse Marcus Holloway, RN',
        notes: 'Negative pressure isolation suite.'
      }
    ]
  },
  {
    id: 'ward-cardiology',
    name: 'Cardiovascular Care Unit',
    code: 'CARD-3F',
    department: 'Cardiology',
    floor: 3,
    headNurse: 'Nurse Chloe Ramirez, RN',
    capacity: 8,
    color: '#f97316',
    beds: [
      {
        id: 'bed-c-301',
        bedNumber: 'Bed C-301',
        roomNumber: 'Room 301',
        status: 'Available',
        assignedNurse: 'Nurse Chloe Ramirez, RN',
      },
      {
        id: 'bed-c-302',
        bedNumber: 'Bed C-302',
        roomNumber: 'Room 302',
        status: 'Occupied',
        patientId: 'pat-101',
        patientName: 'Eleanor Roosevelt-Bennett',
        patientMrn: 'MC-2026-88910',
        admissionDate: '2026-08-30 19:40',
        acuityLevel: 'Moderate',
        assignedNurse: 'Nurse Chloe Ramirez, RN',
        notes: 'Observation for telemetry and BP stabilization.'
      },
      {
        id: 'bed-c-303',
        bedNumber: 'Bed C-303',
        roomNumber: 'Room 303',
        status: 'Occupied',
        patientId: 'pat-107',
        patientName: 'Robert Langdon',
        patientMrn: 'MC-2026-44912',
        admissionDate: '2026-08-29 11:00',
        acuityLevel: 'Stable',
        assignedNurse: 'Nurse Chloe Ramirez, RN'
      },
      {
        id: 'bed-c-304',
        bedNumber: 'Bed C-304',
        roomNumber: 'Room 304',
        status: 'Available',
        assignedNurse: 'Nurse Chloe Ramirez, RN'
      },
      {
        id: 'bed-c-305',
        bedNumber: 'Bed C-305',
        roomNumber: 'Room 305',
        status: 'Maintenance',
        notes: 'Telemetry lead calibration & monitor replacement.'
      },
      {
        id: 'bed-c-306',
        bedNumber: 'Bed C-306',
        roomNumber: 'Room 306',
        status: 'Occupied',
        patientId: 'pat-108',
        patientName: 'George Washington Carver Jr.',
        patientMrn: 'MC-2026-55914',
        admissionDate: '2026-08-31 01:20',
        acuityLevel: 'Moderate',
        assignedNurse: 'Nurse Chloe Ramirez, RN'
      },
      {
        id: 'bed-c-307',
        bedNumber: 'Bed C-307',
        roomNumber: 'Room 307',
        status: 'Cleaning',
        notes: 'UV-C sterilization in progress.'
      },
      {
        id: 'bed-c-308',
        bedNumber: 'Bed C-308',
        roomNumber: 'Room 308',
        status: 'Available'
      }
    ]
  },
  {
    id: 'ward-surgical',
    name: 'Surgical & Orthopedics Ward',
    code: 'SURG-4F',
    department: 'Surgery & Orthopedics',
    floor: 4,
    headNurse: 'Nurse David Kim, BSN',
    capacity: 6,
    color: '#0ea5e9',
    beds: [
      {
        id: 'bed-s-401',
        bedNumber: 'Bed S-401',
        roomNumber: 'Room 401',
        status: 'Occupied',
        patientId: 'pat-109',
        patientName: 'Lucas Henderson',
        patientMrn: 'MC-2026-99120',
        admissionDate: '2026-08-27 10:00',
        acuityLevel: 'Stable',
        assignedNurse: 'Nurse David Kim, BSN'
      },
      {
        id: 'bed-s-402',
        bedNumber: 'Bed S-402',
        roomNumber: 'Room 402',
        status: 'Available'
      },
      {
        id: 'bed-s-403',
        bedNumber: 'Bed S-403',
        roomNumber: 'Room 403',
        status: 'Available'
      },
      {
        id: 'bed-s-404',
        bedNumber: 'Bed S-404',
        roomNumber: 'Room 404',
        status: 'Cleaning'
      },
      {
        id: 'bed-s-405',
        bedNumber: 'Bed S-405',
        roomNumber: 'Room 405',
        status: 'Occupied',
        patientId: 'pat-102',
        patientName: 'Mateo Alejandro Gomez',
        patientMrn: 'MC-2026-77341',
        admissionDate: '2026-08-28 11:20',
        acuityLevel: 'Stable',
        assignedNurse: 'Nurse David Kim, BSN',
        notes: 'Post-op right tibia ORIF.'
      },
      {
        id: 'bed-s-406',
        bedNumber: 'Bed S-406',
        roomNumber: 'Room 406',
        status: 'Available'
      }
    ]
  },
  {
    id: 'ward-pediatric',
    name: 'Pediatric Care Center',
    code: 'PEDS-5F',
    department: 'Pediatrics & Neonatology',
    floor: 5,
    headNurse: 'Nurse Hannah Abbott, RN',
    capacity: 6,
    color: '#8b5cf6',
    beds: [
      {
        id: 'bed-p-501',
        bedNumber: 'Bed P-501',
        roomNumber: 'Room 501',
        status: 'Available'
      },
      {
        id: 'bed-p-502',
        bedNumber: 'Bed P-502',
        roomNumber: 'Room 502',
        status: 'Occupied',
        patientId: 'pat-110',
        patientName: 'Lily Anne Watson',
        patientMrn: 'MC-2026-11993',
        admissionDate: '2026-08-30 09:30',
        acuityLevel: 'Moderate',
        assignedNurse: 'Nurse Hannah Abbott, RN'
      },
      {
        id: 'bed-p-503',
        bedNumber: 'Bed P-503',
        roomNumber: 'Room 503',
        status: 'Occupied',
        patientId: 'pat-104',
        patientName: 'Samuel Lucas Sterling-Miller',
        patientMrn: 'MC-2026-11840',
        admissionDate: '2026-08-30 18:30',
        acuityLevel: 'Moderate',
        assignedNurse: 'Nurse Hannah Abbott, RN',
        notes: 'RSV Bronchiolitis on low-flow O2.'
      },
      {
        id: 'bed-p-504',
        bedNumber: 'Bed P-504',
        roomNumber: 'Room 504',
        status: 'Available'
      },
      {
        id: 'bed-p-505',
        bedNumber: 'Bed P-505',
        roomNumber: 'Room 505',
        status: 'Available'
      },
      {
        id: 'bed-p-506',
        bedNumber: 'Bed P-506',
        roomNumber: 'Room 506',
        status: 'Cleaning'
      }
    ]
  },
  {
    id: 'ward-maternity',
    name: 'Maternity & Women’s Health',
    code: 'MAT-6F',
    department: 'Obstetrics & Gynecology',
    floor: 6,
    headNurse: 'Nurse Maya Patel, CNM',
    capacity: 6,
    color: '#ec4899',
    beds: [
      { id: 'bed-m-601', bedNumber: 'Bed M-601', roomNumber: 'Suite 601', status: 'Occupied', patientName: 'Victoria Price', patientMrn: 'MC-2026-66102', admissionDate: '2026-08-31 02:45', acuityLevel: 'Stable' },
      { id: 'bed-m-602', bedNumber: 'Bed M-602', roomNumber: 'Suite 602', status: 'Available' },
      { id: 'bed-m-603', bedNumber: 'Bed M-603', roomNumber: 'Suite 603', status: 'Occupied', patientName: 'Zara Khan', patientMrn: 'MC-2026-77884', admissionDate: '2026-08-30 21:15', acuityLevel: 'Moderate' },
      { id: 'bed-m-604', bedNumber: 'Bed M-604', roomNumber: 'Suite 604', status: 'Available' },
      { id: 'bed-m-605', bedNumber: 'Bed M-605', roomNumber: 'Suite 605', status: 'Available' },
      { id: 'bed-m-606', bedNumber: 'Bed M-606', roomNumber: 'Suite 606', status: 'Cleaning' }
    ]
  }
];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-201',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientMrn: 'MC-2026-88910',
    doctorId: 'usr-doc-1',
    doctorName: 'Dr. Elena Vance, MD',
    department: 'Cardiology',
    date: '2026-08-31',
    time: '09:30 AM',
    durationMinutes: 45,
    type: 'Cardiology Follow-up',
    status: 'In-Progress',
    roomNumber: 'Suite 302-A',
    reasonForVisit: 'Bi-monthly hypertension titration, ECG check, and blood sugar control review.',
    staffAlertSent: true,
    vitalsPreChecked: true
  },
  {
    id: 'apt-202',
    patientId: 'pat-102',
    patientName: 'Mateo Alejandro Gomez',
    patientMrn: 'MC-2026-77341',
    doctorId: 'usr-doc-2',
    doctorName: 'Dr. Kevin Zhao, MD',
    department: 'Orthopedics',
    date: '2026-08-31',
    time: '11:00 AM',
    durationMinutes: 30,
    type: 'Surgical Post-Op',
    status: 'Confirmed',
    roomNumber: 'Suite 410',
    reasonForVisit: 'Post-op Day 3 tibia weight-bearing evaluation & staple check.',
    staffAlertSent: true,
    vitalsPreChecked: true
  },
  {
    id: 'apt-203',
    patientId: 'pat-104',
    patientName: 'Samuel Lucas Sterling-Miller',
    patientMrn: 'MC-2026-11840',
    doctorId: 'usr-doc-3',
    doctorName: 'Dr. Clara Thorne, MD',
    department: 'Pediatrics',
    date: '2026-08-31',
    time: '01:30 PM',
    durationMinutes: 30,
    type: 'Pediatric Checkup',
    status: 'Scheduled',
    roomNumber: 'Room 508',
    reasonForVisit: 'Follow-up on RSV recovery, wheeze auscultation, and inhaler spacer technique.',
    staffAlertSent: false,
    vitalsPreChecked: false
  },
  {
    id: 'apt-204',
    patientId: 'pat-103',
    patientName: 'Aisha Al-Mansoor',
    patientMrn: 'MC-2026-90412',
    doctorId: 'usr-doc-1',
    doctorName: 'Dr. Elena Vance, MD',
    department: 'Cardiology',
    date: '2026-08-31',
    time: '03:15 PM',
    durationMinutes: 45,
    type: 'Cardiology Follow-up',
    status: 'Scheduled',
    roomNumber: 'ICU Step-down 204',
    reasonForVisit: 'Post-PCI cardiac rehab orientation and dual-antiplatelet adherence counseling.',
    staffAlertSent: true,
    vitalsPreChecked: true
  },
  {
    id: 'apt-205',
    patientId: 'pat-111',
    patientName: 'Julian Vance-Cross',
    patientMrn: 'MC-2026-44109',
    doctorId: 'usr-doc-4',
    doctorName: 'Dr. Marcus Webb, MD',
    department: 'General Internal Medicine',
    date: '2026-09-01',
    time: '10:00 AM',
    durationMinutes: 30,
    type: 'General Consultation',
    status: 'Scheduled',
    roomNumber: 'Exam Room 102',
    reasonForVisit: 'Annual preventative wellness exam and routine lab panel.',
    staffAlertSent: false,
    vitalsPreChecked: false
  }
];

export const INITIAL_INVOICES: BillingInvoice[] = [
  {
    id: 'inv-301',
    invoiceNumber: 'INV-2026-08819',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientMrn: 'MC-2026-88910',
    issueDate: '2026-08-30',
    dueDate: '2026-09-30',
    status: 'Issued',
    items: [
      {
        id: 'item-1',
        code: '99214 (CPT)',
        description: 'Office / Outpatient Visit - Moderate Medical Decision Making (45m)',
        category: 'Consultation',
        quantity: 1,
        unitPrice: 220.00,
        totalPrice: 220.00
      },
      {
        id: 'item-2',
        code: '80053 (CPT)',
        description: 'Comprehensive Metabolic Panel (14 clinical chemistries)',
        category: 'Laboratory',
        quantity: 1,
        unitPrice: 85.00,
        totalPrice: 85.00
      },
      {
        id: 'item-3',
        code: '83036 (CPT)',
        description: 'Glycosylated Hemoglobin (HbA1c Assay)',
        category: 'Laboratory',
        quantity: 1,
        unitPrice: 65.00,
        totalPrice: 65.00
      },
      {
        id: 'item-4',
        code: '93000 (CPT)',
        description: 'Electrocardiogram, Routine 12-Lead with Interpretation & Report',
        category: 'Consultation',
        quantity: 1,
        unitPrice: 110.00,
        totalPrice: 110.00
      },
      {
        id: 'item-5',
        code: 'ROOM-OBS (CPT)',
        description: 'Cardiology Observation Suite - 24-Hour Bed Stay & Nursing Care',
        category: 'Room & Board',
        quantity: 1,
        unitPrice: 850.00,
        totalPrice: 850.00
      }
    ],
    subtotal: 1330.00,
    insuranceCoverageRate: 0.85,
    insurancePortion: 1130.50,
    patientCopay: 25.00,
    patientAmountPaid: 25.00,
    totalDue: 174.50,
    paymentMethod: 'Credit Card',
    claimId: 'CLM-MED-2026-9901',
    claimStatus: 'Approved',
    notes: 'Medicare Advantage primary. Patient copay $25 settled on check-in. Co-insurance balance billed.'
  },
  {
    id: 'inv-302',
    invoiceNumber: 'INV-2026-08820',
    patientId: 'pat-102',
    patientName: 'Mateo Alejandro Gomez',
    patientMrn: 'MC-2026-77341',
    issueDate: '2026-08-28',
    dueDate: '2026-09-28',
    status: 'Pending_Insurance',
    items: [
      {
        id: 'item-6',
        code: '27759 (CPT)',
        description: 'Open treatment of tibial shaft fracture with plate/screws',
        category: 'Surgical',
        quantity: 1,
        unitPrice: 3800.00,
        totalPrice: 3800.00
      },
      {
        id: 'item-7',
        code: '01392 (CPT)',
        description: 'Anesthesia for closed/open procedures on tibial shaft',
        category: 'Surgical',
        quantity: 1,
        unitPrice: 950.00,
        totalPrice: 950.00
      },
      {
        id: 'item-8',
        code: '73590 (CPT)',
        description: 'Radiologic Examination, Tibia and Fibula, 2 Views Post-Op',
        category: 'Radiology',
        quantity: 2,
        unitPrice: 140.00,
        totalPrice: 280.00
      },
      {
        id: 'item-9',
        code: 'ROOM-SURG (CPT)',
        description: 'Inpatient Surgical Bed Care (2 Nights)',
        category: 'Room & Board',
        quantity: 2,
        unitPrice: 1200.00,
        totalPrice: 2400.00
      }
    ],
    subtotal: 7430.00,
    insuranceCoverageRate: 0.90,
    insurancePortion: 6687.00,
    patientCopay: 35.00,
    patientAmountPaid: 35.00,
    totalDue: 708.00,
    paymentMethod: 'Insurance Direct',
    claimId: 'CLM-BCBS-88910',
    claimStatus: 'Under Review',
    notes: 'Prior authorization auth #99214-OK. Claim submitted electronically.'
  },
  {
    id: 'inv-303',
    invoiceNumber: 'INV-2026-08821',
    patientId: 'pat-103',
    patientName: 'Aisha Al-Mansoor',
    patientMrn: 'MC-2026-90412',
    issueDate: '2026-08-29',
    dueDate: '2026-09-29',
    status: 'Pending_Insurance',
    items: [
      {
        id: 'item-10',
        code: '92928 (CPT)',
        description: 'Percutaneous Transcatheter Coronary Intervention with Stent (LAD)',
        category: 'Surgical',
        quantity: 1,
        unitPrice: 8500.00,
        totalPrice: 8500.00
      },
      {
        id: 'item-11',
        code: 'ICU-CARE (CPT)',
        description: 'Intensive Care Unit Critical Care - First Day',
        category: 'Room & Board',
        quantity: 2,
        unitPrice: 2800.00,
        totalPrice: 5600.00
      }
    ],
    subtotal: 14100.00,
    insuranceCoverageRate: 0.90,
    insurancePortion: 12690.00,
    patientCopay: 20.00,
    patientAmountPaid: 20.00,
    totalDue: 1390.00,
    paymentMethod: 'HSA/FSA',
    claimId: 'CLM-UHC-99120',
    claimStatus: 'Submitted',
    notes: 'Emergency admission PCI covered under statutory ACA emergency mandates.'
  }
];

export const INITIAL_STAFF_ALERTS: StaffAlert[] = [
  {
    id: 'alt-1',
    type: 'CODE_BLUE',
    title: 'CODE BLUE - Emergency Cardiac Response',
    message: 'Cardiac Arrest Protocol activated. STAT Resuscitation Team needed immediately.',
    location: 'Emergency Department - Trauma Bay 1',
    severity: 'EMERGENCY',
    timestamp: '2026-08-31 08:35:10',
    acknowledgedBy: ['Dr. Elena Vance, MD', 'Nurse Marcus Holloway, RN'],
    resolved: false
  },
  {
    id: 'alt-2',
    type: 'STAT_LAB',
    title: 'CRITICAL LAB ALERT: High-Sensitivity Troponin',
    message: 'Troponin I result marked CRITICAL for Patient Aisha Al-Mansoor (MRN MC-2026-90412). Attending physician notified.',
    location: 'ICU Bed 201',
    severity: 'CRITICAL',
    timestamp: '2026-08-31 08:12:00',
    patientId: 'pat-103',
    patientName: 'Aisha Al-Mansoor',
    acknowledgedBy: ['Dr. Elena Vance, MD'],
    resolved: true
  },
  {
    id: 'alt-3',
    type: 'APPOINTMENT_REMINDER',
    title: 'Upcoming Appointment: Eleanor Roosevelt-Bennett',
    message: 'Patient is checked-in and vitals completed in Suite 302-A for Dr. Elena Vance.',
    location: 'Cardiovascular Suite 302-A',
    severity: 'INFO',
    timestamp: '2026-08-31 08:25:00',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    acknowledgedBy: ['Dr. Elena Vance, MD'],
    resolved: false
  },
  {
    id: 'alt-4',
    type: 'BED_SHORTAGE',
    title: 'ICU Capacity Warning (83% Utilized)',
    message: 'ICU has only 1 available bed. Consider step-down transfers for stabilized post-PCI patients.',
    location: 'Intensive Care Unit (2nd Floor)',
    severity: 'WARNING',
    timestamp: '2026-08-31 07:15:00',
    acknowledgedBy: ['Dr. Arthur Sterling'],
    resolved: false
  }
];

export const INITIAL_MEDICATION_REMINDERS: MedicationAdherenceReminder[] = [
  {
    id: 'rem-1',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    medicationName: 'Lisinopril 20mg',
    dosage: '1 tablet (20mg)',
    scheduledTime: '08:00 AM',
    frequency: 'Daily (Morning)',
    instructions: 'Take with a glass of water after breakfast.',
    status: 'TAKEN',
    lastLoggedAt: '2026-08-31 08:05 AM',
    snoozeCount: 0
  },
  {
    id: 'rem-2',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    medicationName: 'Metformin ER 1000mg',
    dosage: '1 tablet (1000mg)',
    scheduledTime: '08:00 AM',
    frequency: 'Twice Daily (Morning & Evening)',
    instructions: 'Take with food to avoid gastric upset.',
    status: 'TAKEN',
    lastLoggedAt: '2026-08-31 08:06 AM',
    snoozeCount: 0
  },
  {
    id: 'rem-3',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    medicationName: 'Atorvastatin 40mg',
    dosage: '1 tablet (40mg)',
    scheduledTime: '09:00 PM',
    frequency: 'Nightly',
    instructions: 'Take before sleep.',
    status: 'SCHEDULED',
    snoozeCount: 0
  },
  {
    id: 'rem-4',
    patientId: 'pat-102',
    patientName: 'Mateo Alejandro Gomez',
    medicationName: 'Enoxaparin (Lovenox) 40mg/0.4mL',
    dosage: 'Subcutaneous injection',
    scheduledTime: '09:00 AM',
    frequency: 'Daily',
    instructions: 'Rotate injection sites around abdomen.',
    status: 'SCHEDULED',
    snoozeCount: 0
  }
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    conversationId: 'conv-pat-101',
    senderId: 'pat-101',
    senderName: 'Eleanor Roosevelt-Bennett',
    senderRole: 'PATIENT',
    recipientId: 'usr-doc-1',
    recipientName: 'Dr. Elena Vance, MD',
    content: 'Good morning Dr. Vance. I took my blood pressure this morning at home before coming in and it read 128/82. My ankle swelling is much better after elevating it yesterday evening.',
    timestamp: '2026-08-31 08:10 AM',
    isEncrypted: true,
    isRead: true,
    clinicalPriority: 'ROUTINE'
  },
  {
    id: 'msg-2',
    conversationId: 'conv-pat-101',
    senderId: 'usr-doc-1',
    senderName: 'Dr. Elena Vance, MD',
    senderRole: 'PHYSICIAN',
    recipientId: 'pat-101',
    recipientName: 'Eleanor Roosevelt-Bennett',
    content: 'That is wonderful news Eleanor! 128/82 is right in our target zone. I reviewed your HbA1c lab report from yesterday and it came down nicely to 6.4%. See you shortly in Suite 302.',
    timestamp: '2026-08-31 08:18 AM',
    isEncrypted: true,
    isRead: true,
    clinicalPriority: 'ROUTINE'
  },
  {
    id: 'msg-3',
    conversationId: 'conv-pat-102',
    senderId: 'usr-doc-2',
    senderName: 'Dr. Kevin Zhao, MD',
    senderRole: 'PHYSICIAN',
    recipientId: 'pat-102',
    recipientName: 'Mateo Alejandro Gomez',
    content: 'Hi Mateo, Nurse Kim noted your pain score dropped to 2/10 after physical therapy. I will come by Bed S-405 at 11:00 AM to inspect your surgical incision.',
    timestamp: '2026-08-31 07:50 AM',
    isEncrypted: true,
    isRead: true,
    clinicalPriority: 'ROUTINE'
  }
];

export const INITIAL_AUDIT_LOGS: HipaaAuditLog[] = [
  {
    id: 'aud-991',
    timestamp: '2026-08-31 08:35:10',
    actorId: 'usr-doc-1',
    actorName: 'Dr. Elena Vance, MD',
    actorRole: 'PHYSICIAN',
    action: 'EMERGENCY_GLASS_BREAK',
    details: 'Emergency override activated for Trauma Bay 1 Code Blue resuscitation EHR access.',
    ipAddress: '10.142.4.88 (Secure Clinical Terminal)',
    checksumHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    isGlassBreak: true,
    glassBreakReason: 'Code Blue Resuscitation - Stat medication allergy lookup'
  },
  {
    id: 'aud-992',
    timestamp: '2026-08-31 08:30:00',
    actorId: 'usr-doc-1',
    actorName: 'Dr. Elena Vance, MD',
    actorRole: 'PHYSICIAN',
    action: 'RECORD_MODIFIED',
    details: 'Added Clinical Consultation Note for Eleanor Roosevelt-Bennett.',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    ipAddress: '10.142.4.88',
    checksumHash: 'a8910bcf2918841029481bcde881294819a819b1839120489128391029481234'
  },
  {
    id: 'aud-993',
    timestamp: '2026-08-31 08:15:00',
    actorId: 'usr-nurse-1',
    actorName: 'Nurse Marcus Holloway, RN',
    actorRole: 'NURSE',
    action: 'PATIENT_RECORD_VIEWED',
    details: 'Vitals biometrics recorded and synchronized for Eleanor Roosevelt-Bennett.',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    ipAddress: '10.142.4.102 (Mobile Clinical Tablet)',
    checksumHash: 'f4120ab991283710294819283719283719283719283719283719283719283719'
  },
  {
    id: 'aud-994',
    timestamp: '2026-08-31 08:00:00',
    actorId: 'usr-admin-1',
    actorName: 'Dr. Arthur Sterling',
    actorRole: 'ADMIN',
    action: 'MFA_AUTHENTICATED',
    details: 'Successful Multi-Factor Authentication via Hardware Token / Biometric.',
    ipAddress: '10.142.1.15 (Admin Core Station)',
    checksumHash: 'c901928371928371928371928371928371928371928371928371928371928371'
  },
  {
    id: 'aud-995',
    timestamp: '2026-08-31 06:00:00',
    actorId: 'SYSTEM_CRON',
    actorName: 'MediCore Automated Cloud Vault',
    actorRole: 'ADMIN',
    action: 'CLOUD_BACKUP_CREATED',
    details: 'Automated 256-bit encrypted snapshot backup created with SHA-256 integrity seal.',
    ipAddress: '10.142.0.1 (Secure Backup Node)',
    checksumHash: '9920192837192837192837192837192837192837192837192837192837192837'
  }
];

export const INITIAL_BACKUP_SNAPSHOTS: CloudBackupSnapshot[] = [
  {
    id: 'snp-20260831-0600',
    timestamp: '2026-08-31 06:00:00 UTC',
    filename: 'medicore_vault_snapshot_20260831_0600.enc.json',
    sizeKb: 1420,
    counts: {
      patients: 4,
      appointments: 5,
      invoices: 3,
      auditLogs: 5,
      wards: 5
    },
    checksum: 'SHA256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069',
    status: 'SYNCED_TO_CLOUD',
    cloudRegion: 'us-east4 (HIPAA Compliant Cloud Vault)',
    triggeredBy: 'Automated Daily DR Daemon'
  },
  {
    id: 'snp-20260830-0600',
    timestamp: '2026-08-30 06:00:00 UTC',
    filename: 'medicore_vault_snapshot_20260830_0600.enc.json',
    sizeKb: 1390,
    counts: {
      patients: 4,
      appointments: 4,
      invoices: 2,
      auditLogs: 4,
      wards: 5
    },
    checksum: 'SHA256:4a5b6c7d8e9f0123456789abcdef0123456789abcdef0123456789abcdef0123',
    status: 'SYNCED_TO_CLOUD',
    cloudRegion: 'us-east4 (HIPAA Compliant Cloud Vault)',
    triggeredBy: 'Automated Daily DR Daemon'
  }
];

// =========================================================================
// DIAGNOSTIC LAB TEST DEFINITIONS CATALOG
// =========================================================================
export const AVAILABLE_LAB_TESTS: LabTestDefinition[] = [
  {
    id: 'test-def-cbc',
    code: 'CBC-85025',
    name: 'Complete Blood Count (CBC) with Diff',
    category: 'Hematology',
    standardPrice: 45.00,
    price: 45.00,
    unit: 'x10^3/uL',
    referenceRange: 'WBC: 4.5-11.0, RBC: 4.2-5.4, Hgb: 12.0-16.0',
    normalRange: 'WBC: 4.5-11.0, RBC: 4.2-5.4, Hgb: 12.0-16.0',
    sampleRequired: 'Whole Blood (EDTA Lavender Top)',
    typicalTurnaroundMinutes: 30
  },
  {
    id: 'test-def-cmp',
    code: 'CMP-80053',
    name: 'Comprehensive Metabolic Panel (CMP)',
    category: 'Biochemistry',
    standardPrice: 65.00,
    price: 65.00,
    unit: 'mg/dL',
    referenceRange: 'Glucose: 70-99, BUN: 7-20, Creatinine: 0.6-1.2, Na: 136-145',
    normalRange: 'Glucose: 70-99, BUN: 7-20, Creatinine: 0.6-1.2, Na: 136-145',
    sampleRequired: 'Serum (Gold/SST Tube)',
    typicalTurnaroundMinutes: 45
  },
  {
    id: 'test-def-lipid',
    code: 'LIPID-80061',
    name: 'Lipid Profile Comprehensive Panel',
    category: 'Biochemistry',
    standardPrice: 55.00,
    price: 55.00,
    unit: 'mg/dL',
    referenceRange: 'Total Chol: <200, HDL: >50, LDL: <100, Trig: <150',
    normalRange: 'Total Chol: <200, HDL: >50, LDL: <100, Trig: <150',
    sampleRequired: 'Serum (Fasting 10-12 hrs)',
    typicalTurnaroundMinutes: 40
  },
  {
    id: 'test-def-hba1c',
    code: 'HBA1C-83036',
    name: 'Glycated Hemoglobin (HbA1c)',
    category: 'Biochemistry',
    standardPrice: 40.00,
    price: 40.00,
    unit: '%',
    referenceRange: '< 5.7% (Normal), 5.7-6.4% (Prediabetes), >= 6.5% (Diabetic)',
    normalRange: '< 5.7% (Normal), 5.7-6.4% (Prediabetes), >= 6.5% (Diabetic)',
    sampleRequired: 'Whole Blood (EDTA Tube)',
    typicalTurnaroundMinutes: 25
  },
  {
    id: 'test-def-trop',
    code: 'TROP-84484',
    name: 'High-Sensitivity Cardiac Troponin-I (STAT)',
    category: 'Biochemistry',
    standardPrice: 85.00,
    price: 85.00,
    unit: 'ng/L',
    referenceRange: '< 14 ng/L (Negative for Myocardial Infarction)',
    normalRange: '< 14 ng/L (Negative for Myocardial Infarction)',
    sampleRequired: 'Heparin Plasma / Serum (STAT)',
    typicalTurnaroundMinutes: 15
  },
  {
    id: 'test-def-renal',
    code: 'RENAL-80069',
    name: 'Renal Function Panel with eGFR',
    category: 'Biochemistry',
    standardPrice: 50.00,
    price: 50.00,
    unit: 'mg/dL',
    referenceRange: 'Creatinine: 0.6-1.2, eGFR: >60 mL/min/1.73m2, BUN: 7-20',
    normalRange: 'Creatinine: 0.6-1.2, eGFR: >60 mL/min/1.73m2, BUN: 7-20',
    sampleRequired: 'Serum (SST Tube)',
    typicalTurnaroundMinutes: 35
  },
  {
    id: 'test-def-ua',
    code: 'UA-81003',
    name: 'Urinalysis Automated with Microscopy',
    category: 'Pathology',
    standardPrice: 30.00,
    price: 30.00,
    unit: 'neg/pos',
    referenceRange: 'Protein: Neg, Leukocytes: Neg, Nitrite: Neg, Glucose: Neg',
    normalRange: 'Protein: Neg, Leukocytes: Neg, Nitrite: Neg, Glucose: Neg',
    sampleRequired: 'Midstream Clean Catch Urine',
    typicalTurnaroundMinutes: 20
  },
  {
    id: 'test-def-cxr',
    code: 'CXR-71046',
    name: 'Chest X-Ray 2-Views (PA & Lateral)',
    category: 'Radiology',
    standardPrice: 120.00,
    price: 120.00,
    unit: 'Radiological View',
    referenceRange: 'Normal lung fields, cardiothoracic ratio < 0.5',
    normalRange: 'Normal lung fields, cardiothoracic ratio < 0.5',
    sampleRequired: 'Radiology Imaging Suite',
    typicalTurnaroundMinutes: 45
  },
  {
    id: 'test-def-crp',
    code: 'CRP-86140',
    name: 'C-Reactive Protein (High Sensitivity hs-CRP)',
    category: 'Biochemistry',
    standardPrice: 42.00,
    price: 42.00,
    unit: 'mg/L',
    referenceRange: '< 1.0 mg/L (Low cardiovascular risk)',
    normalRange: '< 1.0 mg/L (Low cardiovascular risk)',
    sampleRequired: 'Serum (SST Tube)',
    typicalTurnaroundMinutes: 30
  }
];

// =========================================================================
// INITIAL LAB ORDERS
// =========================================================================
export const INITIAL_LAB_ORDERS: LabOrder[] = [
  {
    id: 'lab-ord-101',
    orderNumber: 'LAB-2026-0881',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientMrn: 'MC-2026-88910',
    orderingDoctorId: 'usr-doc-1',
    orderingDoctorName: 'Dr. Elena Vance, MD',
    orderingDoctorSpecialty: 'Cardiovascular & Internal Medicine',
    orderDate: '2026-08-31 09:15',
    priority: 'URGENT',
    clinicalIndication: 'Patient presenting with mild exertional dyspnea, palpitations, and chronic hypertension checkup.',
    specimenType: 'Venous Whole Blood & Serum',
    status: 'COMPLETED',
    totalPrice: 155.00,
    collectedAt: '2026-08-31 09:30',
    completedAt: '2026-08-31 10:05',
    technicianId: 'usr-lab-1',
    technicianName: 'David Okafor, MLS',
    technicianNotes: 'Serum clear, non-lipemic. High-sensitivity Troponin within normal reference range. Lipid panel reveals elevated LDL.',
    sentBackToSpecialist: true,
    sentBackAt: '2026-08-31 10:08',
    billingAdded: true,
    tests: [
      {
        testCode: 'LIPID-80061',
        testName: 'Lipid Profile Comprehensive Panel',
        category: 'Biochemistry',
        price: 55.00,
        resultValue: 'Total: 218, LDL: 138, HDL: 46, Trig: 168',
        unit: 'mg/dL',
        referenceRange: 'Total <200, LDL <100',
        status: 'ABNORMAL',
        flag: 'HIGH',
        recordedAt: '2026-08-31 10:00'
      },
      {
        testCode: 'TROP-84484',
        testName: 'High-Sensitivity Cardiac Troponin-I (STAT)',
        category: 'Biochemistry',
        price: 85.00,
        resultValue: '4.2',
        unit: 'ng/L',
        referenceRange: '< 14 ng/L',
        status: 'NORMAL',
        flag: 'NORMAL',
        recordedAt: '2026-08-31 10:02'
      },
      {
        testCode: 'CRP-86140',
        testName: 'C-Reactive Protein (High Sensitivity hs-CRP)',
        category: 'Biochemistry',
        price: 42.00,
        resultValue: '3.1',
        unit: 'mg/L',
        referenceRange: '< 1.0 mg/L',
        status: 'ABNORMAL',
        flag: 'HIGH',
        recordedAt: '2026-08-31 10:05'
      }
    ]
  },
  {
    id: 'lab-ord-102',
    orderNumber: 'LAB-2026-0882',
    patientId: 'pat-102',
    patientName: 'Samuel Jackson Wright',
    patientMrn: 'MC-2026-77391',
    orderingDoctorId: 'usr-doc-1',
    orderingDoctorName: 'Dr. Elena Vance, MD',
    orderingDoctorSpecialty: 'Cardiovascular & Internal Medicine',
    orderDate: '2026-08-31 10:30',
    priority: 'ROUTINE',
    clinicalIndication: 'Routine Type 2 Diabetes glycemic monitoring and renal baseline.',
    specimenType: 'Venous Blood & First Morning Urine',
    status: 'IN_PROGRESS',
    totalPrice: 90.00,
    collectedAt: '2026-08-31 10:45',
    technicianId: 'usr-lab-1',
    technicianName: 'David Okafor, MLS',
    technicianNotes: 'Sample processing on Beckman Coulter AU5800 Analyzer.',
    sentBackToSpecialist: false,
    billingAdded: true,
    tests: [
      {
        testCode: 'HBA1C-83036',
        testName: 'Glycated Hemoglobin (HbA1c)',
        category: 'Biochemistry',
        price: 40.00,
        resultValue: '7.8',
        unit: '%',
        referenceRange: '< 5.7% (Diabetic Goal: <7.0%)',
        status: 'ABNORMAL',
        flag: 'HIGH',
        recordedAt: '2026-08-31 10:55'
      },
      {
        testCode: 'RENAL-80069',
        testName: 'Renal Function Panel with eGFR',
        category: 'Biochemistry',
        price: 50.00,
        unit: 'mg/dL',
        referenceRange: 'Creatinine: 0.6-1.2, eGFR: >60',
        status: 'PENDING'
      }
    ]
  },
  {
    id: 'lab-ord-103',
    orderNumber: 'LAB-2026-0883',
    patientId: 'pat-103',
    patientName: 'Maria Sofia Santos',
    patientMrn: 'MC-2026-99204',
    orderingDoctorId: 'usr-doc-1',
    orderingDoctorName: 'Dr. Elena Vance, MD',
    orderingDoctorSpecialty: 'Internal Medicine & Pulmonology',
    orderDate: '2026-08-31 11:00',
    priority: 'STAT',
    clinicalIndication: 'Acute onset productive cough, wheezing, low-grade pyrexia.',
    specimenType: 'Whole Blood & Sputum Specimen',
    status: 'ORDERED',
    totalPrice: 165.00,
    sentBackToSpecialist: false,
    billingAdded: false,
    tests: [
      {
        testCode: 'CBC-85025',
        testName: 'Complete Blood Count (CBC) with Diff',
        category: 'Hematology',
        price: 45.00,
        unit: 'x10^3/uL',
        referenceRange: 'WBC: 4.5-11.0',
        status: 'PENDING'
      },
      {
        testCode: 'CXR-71046',
        testName: 'Chest X-Ray 2-Views (PA & Lateral)',
        category: 'Radiology',
        price: 120.00,
        unit: 'Radiological View',
        referenceRange: 'Clear lung parenchyma',
        status: 'PENDING'
      }
    ]
  }
];

// =========================================================================
// INITIAL PHARMACY PRESCRIPTIONS
// =========================================================================
export const INITIAL_PHARMACY_PRESCRIPTIONS: PharmacyPrescription[] = [
  {
    id: 'rx-2026-9041',
    rxNumber: 'RX-2026-9041',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientMrn: 'MC-2026-88910',
    patientDob: '1952-04-12',
    patientAllergies: [
      { id: 'alg-1', allergen: 'Penicillin', reaction: 'Anaphylaxis', severity: 'LIFE_THREATENING' },
      { id: 'alg-2', allergen: 'Sulfa Drugs', reaction: 'Skin rash', severity: 'MODERATE' }
    ],
    prescribingDoctorId: 'usr-doc-1',
    prescribingDoctorName: 'Dr. Elena Vance, MD',
    prescribingDoctorSpecialty: 'Cardiovascular Medicine',
    diagnosisReference: 'I10 (Essential Primary Hypertension) & E78.0 (Pure Hypercholesterolemia)',
    issueDate: '2026-08-31 10:20',
    priority: 'ROUTINE',
    status: 'DISPENSED',
    totalAmount: 68.50,
    dispensedAt: '2026-08-31 10:40',
    dispensedBy: 'PharmD. Maya Lin (RPH-PHARM-31908)',
    dispensingNotes: 'Five Rights verified via 2D Camera Barcode Scanner. Cross-referenced patient Penicillin & Sulfa allergy profile.',
    batchLotNumber: 'LOT-ATV-88294B',
    addedToBillingInvoice: true,
    items: [
      {
        medicationId: 'med-101',
        name: 'Atorvastatin Calcium',
        barcode: 'MED-ATV-20MG',
        dosage: '20mg',
        form: 'Tablet',
        frequency: 'Once Daily at Bedtime',
        route: 'Oral',
        quantity: 30,
        daysSupply: 30,
        instructions: 'Take 1 tablet by mouth daily in the evening. Avoid grapefruit juice.',
        unitPrice: 0.95,
        totalPrice: 28.50,
        isVerified: true,
        scannedBarcode: 'MED-ATV-20MG',
        batchLotNumber: 'LOT-ATV-88294B',
        expiryDate: '2027-11-30'
      },
      {
        medicationId: 'med-102',
        name: 'Lisinopril',
        barcode: 'MED-LIS-10MG',
        dosage: '10mg',
        form: 'Tablet',
        frequency: 'Once Daily Morning',
        route: 'Oral',
        quantity: 30,
        daysSupply: 30,
        instructions: 'Take 1 tablet by mouth every morning with water.',
        unitPrice: 0.60,
        totalPrice: 18.00,
        isVerified: true,
        scannedBarcode: 'MED-LIS-10MG',
        batchLotNumber: 'LOT-LIS-44019C',
        expiryDate: '2028-02-15'
      },
      {
        medicationId: 'med-103',
        name: 'Coenzyme Q10 Softgel',
        barcode: 'MED-COQ-100MG',
        dosage: '100mg',
        form: 'Capsule',
        frequency: 'Once Daily with Meal',
        route: 'Oral',
        quantity: 30,
        daysSupply: 30,
        instructions: 'Dietary adjunct for statin support.',
        unitPrice: 0.73,
        totalPrice: 22.00,
        isVerified: true,
        scannedBarcode: 'MED-COQ-100MG',
        batchLotNumber: 'LOT-COQ-99102',
        expiryDate: '2027-08-20'
      }
    ]
  },
  {
    id: 'rx-2026-9042',
    rxNumber: 'RX-2026-9042',
    patientId: 'pat-102',
    patientName: 'Samuel Jackson Wright',
    patientMrn: 'MC-2026-77391',
    patientDob: '1968-11-20',
    patientAllergies: [
      { id: 'alg-4', allergen: 'Aspirin (NSAIDs)', reaction: 'Bronchospasm', severity: 'SEVERE' }
    ],
    prescribingDoctorId: 'usr-doc-1',
    prescribingDoctorName: 'Dr. Elena Vance, MD',
    prescribingDoctorSpecialty: 'Internal Medicine',
    diagnosisReference: 'E11.9 (Type 2 Diabetes Mellitus without complications)',
    issueDate: '2026-08-31 11:00',
    priority: 'ROUTINE',
    status: 'PENDING_DISPENSE',
    totalAmount: 42.00,
    addedToBillingInvoice: false,
    items: [
      {
        medicationId: 'med-201',
        name: 'Metformin Hydrochloride Extended-Release',
        barcode: 'MED-MET-500MG',
        dosage: '500mg',
        form: 'Tablet',
        frequency: 'Twice Daily with Meals',
        route: 'Oral',
        quantity: 60,
        daysSupply: 30,
        instructions: 'Take 1 tablet twice daily with breakfast and dinner. Do not crush.',
        unitPrice: 0.45,
        totalPrice: 27.00,
        isVerified: false
      },
      {
        medicationId: 'med-202',
        name: 'Empagliflozin (Jardiance)',
        barcode: 'MED-EMP-10MG',
        dosage: '10mg',
        form: 'Tablet',
        frequency: 'Once Daily Morning',
        route: 'Oral',
        quantity: 30,
        daysSupply: 30,
        instructions: 'Take 1 tablet by mouth daily in the morning.',
        unitPrice: 0.50,
        totalPrice: 15.00,
        isVerified: false
      }
    ]
  }
];

// =========================================================================
// INITIAL MEDICATION ADMINISTRATION RECORDS (BCMA)
// =========================================================================
export const INITIAL_MAR_RECORDS: MedicationAdministrationRecord[] = [
  {
    id: 'mar-101',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientMrn: 'MC-2026-88910',
    patientBarcode: 'PAT-MC-2026-88910',
    medicationId: 'med-101',
    medicationName: 'Atorvastatin Calcium 20mg',
    medicationBarcode: 'MED-ATV-20MG',
    prescribedDose: '20mg Oral Daily',
    route: 'Oral',
    scheduledTime: '2026-08-31 20:00',
    scannedPatientBarcode: 'PAT-MC-2026-88910',
    scannedMedicationBarcode: 'MED-ATV-20MG',
    fiveRightsVerified: {
      rightPatient: true,
      rightDrug: true,
      rightDose: true,
      rightRoute: true,
      rightTime: true
    },
    status: 'VERIFIED_SAFE',
    safetyAlerts: []
  },
  {
    id: 'mar-102',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientMrn: 'MC-2026-88910',
    patientBarcode: 'PAT-MC-2026-88910',
    medicationId: 'med-102',
    medicationName: 'Lisinopril 10mg',
    medicationBarcode: 'MED-LIS-10MG',
    prescribedDose: '10mg Oral Morning',
    route: 'Oral',
    scheduledTime: '2026-08-31 08:00',
    administeredTime: '2026-08-31 08:12',
    administeredBy: 'Nurse Marcus Holloway, RN',
    scannedPatientBarcode: 'PAT-MC-2026-88910',
    scannedMedicationBarcode: 'MED-LIS-10MG',
    fiveRightsVerified: {
      rightPatient: true,
      rightDrug: true,
      rightDose: true,
      rightRoute: true,
      rightTime: true
    },
    status: 'ADMINISTERED',
    safetyAlerts: []
  }
];

// =========================================================================
// INITIAL PATIENT CARE WORKFLOW JOURNEYS (OUTPATIENT END-TO-END)
// =========================================================================
export const INITIAL_CARE_JOURNEYS: PatientCareJourney[] = [
  {
    id: 'jrn-101',
    patientId: 'pat-101',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientMrn: 'MC-2026-88910',
    currentStage: 'CLEARED_OUTPATIENT',
    appointmentId: 'apt-101',
    registeredAt: '2026-08-31 08:45',
    assignedSpecialistId: 'usr-doc-1',
    assignedSpecialistName: 'Dr. Elena Vance, MD',
    specialistDoctorId: 'usr-doc-1',
    specialistDoctorName: 'Dr. Elena Vance, MD',
    specialistDepartment: 'Cardiovascular & Internal Medicine',
    reasonForVisit: 'Hypertension and lipid panel follow-up',
    consultationNotes: 'Patient presented for outpatient cardiac and hyperlipidemia review. Ordered STAT cardiac troponin, lipids, hs-CRP.',
    labOrderId: 'lab-ord-101',
    labCompletedAt: '2026-08-31 10:05',
    diagnosisText: 'Essential primary hypertension (I10) and pure hypercholesterolemia (E78.0). Non-ischemic baseline confirmed with negative cardiac troponin.',
    diagnosisIcdCodes: ['I10', 'E78.0', 'Z79.899'],
    diagnosisPrintedAt: '2026-08-31 10:22',
    physicalCopiesConfirmed: true, // 1 Physical Copy filed to Hospital Archive + 1 Handed to Patient
    prescriptionId: 'rx-2026-9041',
    pharmacyPrescriptionId: 'rx-2026-9041',
    pharmacyDispensedAt: '2026-08-31 10:40',
    invoiceId: 'inv-101',
    billingInvoiceId: 'inv-101',
    cashierClearedAt: '2026-08-31 10:58',
    isOutpatientCleared: true,
    isClearedOnSameDay: true,
    stageHistory: [
      {
        stage: 'RECEPTION_REGISTRATION',
        timestamp: '2026-08-31 08:45',
        actorName: 'Chloe Rodriguez',
        actorRole: 'Receptionist',
        notes: 'Patient registered at central reception, insurance validated, assigned to Dr. Elena Vance (Cardiology).'
      },
      {
        stage: 'SPECIALIST_CONSULTATION',
        timestamp: '2026-08-31 09:10',
        actorName: 'Dr. Elena Vance, MD',
        actorRole: 'Physician / Specialist',
        notes: 'Comprehensive consultation conducted. Vitals checked. Lab test requisition LAB-2026-0881 dispatched to Diagnostics.'
      },
      {
        stage: 'LAB_TESTS_ORDERED',
        timestamp: '2026-08-31 09:15',
        actorName: 'Dr. Elena Vance, MD',
        actorRole: 'Physician / Specialist',
        notes: 'Specimen order received by Central Lab: Lipid Profile, hs-Troponin I, hs-CRP.'
      },
      {
        stage: 'LAB_FINDINGS_RECEIVED',
        timestamp: '2026-08-31 10:08',
        actorName: 'David Okafor, MLS',
        actorRole: 'Lab Technician',
        notes: 'Specimens analyzed and validated. Findings dispatched electronically back to Dr. Elena Vance.'
      },
      {
        stage: 'DIAGNOSIS_AND_REPORT_PRINTED',
        timestamp: '2026-08-31 10:22',
        actorName: 'Dr. Elena Vance, MD',
        actorRole: 'Physician / Specialist',
        notes: 'Diagnosis confirmed. Official Diagnosis Report printed in 2 copies (1 Hospital Records Archive, 1 to Patient). Rx-2026-9041 sent to Pharmacy.'
      },
      {
        stage: 'PHARMACY_PRESCRIBED',
        timestamp: '2026-08-31 10:40',
        actorName: 'PharmD. Maya Lin',
        actorRole: 'Pharmacist',
        notes: 'Atorvastatin 20mg, Lisinopril 10mg, CoQ10 verified with Camera Barcode Scanner and dispensed to patient.'
      },
      {
        stage: 'CASHIER_BILLING_PENDING',
        timestamp: '2026-08-31 10:45',
        actorName: 'Sarah Chen, CPC',
        actorRole: 'Cashier / Billing',
        notes: 'Consolidated invoice generated: Consultation ($150) + Lab ($155) + Pharmacy ($68.50). Insurance applied 85%.'
      },
      {
        stage: 'CLEARED_OUTPATIENT',
        timestamp: '2026-08-31 10:58',
        actorName: 'Sarah Chen, CPC',
        actorRole: 'Cashier / Billing',
        notes: 'Copay payment of $25.00 settled via HSA Card. Stamped discharge receipt issued. Outpatient cleared on same day.'
      }
    ]
  },
  {
    id: 'jrn-102',
    patientId: 'pat-102',
    patientName: 'Samuel Jackson Wright',
    patientMrn: 'MC-2026-77391',
    currentStage: 'LAB_TESTS_ORDERED',
    appointmentId: 'apt-102',
    registeredAt: '2026-08-31 10:15',
    assignedSpecialistId: 'usr-doc-1',
    assignedSpecialistName: 'Dr. Elena Vance, MD',
    specialistDoctorId: 'usr-doc-1',
    specialistDoctorName: 'Dr. Elena Vance, MD',
    specialistDepartment: 'Internal Medicine & Endocrinology',
    reasonForVisit: 'Quarterly diabetic checkup and HbA1c review',
    consultationNotes: 'Quarterly diabetic checkup. Referred to diagnostic lab for HbA1c and Renal Function.',
    labOrderId: 'lab-ord-102',
    physicalCopiesConfirmed: false,
    isOutpatientCleared: false,
    isClearedOnSameDay: false,
    stageHistory: [
      {
        stage: 'RECEPTION_REGISTRATION',
        timestamp: '2026-08-31 10:15',
        actorName: 'Chloe Rodriguez',
        actorRole: 'Receptionist',
        notes: 'Patient checked in at reception desk.'
      },
      {
        stage: 'SPECIALIST_CONSULTATION',
        timestamp: '2026-08-31 10:30',
        actorName: 'Dr. Elena Vance, MD',
        actorRole: 'Physician / Specialist',
        notes: 'Exam completed. Sent to lab for HbA1c & Renal panel.'
      },
      {
        stage: 'LAB_TESTS_ORDERED',
        timestamp: '2026-08-31 10:35',
        actorName: 'Dr. Elena Vance, MD',
        actorRole: 'Physician / Specialist',
        notes: 'Blood draw completed by phlebotomy.'
      }
    ]
  },
  {
    id: 'jrn-103',
    patientId: 'pat-103',
    patientName: 'Maria Sofia Santos',
    patientMrn: 'MC-2026-99204',
    currentStage: 'SPECIALIST_CONSULTATION',
    appointmentId: 'apt-103',
    registeredAt: '2026-08-31 10:45',
    assignedSpecialistId: 'usr-doc-1',
    assignedSpecialistName: 'Dr. Elena Vance, MD',
    specialistDoctorId: 'usr-doc-1',
    specialistDoctorName: 'Dr. Elena Vance, MD',
    specialistDepartment: 'Internal Medicine & Pulmonology',
    reasonForVisit: 'Respiratory wheezing and productive cough',
    consultationNotes: 'Patient experiencing respiratory wheezing and productive cough.',
    labOrderId: 'lab-ord-103',
    physicalCopiesConfirmed: false,
    isOutpatientCleared: false,
    isClearedOnSameDay: false,
    stageHistory: [
      {
        stage: 'RECEPTION_REGISTRATION',
        timestamp: '2026-08-31 10:45',
        actorName: 'Chloe Rodriguez',
        actorRole: 'Receptionist',
        notes: 'Outpatient walk-in registered at reception.'
      },
      {
        stage: 'SPECIALIST_CONSULTATION',
        timestamp: '2026-08-31 11:00',
        actorName: 'Dr. Elena Vance, MD',
        actorRole: 'Physician / Specialist',
        notes: 'In consultation room 302. Ordering STAT Chest X-Ray and CBC.'
      }
    ]
  }
];

// =========================================================================
// INITIAL TRIAGE ASSESSMENTS (ICD-10 & SPECIALTY GUIDELINES)
// =========================================================================
export const INITIAL_TRIAGE_ASSESSMENTS: TriageAssessment[] = [
  {
    id: 'trg-001',
    timestamp: '2026-08-31 08:30',
    patientName: 'Eleanor Roosevelt-Bennett',
    patientId: 'pat-101',
    patientAge: 74,
    patientGender: 'Female',
    chiefComplaint: 'Substernal chest tightness radiating to jaw, mild exertional dyspnea, and elevated home BP 168/95 mmHg.',
    symptomDuration: 'Started 2 hours ago during morning walk',
    vitalSigns: {
      bloodPressure: '164/92',
      heartRate: 88,
      spo2: 96,
      temperature: 36.9,
      respiratoryRate: 18,
      painLevel: 6
    },
    knownAllergies: ['Penicillin (Anaphylaxis)', 'Sulfa Drugs', 'Iodine Contrast Dye'],
    chronicConditions: ['Hypertensive Heart Disease (I11.9)', 'Type 2 Diabetes Mellitus (E11.40)'],
    acuityLevel: 'ESI_2_EMERGENT',
    acuityTitle: 'Level 2 - Emergent (High Risk / Potential ACS / <15m)',
    recommendedDepartment: 'Cardiovascular & Internal Medicine',
    secondaryDepartment: 'Emergency Medicine & Critical Care',
    recommendedSpecialistName: 'Dr. Elena Vance, MD',
    recommendedSpecialistRole: 'Cardiologist & Outpatient Specialist',
    primaryIcd10: {
      code: 'I20.0',
      name: 'Unstable angina',
      category: 'Diseases of the circulatory system (I00-I99)',
      confidenceScore: 0.94,
      clinicalRationale: 'New-onset chest tightness with radiation to jaw in a patient with established hypertensive heart disease and diabetes warrants immediate ruling out of acute coronary syndrome under ICD-10 clinical coding guidelines.'
    },
    secondaryIcd10List: [
      {
        code: 'I10',
        name: 'Essential (primary) hypertension',
        category: 'Hypertensive diseases (I10-I15)',
        confidenceScore: 0.91,
        clinicalRationale: 'Systolic blood pressure exceeding 160 mmHg on presentation.'
      },
      {
        code: 'R07.9',
        name: 'Chest pain, unspecified',
        category: 'Symptoms, signs and abnormal clinical findings (R00-R99)',
        confidenceScore: 0.88,
        clinicalRationale: 'Pre-troponin symptom classification.'
      }
    ],
    differentialDiagnoses: [
      { condition: 'Acute Coronary Syndrome (NSTEMI / Unstable Angina)', icd10: 'I20.0', probability: 0.74, rationale: 'Exertional onset, jaw radiation, high cardiovascular risk profile.' },
      { condition: 'Hypertensive Urgency with Myocardial Strain', icd10: 'I11.9', probability: 0.18, rationale: 'Elevated afterload inducing transient subendocardial ischemia.' },
      { condition: 'Esophageal Spasm / Gastroesophageal Reflux', icd10: 'K21.9', probability: 0.08, rationale: 'Non-cardiac etiology possible but secondary.' }
    ],
    redFlags: [
      'Precordial tightness radiating to mandible',
      'Hypertensive presentation (>160 mmHg systolic)',
      'Multiple cardiovascular co-morbidities (HTN + T2D)'
    ],
    immediateActionProtocols: [
      'STAT 12-Lead ECG within 10 minutes',
      'Draw STAT Cardiac Troponin I (0h/2h baseline)',
      'Continuous Pulse Oximetry and cardiac telemetry monitoring',
      'Chewable Aspirin 324mg (patient has Penicillin allergy, Aspirin verified safe)'
    ],
    suggestedDiagnosticOrders: [
      'STAT High-Sensitivity Cardiac Troponin I',
      '12-Lead Electrocardiogram (ECG)',
      'Complete Metabolic Panel (CMP)',
      'Lipid Profile & hs-CRP'
    ],
    clinicalSummary: '74-year-old female presenting with emergent precordial tightness and jaw radiation. Prioritized ESI Level 2. Immediate allocation to Cardiovascular & Internal Medicine under Dr. Elena Vance with urgent troponin and ECG diagnostics.',
    guidelineReference: 'WHO ICD-10 Guidelines (Chapter IX: Diseases of the Circulatory System) & Emergency Severity Index (ESI v4 Implementation Guide)',
    appliedToRegistration: true
  },
  {
    id: 'trg-002',
    timestamp: '2026-08-31 09:15',
    patientName: 'Samuel Jackson Wright',
    patientId: 'pat-102',
    patientAge: 58,
    patientGender: 'Male',
    chiefComplaint: 'Polyuria, polydipsia, blurred vision over past 2 weeks, fasting glucose self-tested at 265 mg/dL.',
    symptomDuration: 'Subacute (2-3 weeks worsening)',
    vitalSigns: {
      bloodPressure: '134/84',
      heartRate: 76,
      spo2: 98,
      temperature: 36.6,
      respiratoryRate: 16,
      painLevel: 1
    },
    knownAllergies: ['None Reported'],
    chronicConditions: ['Type 2 Diabetes Mellitus', 'Dyslipidemia'],
    acuityLevel: 'ESI_4_SEMI_URGENT',
    acuityTitle: 'Level 4 - Semi-Urgent (1 Resource / Subacute / <60m)',
    recommendedDepartment: 'Endocrinology & Metabolic Disorders',
    secondaryDepartment: 'Internal Medicine',
    recommendedSpecialistName: 'Dr. Sarah Lin, MD',
    recommendedSpecialistRole: 'Endocrinologist & Diabetologist',
    primaryIcd10: {
      code: 'E11.65',
      name: 'Type 2 diabetes mellitus with hyperglycemia',
      category: 'Endocrine, nutritional and metabolic diseases (E00-E89)',
      confidenceScore: 0.96,
      clinicalRationale: 'Classic triad of polyuria, polydipsia, and marked hyperglycemia (>250 mg/dL) without acute ketoacidosis flags conforms to ICD-10 endocrine classification.'
    },
    secondaryIcd10List: [
      {
        code: 'E78.5',
        name: 'Hyperlipidemia, unspecified',
        category: 'Metabolic disorders (E70-E88)',
        confidenceScore: 0.86,
        clinicalRationale: 'Concomitant metabolic syndrome risk factors.'
      },
      {
        code: 'R35.0',
        name: 'Frequency of micturition (Polyuria)',
        category: 'Symptoms and signs involving urinary system (R30-R39)',
        confidenceScore: 0.82,
        clinicalRationale: 'Secondary osmotic diuresis from glycosuria.'
      }
    ],
    differentialDiagnoses: [
      { condition: 'Uncontrolled Type 2 Diabetes Mellitus with Hyperglycemia', icd10: 'E11.65', probability: 0.88, rationale: 'Consistent blood sugar elevation and osmotic symptoms.' },
      { condition: 'Early Hyperosmolar Hyperglycemic State (HHS)', icd10: 'E11.00', probability: 0.09, rationale: 'Requires renal function and serum osmolality evaluation.' },
      { condition: 'Secondary Diabetes due to medication/corticosteroids', icd10: 'E09.9', probability: 0.03, rationale: 'Medication review pending.' }
    ],
    redFlags: [
      'Hyperglycemia > 250 mg/dL',
      'Osmotic diuresis risk of dehydration'
    ],
    immediateActionProtocols: [
      'Point-of-care capillary blood glucose verification',
      'Urine dipstick for ketones and microalbumin',
      'Assess oral hydration status and vital stability'
    ],
    suggestedDiagnosticOrders: [
      'Serum Glycated Hemoglobin (HbA1c)',
      'Comprehensive Metabolic Panel (CMP / eGFR)',
      'Urinalysis & Urine Microalbumin/Creatinine Ratio',
      'Lipid Panel (Fasting)'
    ],
    clinicalSummary: '58-year-old male with symptomatic hyperglycemia. Allocated to Endocrinology & Metabolic Disorders for medication titration and glycemic stabilization.',
    guidelineReference: 'ADA Standards of Care & WHO ICD-10 Chapter IV (Endocrine and Metabolic Disorders)',
    appliedToRegistration: true
  },
  {
    id: 'trg-003',
    timestamp: '2026-08-31 09:40',
    patientName: 'Maria Sofia Santos',
    patientId: 'pat-103',
    patientAge: 42,
    patientGender: 'Female',
    chiefComplaint: 'Productive cough with yellowish sputum, low-grade fever 38.2°C, and bilateral expiratory wheezing.',
    symptomDuration: '4 days worsening',
    vitalSigns: {
      bloodPressure: '122/78',
      heartRate: 92,
      spo2: 94,
      temperature: 38.2,
      respiratoryRate: 22,
      painLevel: 3
    },
    knownAllergies: ['Aspirin (Bronchospasm)'],
    chronicConditions: ['Moderate Persistent Asthma (J45.40)'],
    acuityLevel: 'ESI_3_URGENT',
    acuityTitle: 'Level 3 - Urgent (Multiple Resources / Moderate Dyspnea / <30m)',
    recommendedDepartment: 'Pulmonology & Respiratory Medicine',
    secondaryDepartment: 'Internal Medicine',
    recommendedSpecialistName: 'Dr. Evelyn Reed, MD',
    recommendedSpecialistRole: 'Lead Pulmonologist & Critical Care Specialist',
    primaryIcd10: {
      code: 'J45.901',
      name: 'Unspecified asthma with (acute) exacerbation',
      category: 'Chronic lower respiratory diseases (J40-J47)',
      confidenceScore: 0.93,
      clinicalRationale: 'Acute bronchospastic exacerbation triggered by suspected upper respiratory tract infection in an established asthmatic patient.'
    },
    secondaryIcd10List: [
      {
        code: 'J18.9',
        name: 'Pneumonia, unspecified organism',
        category: 'Influenza and pneumonia (J09-J18)',
        confidenceScore: 0.84,
        clinicalRationale: 'Febrile state with purulent sputum requires ruling out focal consolidation.'
      },
      {
        code: 'J20.9',
        name: 'Acute bronchitis, unspecified',
        category: 'Other acute lower respiratory infections (J20-J22)',
        confidenceScore: 0.81,
        clinicalRationale: 'Tracheobronchial inflammation signs.'
      }
    ],
    differentialDiagnoses: [
      { condition: 'Acute Asthmatic Exacerbation with Secondary Infection', icd10: 'J45.901', probability: 0.70, rationale: 'Expiratory wheezes, tachycardia, and drop in SpO2 to 94%.' },
      { condition: 'Community-Acquired Bacterial Pneumonia', icd10: 'J18.9', probability: 0.22, rationale: 'Fever 38.2°C and productive sputum.' },
      { condition: 'Viral Upper Respiratory Bronchitis', icd10: 'J20.9', probability: 0.08, rationale: 'Upper respiratory prodrome.' }
    ],
    redFlags: [
      'SpO2 down to 94% on room air',
      'Tachypnea (RR 22 bpm)',
      'Known severe Aspirin-exacerbated respiratory disease (AERD)'
    ],
    immediateActionProtocols: [
      'Administer supplemental oxygen via nasal cannula to maintain SpO2 >= 95%',
      'Deliver nebulized Albuterol/Ipratropium (DuoNeb 2.5mg/0.5mg)',
      'Avoid NSAIDs/Aspirin due to confirmed AERD allergy'
    ],
    suggestedDiagnosticOrders: [
      'Chest Radiography (PA and Lateral)',
      'Complete Blood Count (CBC) with Differential',
      'Serum C-Reactive Protein (hs-CRP)',
      'Peak Expiratory Flow Rate (PEFR)'
    ],
    clinicalSummary: '42-year-old female with asthmatic flare-up, febrile state, and moderate hypoxia. Triage priority ESI Level 3. Assigned to Pulmonology & Respiratory Medicine under Dr. Evelyn Reed.',
    guidelineReference: 'GINA Global Strategy for Asthma Management & WHO ICD-10 Chapter X (Diseases of the Respiratory System)',
    appliedToRegistration: true
  }
];


