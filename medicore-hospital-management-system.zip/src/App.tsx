/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { HospitalProvider, useHospital } from './context/HospitalContext';
import { Header } from './components/layout/Header';
import { Sidebar, MobileNav, NavTab } from './components/layout/Sidebar';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { PatientRecords } from './components/patients/PatientRecords';
import { AppointmentScheduler } from './components/appointments/AppointmentScheduler';
import { BillingModule } from './components/billing/BillingModule';
import { WardOccupancy } from './components/wards/WardOccupancy';
import { StaffAlertsFeed } from './components/alerts/StaffAlertsFeed';
import { SecureProviderChat } from './components/chat/SecureProviderChat';
import { HipaaAuditTrail } from './components/security/HipaaAuditTrail';
import { CloudBackupModule } from './components/backup/CloudBackupModule';
import { OutpatientWorkflowView } from './components/workflow/OutpatientWorkflowView';
import { TriageAssistantView } from './components/triage/TriageAssistantView';
import { LaboratoryView } from './components/lab/LaboratoryView';
import { PharmacyView } from './components/pharmacy/PharmacyView';
import { BarcodeScannerView } from './components/scanner/BarcodeScannerView';
import { AdminBottleneckDashboard } from './components/admin/AdminBottleneckDashboard';
import { LoginView } from './components/auth/LoginView';
import { MfaModal } from './components/security/MfaModal';
import { GlassBreakModal } from './components/security/GlassBreakModal';
import { SessionLockScreen } from './components/security/SessionLockScreen';
import { AccessibilityModal } from './components/accessibility/AccessibilityModal';

const HospitalAppContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isMfaOpen, setIsMfaOpen] = useState(false);
  const [isGlassBreakOpen, setIsGlassBreakOpen] = useState(false);
  const [isAccessibilityOpen, setIsAccessibilityOpen] = useState(false);
  const { isLocked, isAuthenticated } = useAuth();
  const { isOfflineMode } = useHospital();

  // If not authenticated, show modern institutional login & SSO portal
  if (!isAuthenticated) {
    return <LoginView />;
  }

  if (isLocked) {
    return <SessionLockScreen />;
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans antialiased selection:bg-teal-700 selection:text-white">
      {/* Top Application Header */}
      <Header
        onOpenMfa={() => setIsMfaOpen(true)}
        onOpenGlassBreak={() => setIsGlassBreakOpen(true)}
        onOpenAccessibility={() => setIsAccessibilityOpen(true)}
      />

      {/* Main Workspace with Sidebar and Content View */}
      <div className="flex-1 flex w-full max-w-[1600px] mx-auto">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto pb-24 lg:pb-8 max-w-full">
          {activeTab === 'dashboard' && <DashboardOverview onNavigate={setActiveTab} />}
          {activeTab === 'adminBottlenecks' && <AdminBottleneckDashboard />}
          {activeTab === 'triage' && <TriageAssistantView onNavigate={setActiveTab} />}
          {activeTab === 'workflow' && <OutpatientWorkflowView />}
          {activeTab === 'labs' && <LaboratoryView />}
          {activeTab === 'pharmacy' && <PharmacyView />}
          {activeTab === 'scanner' && <BarcodeScannerView />}
          {activeTab === 'patients' && <PatientRecords onNavigate={setActiveTab} />}
          {activeTab === 'appointments' && <AppointmentScheduler onNavigate={setActiveTab} />}
          {activeTab === 'billing' && <BillingModule />}
          {activeTab === 'wards' && <WardOccupancy onNavigate={setActiveTab} />}
          {activeTab === 'alerts' && <StaffAlertsFeed />}
          {activeTab === 'chat' && <SecureProviderChat />}
          {activeTab === 'audit' && <HipaaAuditTrail />}
          {activeTab === 'backup' && <CloudBackupModule />}
        </main>
      </div>

      {/* Mobile Navigation Bar */}
      <MobileNav activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Modals for Security & Accessibility */}
      <MfaModal isOpen={isMfaOpen} onClose={() => setIsMfaOpen(false)} />
      <GlassBreakModal isOpen={isGlassBreakOpen} onClose={() => setIsGlassBreakOpen(false)} />
      <AccessibilityModal isOpen={isAccessibilityOpen} onClose={() => setIsAccessibilityOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <HospitalProvider>
        <HospitalAppContent />
      </HospitalProvider>
    </AuthProvider>
  );
}
