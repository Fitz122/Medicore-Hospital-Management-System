export type UserRole = 'ADMIN' | 'PHYSICIAN' | 'NURSE' | 'BILLING' | 'PATIENT' | 'RECEPTIONIST' | 'LAB_TECHNICIAN' | 'PHARMACIST';

export type Language = 'en' | 'es' | 'fr' | 'zh' | 'ar' | 'de';

export type SaaSSubscriptionPlan = 'STARTER' | 'PROFESSIONAL' | 'ENTERPRISE';

export type SaaSFacilityType = 
  | 'HOSPITAL' 
  | 'OUTPATIENT_CLINIC' 
  | 'URGENT_CARE' 
  | 'DIAGNOSTIC_LAB' 
  | 'TELEHEALTH_GROUP' 
  | 'SPECIALTY_SURGICAL';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  department: string;
  organizationName?: string;
  organizationType?: string;
  planTier?: SaaSSubscriptionPlan;
  licenseNumber?: string;
  cloudRegion?: string;
  mfaEnabled: boolean;
  mfaVerified: boolean;
  isRegisteredAccount?: boolean;
  registeredAt?: string;
}

export interface SaaSRegistrationData {
  organizationName: string;
  facilityType: SaaSFacilityType | string;
  planTier: SaaSSubscriptionPlan;
  adminName: string;
  email: string;
  password?: string;
  role: UserRole;
  department: string;
  licenseNumber?: string;
  cloudRegion?: string;
  isTrial?: boolean;
  inviteCode?: string;
}

export interface VitalSign {
  id: string;
  bloodPressure: string; // e.g., "120/80"
  heartRate: number; // bpm
  temperature: number; // in Celsius e.g., 37.0
  spo2: number; // % oxygen e.g., 98
  respiratoryRate: number; // breaths per min
  heightCm: number;
  weightKg: number;
  bmi: number;
  recordedAt: string;
  recordedBy: string;
}

export interface Allergy {
  id: string;
  allergen: string;
  reaction: string;
  severity: 'MILD' | 'MODERATE' | 'SEVERE' | 'LIFE_THREATENING';
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  route: 'Oral' | 'IV' | 'Topical' | 'Inhalation' | 'Subcutaneous';
  startDate: string;
  endDate?: string;
  prescribingDoctor: string;
  active: boolean;
  instructions: string;
  barcode?: string; // NDC / Barcode e.g. "MED-LIP-20MG"
  batchNumber?: string;
  isDispensed?: boolean;
  dispensedAt?: string;
}

export interface LabResult {
  id: string;
  testName: string;
  category: 'Hematology' | 'Biochemistry' | 'Microbiology' | 'Radiology' | 'Pathology';
  date: string;
  resultValue: string;
  unit: string;
  referenceRange: string;
  status: 'NORMAL' | 'ABNORMAL' | 'CRITICAL' | 'PENDING';
  orderingDoctor: string;
  notes?: string;
}

export interface ClinicalNote {
  id: string;
  date: string;
  authorName: string;
  authorRole: string;
  category: 'Progress Note' | 'Consultation' | 'Admission Note' | 'Discharge Summary' | 'Nursing Assessment' | 'Assessment';
  content?: string;
  note?: string;
  icdCodes?: string[];
  isEncrypted?: boolean;
}

export interface Patient {
  id: string;
  mrn: string; // Medical Record Number
  name: string;
  dob?: string;
  dateOfBirth?: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  bloodType: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  phone: string;
  email: string;
  address: string;
  conditions?: string[];
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  insurance: {
    provider: string;
    policyNumber: string;
    groupNumber: string;
    coveragePercentage: number;
    copayAmount: number;
    deductibleMet: boolean;
  };
  allergies: Allergy[];
  chronicConditions: string[];
  vitals: VitalSign[];
  medications: Medication[];
  labResults: LabResult[];
  clinicalNotes: ClinicalNote[];
  assignedWard?: string;
  assignedBed?: string;
  admissionStatus: 'Outpatient' | 'Inpatient' | 'Observation' | 'Discharged';
  admissionDate?: string;
  isOfflineCached?: boolean;
}

export type AppointmentStatus = 'Scheduled' | 'Confirmed' | 'In-Progress' | 'Completed' | 'Cancelled' | 'No-Show';
export type AppointmentType = 
  | 'General Consultation' 
  | 'Cardiology Follow-up' 
  | 'Pediatric Checkup' 
  | 'Surgical Post-Op' 
  | 'Emergency Triage' 
  | 'Telehealth Review'
  | 'Specialist Consultation'
  | 'Specialist Review'
  | 'Diagnostic Lab'
  | 'Pharmacy Dispense';

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientMrn: string;
  doctorId: string;
  doctorName: string;
  doctorSpecialty?: string;
  department: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  durationMinutes: number;
  type: AppointmentType;
  status: AppointmentStatus;
  roomNumber: string;
  reasonForVisit: string;
  staffAlertSent: boolean;
  vitalsPreChecked: boolean;
}

export interface BillingItem {
  id: string;
  code: string; // CPT or ICD-10 code
  description: string;
  category: 'Consultation' | 'Laboratory' | 'Pharmacy' | 'Radiology' | 'Surgical' | 'Room & Board';
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export type InvoiceStatus = 'Draft' | 'Issued' | 'Pending_Insurance' | 'Partially_Paid' | 'Paid' | 'Disputed';

export interface BillingInvoice {
  id: string;
  invoiceNumber: string;
  patientId: string;
  patientName: string;
  patientMrn: string;
  issueDate: string;
  dueDate: string;
  status: InvoiceStatus;
  items: BillingItem[];
  subtotal: number;
  tax?: number;
  discount?: number;
  insuranceCoverageRate?: number; // e.g. 0.8 (80%)
  insuranceCoverage?: number;
  insurancePortion?: number;
  insurancePolicyNumber?: string;
  copayAmount?: number;
  patientCopay?: number;
  patientAmountPaid?: number;
  totalDue: number;
  paymentMethod?: 'Insurance Direct' | 'Credit Card' | 'HSA/FSA' | 'Bank Transfer' | 'Cash' | 'Insurance + Co-pay';
  claimId?: string;
  claimStatus?: 'Submitted' | 'Under Review' | 'Approved' | 'Rejected';
  notes?: string;
}

export type BedStatus = 'Available' | 'Occupied' | 'Cleaning' | 'Maintenance';

export interface Bed {
  id: string;
  bedNumber: string;
  roomNumber: string;
  status: BedStatus;
  patientId?: string;
  patientName?: string;
  patientMrn?: string;
  admissionDate?: string;
  acuityLevel?: 'Low' | 'Moderate' | 'Critical' | 'Stable';
  assignedNurse?: string;
  notes?: string;
}

export interface Ward {
  id: string;
  name: string;
  code: string;
  department: string;
  floor: number;
  headNurse: string;
  capacity: number;
  beds: Bed[];
  color: string;
}

export type AlertSeverity = 'EMERGENCY' | 'CRITICAL' | 'WARNING' | 'INFO';
export type AlertType = 
  | 'CODE_BLUE' 
  | 'TRAUMA_STAT' 
  | 'RAPID_RESPONSE' 
  | 'STAT_LAB' 
  | 'BED_SHORTAGE' 
  | 'APPOINTMENT_REMINDER' 
  | 'MEDICATION_DUE'
  | 'LAB_RESULT'
  | 'MEDICATION_ALERT';

export interface StaffAlert {
  id: string;
  type: AlertType;
  title: string;
  message: string;
  location: string;
  severity: AlertSeverity;
  timestamp: string;
  patientId?: string;
  patientName?: string;
  acknowledgedBy: string[];
  resolved: boolean;
}

export interface MedicationAdherenceReminder {
  id: string;
  patientId: string;
  patientName: string;
  medicationName: string;
  dosage: string;
  scheduledTime: string; // e.g. "08:00 AM"
  frequency: string;
  instructions: string;
  status: 'SCHEDULED' | 'TAKEN' | 'SNOOZED' | 'MISSED';
  lastLoggedAt?: string;
  snoozeCount: number;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  recipientId: string;
  recipientName: string;
  content: string;
  timestamp: string;
  isEncrypted: boolean;
  isRead: boolean;
  attachmentName?: string;
  clinicalPriority: 'ROUTINE' | 'URGENT';
}

export interface HipaaAuditLog {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: 
    | 'PATIENT_RECORD_VIEWED' 
    | 'RECORD_MODIFIED' 
    | 'EMERGENCY_GLASS_BREAK' 
    | 'BILLING_PROCESSED' 
    | 'REPORT_EXPORTED' 
    | 'CLOUD_BACKUP_CREATED' 
    | 'MFA_AUTHENTICATED' 
    | 'MEDICATION_LOGGED'
    | 'BARCODE_MEDICATION_VERIFIED'
    | 'LAB_TEST_ORDERED'
    | 'LAB_RESULTS_DISPATCHED'
    | 'LAB_RESULTS_SENT_TO_SPECIALIST'
    | 'PRESCRIPTION_ISSUED'
    | 'PRESCRIPTION_DISPENSED'
    | 'MEDICATION_DISPENSED'
    | 'DIAGNOSIS_REPORT_PRINTED_AND_ARCHIVED'
    | 'OUTPATIENT_CLEARED'
    | 'OUTPATIENT_CLEARED_SAME_DAY'
    | 'AI_TRIAGE_PERFORMED'
    | 'PATIENT_REGISTERED'
    | 'REMOTE_VIDEO_CONSULTATION_CONDUCTED'
    | 'REMOTE_CONSULTATION_INITIATED'
    | 'LAB_DIAGNOSTIC_REPORT_GENERATED'
    | 'USER_LOGIN'
    | 'USER_LOGOUT';
  details: string;
  patientId?: string;
  patientName?: string;
  ipAddress: string;
  checksumHash: string;
  isGlassBreak?: boolean;
  glassBreakReason?: string;
}

export interface CloudBackupSnapshot {
  id: string;
  timestamp: string;
  filename: string;
  sizeKb: number;
  counts: {
    patients: number;
    appointments: number;
    invoices: number;
    auditLogs: number;
    wards: number;
  };
  checksum: string;
  status: 'SYNCED_TO_CLOUD' | 'LOCAL_STAGED' | 'RESTORED';
  cloudRegion: string;
  triggeredBy: string;
}

export interface AccessibilitySettings {
  seniorMode: boolean;
  highContrast: boolean;
  fontSize: 'normal' | 'large' | 'extra-large';
  textToSpeechEnabled: boolean;
}

// ----------------------------------------------------
// DIAGNOSTIC LABORATORY TYPES
// ----------------------------------------------------
export interface LabTestDefinition {
  id?: string;
  code: string;
  name: string;
  category: 'Hematology' | 'Biochemistry' | 'Microbiology' | 'Radiology' | 'Pathology';
  standardPrice: number;
  price?: number;
  unit: string;
  referenceRange: string;
  normalRange?: string;
  sampleRequired?: string;
  typicalTurnaroundMinutes?: number;
}

export interface LabOrderItemResult {
  id?: string;
  testCode: string;
  code?: string;
  testName: string;
  category: 'Hematology' | 'Biochemistry' | 'Microbiology' | 'Radiology' | 'Pathology';
  price: number;
  resultValue?: string;
  unit: string;
  referenceRange: string;
  normalRange?: string;
  sampleRequired?: string;
  status: 'NORMAL' | 'ABNORMAL' | 'CRITICAL' | 'PENDING' | 'COMPLETED';
  interpretation?: string;
  flag?: 'HIGH' | 'LOW' | 'CRITICAL' | 'NORMAL';
  recordedAt?: string;
}

export interface LabOrder {
  id: string;
  orderNumber: string; // e.g. "LAB-2026-0881"
  patientId: string;
  patientName: string;
  patientMrn: string;
  orderingDoctorId: string;
  orderingDoctorName: string;
  orderingDoctor?: string;
  doctorName?: string;
  orderingDoctorSpecialty: string;
  orderDate: string;
  priority: 'ROUTINE' | 'URGENT' | 'STAT';
  clinicalIndication: string;
  specimenType: string; // e.g. "Whole Blood (EDTA)", "Serum", "Midstream Urine"
  status: 'ORDERED' | 'SAMPLE_COLLECTED' | 'IN_PROGRESS' | 'IN_ANALYSIS' | 'COMPLETED' | 'CANCELLED';
  tests: LabOrderItemResult[];
  totalPrice: number;
  resultsSummary?: string;
  results?: Array<{ testName: string; value: string; flag: string; referenceRange: string; unit: string }>;
  sampleCollectionTime?: string;
  resultTime?: string;
  collectedAt?: string;
  completedAt?: string;
  technicianId?: string;
  technicianName?: string;
  technicianNotes?: string;
  sentBackToSpecialist: boolean;
  sentBackAt?: string;
  billingAdded: boolean;
}

export type LabTestItem = LabOrderItemResult;
export type LabTestResult = LabResult;

// ----------------------------------------------------
// PHARMACY & PRESCRIPTION TYPES
// ----------------------------------------------------
export interface PharmacyItem {
  id?: string;
  medicationId: string;
  name: string;
  medicationName?: string;
  barcode: string; // NDC / EAN Barcode e.g. "MED-LIP-20MG"
  dosage: string;
  form: 'Tablet' | 'Capsule' | 'Syrup' | 'Injection' | 'Inhaler' | 'Ointment';
  frequency: string;
  route: string;
  quantity: number;
  daysSupply: number;
  instructions: string;
  unitPrice: number;
  totalPrice: number;
  isVerified: boolean;
  isVerifiedByPharmacist?: boolean;
  scannedBarcode?: string;
  batchLotNumber?: string;
  expiryDate?: string;
}

export type PrescriptionMedItem = PharmacyItem;
export type MedicationItem = Medication;

export interface PharmacyPrescription {
  id: string;
  rxNumber: string; // e.g. "RX-2026-9041"
  patientId: string;
  patientName: string;
  patientMrn: string;
  patientDob?: string;
  patientAllergies?: Allergy[];
  prescribingDoctorId: string;
  prescribingDoctorName: string;
  prescribingDoctorRole?: string;
  prescribingDoctorSpecialty?: string;
  diagnosisReference: string;
  issueDate?: string;
  issuedDate?: string;
  priority: 'ROUTINE' | 'URGENT' | 'STAT';
  status: 'PENDING' | 'PENDING_DISPENSE' | 'VERIFIED' | 'DISPENSED' | 'CANCELLED';
  items: PharmacyItem[];
  totalAmount: number;
  dispensedAt?: string;
  dispensedBy?: string;
  dispensingNotes?: string;
  batchLotNumber?: string;
  addedToBillingInvoice: boolean;
}

// ----------------------------------------------------
// BARCODE MEDICATION ADMINISTRATION (BCMA / 5 RIGHTS)
// ----------------------------------------------------
export interface MedicationAdministrationRecord {
  id: string;
  patientId: string;
  patientName: string;
  patientMrn: string;
  patientBarcode?: string; // e.g. "PAT-MC-2026-88910"
  patientBarcodeScanned?: string;
  medicationId?: string;
  medicationName: string;
  medicationBarcode?: string; // e.g. "MED-LIP-20MG"
  medicationBarcodeScanned?: string;
  prescribedDose?: string;
  dosage?: string;
  route: string;
  scheduledTime: string;
  administeredTime?: string;
  administeredBy?: string;
  administeredByStaffId?: string;
  administeredByStaffName?: string;
  scannedPatientBarcode?: string;
  scannedMedicationBarcode?: string;
  isBarcodeVerified?: boolean;
  verificationStatus?: string;
  fiveRightsVerified?: {
    rightPatient: boolean;
    rightDrug: boolean;
    rightDose: boolean;
    rightRoute: boolean;
    rightTime: boolean;
  };
  status?: 'PENDING' | 'VERIFIED_SAFE' | 'WARNING_MISMATCH' | 'ADMINISTERED';
  safetyAlerts: string[];
  notes?: string;
}

// ----------------------------------------------------
// PATIENT CARE JOURNEY & OUTPATIENT WORKFLOW
// ----------------------------------------------------
export type WorkflowStage = 
  | 'RECEPTION_REGISTRATION'
  | 'RECEPTION_REGISTERED'
  | 'SPECIALIST_BOOKED'
  | 'SPECIALIST_CONSULTATION'
  | 'SPECIALIST_REVIEW'
  | 'LAB_TESTS_ORDERED'
  | 'LAB_TESTING'
  | 'LAB_RESULTS_READY'
  | 'LAB_FINDINGS_RECEIVED'
  | 'DIAGNOSIS_AND_PRINT'
  | 'DIAGNOSIS_AND_REPORT'
  | 'DIAGNOSIS_AND_REPORT_PRINTED'
  | 'PHARMACY_PRESCRIBED'
  | 'PHARMACY_DISPENSING'
  | 'CASHIER_BILLING'
  | 'CASHIER_BILLING_PENDING'
  | 'CASHIER_PENDING_PAYMENT'
  | 'CLEARED_OUTPATIENT'
  | 'OUTPATIENT_CLEARED';

export type CareJourneyStage = WorkflowStage;

export interface DiagnosisPrintReport {
  reportId: string;
  date: string;
  patientId: string;
  patientName: string;
  patientMrn: string;
  specialistName: string;
  specialty: string;
  clinicalFindings: string;
  labSummary: string;
  diagnosis: string;
  prescribedMedications: string[];
  followUpInstructions: string;
  isArchivedPhysically: boolean;
  isHandedToPatient: boolean;
}

export interface PatientCareJourney {
  id?: string;
  patientId: string;
  patientName: string;
  patientMrn: string;
  currentStage: WorkflowStage;
  appointmentId?: string;
  registeredAt?: string;
  assignedSpecialistId?: string;
  assignedSpecialistName?: string;
  specialistDoctorId?: string;
  specialistDoctorName?: string;
  specialistDepartment?: string;
  reasonForVisit?: string;
  consultationNotes?: string;
  labOrderId?: string;
  labCompletedAt?: string;
  diagnosisText?: string;
  diagnosisReportText?: string;
  diagnosisIcdCodes?: string[];
  diagnosisPrintedAt?: string;
  physicalCopiesConfirmed?: boolean; // 1 to Hospital Physical Records Storage, 1 to Patient
  physicalDiagnosisReportArchived?: boolean;
  physicalDiagnosisReportGivenToPatient?: boolean;
  prescriptionId?: string;
  pharmacyPrescriptionId?: string;
  pharmacyDispensedAt?: string;
  invoiceId?: string;
  billingInvoiceId?: string;
  cashierClearedAt?: string;
  isOutpatientCleared?: boolean;
  isClearedOnSameDay?: boolean;
  stageHistory: Array<{
    stage: WorkflowStage;
    timestamp: string;
    actorName: string;
    actorRole: string;
    notes: string;
  }>;
}

// =========================================================================
// AI-POWERED CLINICAL TRIAGE & ICD-10 SPECIALIST GUIDELINES
// =========================================================================

export type TriageAcuityLevel = 
  | 'ESI_1_RESUSCITATION' 
  | 'ESI_2_EMERGENT' 
  | 'ESI_3_URGENT' 
  | 'ESI_4_SEMI_URGENT' 
  | 'ESI_5_NON_URGENT';

export interface Icd10Recommendation {
  code: string;
  name: string;
  category: string;
  confidenceScore: number; // e.g. 0.94
  clinicalRationale: string;
}

export interface TriageAssessment {
  id: string;
  timestamp: string;
  patientName: string;
  patientId?: string;
  patientAge: number;
  patientGender: 'Male' | 'Female' | 'Other';
  chiefComplaint: string;
  symptomDuration: string;
  vitalSigns?: {
    bloodPressure?: string;
    heartRate?: number;
    spo2?: number;
    temperature?: number;
    respiratoryRate?: number;
    painLevel?: number; // 0-10
  };
  knownAllergies?: string[];
  chronicConditions?: string[];
  
  // AI Clinical Output
  acuityLevel: TriageAcuityLevel;
  acuityTitle: string;
  recommendedDepartment: string;
  secondaryDepartment?: string;
  recommendedSpecialistName?: string;
  recommendedSpecialistRole?: string;
  
  primaryIcd10: Icd10Recommendation;
  secondaryIcd10List: Icd10Recommendation[];
  
  differentialDiagnoses: Array<{
    condition: string;
    icd10: string;
    probability: number;
    rationale: string;
  }>;
  
  redFlags: string[];
  immediateActionProtocols: string[];
  suggestedDiagnosticOrders: string[];
  clinicalSummary: string;
  guidelineReference: string;
  
  reviewedByStaff?: string;
  appliedToRegistration?: boolean;
}

// =========================================================================
// ADMINISTRATIVE DEPARTMENT BOTTLENECK & PATIENT LOAD TYPES
// =========================================================================

export type BottleneckSeverity = 'OPTIMAL' | 'MODERATE' | 'WARNING' | 'CRITICAL';

export interface DepartmentBottleneckMetrics {
  id: string;
  name: string;
  code: string;
  headOfDepartment: string;
  currentPatientLoad: number;
  capacityLimit: number;
  utilizationRate: number; // percentage
  averageWaitTimeMinutes: number;
  longestWaitTimeMinutes: number;
  pendingLabTestsCount: number;
  statLabTestsPending: number;
  averageLabTurnaroundMinutes: number;
  staffOnDutyCount: number;
  patientToStaffRatio: number;
  bottleneckSeverity: BottleneckSeverity;
  primaryBottleneckCause: string;
  recommendedMitigationActions: string[];
  bedOccupancyPercent?: number;
  dischargesPendingCount?: number;
  activeTriageQueueCount?: number;
  trend: 'INCREASING' | 'STABLE' | 'DECREASING';
}

export interface TelehealthSessionRecord {
  id: string;
  patientId: string;
  patientName: string;
  patientMrn: string;
  doctorId: string;
  doctorName: string;
  specialty: string;
  startTime: string;
  endTime?: string;
  durationMinutes: number;
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  encryptionProtocol: 'AES-256-GCM / WebRTC DTLS-SRTP 1.2';
  encryptionKeyFingerprint: string;
  soapNotes: {
    subjective: string;
    objective: string;
    assessment: string;
    plan: string;
  };
  prescriptionsIssued?: string[];
  followUpRecommended?: string;
  auditChecksum: string;
}


