/**
 * MediCore Health System - Universal Medical Printing Engine
 * Provides direct, seamless, and high-fidelity physical printer output
 * formatted for clinical documentation, HIPAA compliance, and thermal/laser printers.
 */

import { 
  Patient, 
  BillingInvoice, 
  LabOrder, 
  PharmacyPrescription, 
  Appointment, 
  TriageAssessment, 
  HipaaAuditLog, 
  User,
  VitalSign,
  Medication,
  ClinicalNote,
  LabResult
} from '../types';

/**
 * Universal print helper that prints any HTML content or DOM element directly to the printer
 * using an isolated print iframe, ensuring zero UI clutter, sidebars, or modal backgrounds.
 */
export function printHtmlDirectly(htmlContent: string, title = 'MediCore Health System - Clinical Document'): void {
  // Create an isolated hidden iframe
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = 'none';
  iframe.style.visibility = 'hidden';
  iframe.setAttribute('aria-hidden', 'true');
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) {
    // Fallback: direct window.print if iframe is blocked
    window.print();
    return;
  }

  const fullDocumentHtml = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${title}</title>
      <style>
        @page {
          size: letter portrait;
          margin: 12mm 15mm 12mm 15mm;
        }
        * {
          box-sizing: border-box;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
        }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
          font-size: 11pt;
          line-height: 1.45;
          color: #0f172a;
          background: #ffffff;
          margin: 0;
          padding: 0;
        }
        h1, h2, h3, h4, h5, h6 {
          color: #0f172a;
          margin-top: 0;
          font-weight: 800;
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          border-bottom: 2.5px solid #0f172a;
          padding-bottom: 12px;
          margin-bottom: 16px;
        }
        .header-title {
          font-size: 18pt;
          font-weight: 900;
          letter-spacing: -0.5px;
          color: #042f2e;
          margin-bottom: 2px;
        }
        .header-subtitle {
          font-size: 9.5pt;
          color: #475569;
          font-weight: 600;
        }
        .header-meta {
          text-align: right;
          font-size: 8.5pt;
          color: #334155;
        }
        .badge {
          display: inline-block;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 8pt;
          font-weight: 800;
          text-transform: uppercase;
          border: 1px solid #cbd5e1;
          background: #f8fafc;
        }
        .badge-hipaa {
          background: #ecfdf5;
          color: #065f46;
          border-color: #a7f3d0;
        }
        .badge-alert {
          background: #fff1f2;
          color: #9f1239;
          border-color: #fecdd3;
        }
        .badge-critical {
          background: #ffe4e6;
          color: #881337;
          border-color: #fda4af;
          font-weight: 900;
        }
        .grid-2 {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
          margin-bottom: 14px;
        }
        .grid-3 {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          gap: 10px;
          margin-bottom: 14px;
        }
        .grid-4 {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr 1fr;
          gap: 8px;
          margin-bottom: 14px;
        }
        .card {
          border: 1px solid #cbd5e1;
          border-radius: 8px;
          padding: 10px 12px;
          background: #f8fafc;
          margin-bottom: 12px;
          page-break-inside: avoid;
          break-inside: avoid;
        }
        .card-alert {
          background: #fff1f2;
          border-color: #fecdd3;
        }
        .label {
          font-size: 7.5pt;
          text-transform: uppercase;
          font-weight: 800;
          color: #64748b;
          margin-bottom: 2px;
          letter-spacing: 0.5px;
        }
        .value {
          font-size: 10pt;
          font-weight: 700;
          color: #0f172a;
        }
        .mono {
          font-family: 'Courier New', Courier, monospace;
          font-weight: 700;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 14px;
          font-size: 9pt;
          page-break-inside: avoid;
          break-inside: avoid;
        }
        th {
          background: #f1f5f9;
          border: 1px solid #cbd5e1;
          padding: 6px 8px;
          text-align: left;
          font-size: 8pt;
          font-weight: 800;
          color: #334155;
          text-transform: uppercase;
        }
        td {
          border: 1px solid #cbd5e1;
          padding: 6px 8px;
          vertical-align: top;
        }
        tr:nth-child(even) td {
          background: #f8fafc;
        }
        .section-title {
          font-size: 11pt;
          font-weight: 800;
          color: #0f172a;
          border-bottom: 1.5px solid #cbd5e1;
          padding-bottom: 4px;
          margin-top: 14px;
          margin-bottom: 8px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .footer {
          margin-top: 20px;
          border-top: 1.5px solid #cbd5e1;
          padding-top: 10px;
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          font-size: 8pt;
          color: #64748b;
          page-break-inside: avoid;
          break-inside: avoid;
        }
        .signature-line {
          width: 200px;
          border-bottom: 1px solid #0f172a;
          margin-top: 30px;
          margin-bottom: 4px;
        }
        .barcode-strip {
          font-family: 'Courier New', Courier, monospace;
          background: #0f172a;
          color: #ffffff;
          padding: 4px 10px;
          border-radius: 4px;
          display: inline-block;
          font-weight: 900;
          letter-spacing: 2px;
        }
      </style>
    </head>
    <body>
      ${htmlContent}
    </body>
    </html>
  `;

  doc.open();
  doc.write(fullDocumentHtml);
  doc.close();

  // Wait for rendering then trigger printer
  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (e) {
      console.warn('Iframe print failed, falling back to direct window.print:', e);
      window.print();
    } finally {
      // Clean up iframe after print dialog completes
      setTimeout(() => {
        if (iframe.parentNode) {
          iframe.parentNode.removeChild(iframe);
        }
      }, 3000);
    }
  }, 350);
}

/**
 * 1. Direct Print: Complete Patient EHR Medical Chart & Health Record
 */
export function printPatientCompleteRecord(patient: Patient, currentUser?: Partial<User> | null): void {
  const doctorName = currentUser?.name || 'Attending Physician';
  const doctorRole = currentUser?.role || 'PHYSICIAN';
  const orgName = currentUser?.organizationName || 'MEDICORE UNIVERSITY HEALTH SYSTEM';
  const now = new Date().toLocaleString();

  const vitals = patient.vitals || [];
  const meds = patient.medications || [];
  const notes = patient.clinicalNotes || [];
  const labs = patient.labResults || [];
  const allergies = patient.allergies || [];
  const chronic = patient.chronicConditions || patient.conditions || [];

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Department of Clinical Affairs • Complete Electronic Health Record (EHR)</div>
        <div style="font-size: 8pt; color: #64748b; margin-top: 2px;">
          75 Francis Street, Boston, MA 02115 • Tel: +1 (555) 720-4000 • HIPAA Certified
        </div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">HIPAA 256-Bit Encrypted</span>
        <div style="margin-top: 4px;"><strong>Printed:</strong> ${now}</div>
        <div><strong>MRN:</strong> <span class="mono">${patient.mrn}</span></div>
      </div>
    </div>

    <!-- Patient Demographics Banner -->
    <div class="card">
      <div class="grid-4">
        <div>
          <div class="label">Patient Name</div>
          <div class="value" style="font-size: 12pt;">${patient.name}</div>
        </div>
        <div>
          <div class="label">DOB / Age / Gender</div>
          <div class="value">${patient.dob || patient.dateOfBirth || 'N/A'} (${patient.age}y / ${patient.gender})</div>
        </div>
        <div>
          <div class="label">Blood Type</div>
          <div class="value" style="color: #be123c;">${patient.bloodType || 'N/A'}</div>
        </div>
        <div>
          <div class="label">Admission Status</div>
          <div class="value">${patient.admissionStatus} ${patient.assignedWard ? `(${patient.assignedWard})` : ''}</div>
        </div>
      </div>

      <div class="grid-3" style="margin-top: 8px; margin-bottom: 0; padding-top: 8px; border-top: 1px solid #e2e8f0;">
        <div>
          <div class="label">Primary Phone & Email</div>
          <div style="font-size: 9pt;">${patient.phone || 'N/A'} • ${patient.email || 'N/A'}</div>
        </div>
        <div>
          <div class="label">Health Insurance</div>
          <div style="font-size: 9pt;"><strong>${patient.insurance?.provider || 'Self-Pay'}</strong> (Policy: ${patient.insurance?.policyNumber || 'N/A'})</div>
        </div>
        <div>
          <div class="label">Emergency Contact</div>
          <div style="font-size: 9pt;">${patient.emergencyContact?.name || 'N/A'} (${patient.emergencyContact?.relationship || 'Next of Kin'}) • ${patient.emergencyContact?.phone || 'N/A'}</div>
        </div>
      </div>
    </div>

    <!-- Allergies Alert Box -->
    <div class="card card-alert">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
        <span class="label" style="color: #9f1239; font-weight: 900;">Documented Allergies & Drug Sensitivities:</span>
        <span class="badge badge-alert">${allergies.length} Recorded</span>
      </div>
      <div>
        ${allergies.length > 0 ? allergies.map(a => `
          <span style="display: inline-block; margin-right: 8px; margin-bottom: 4px; padding: 3px 8px; background: #ffffff; border: 1px solid #fca5a5; border-radius: 4px; font-size: 8.5pt;">
            <strong>${a.allergen}</strong> (${a.reaction} - <span style="color: #991b1b; font-weight: 800;">${a.severity}</span>)
          </span>
        `).join('') : '<span style="font-size: 9pt; color: #475569; font-style: italic;">No Known Drug Allergies (NKDA)</span>'}
      </div>
    </div>

    <!-- Active Diagnoses & Chronic Conditions -->
    <div class="section-title">Active Clinical Diagnoses & Chronic Conditions</div>
    <div style="margin-bottom: 12px; font-size: 9.5pt;">
      ${chronic.length > 0 ? chronic.map(c => `<div style="padding: 2px 0;">• <strong>${c}</strong></div>`).join('') : '<div>• General Evaluation / Routine Screening</div>'}
    </div>

    <!-- Latest Vital Signs History -->
    <div class="section-title">Biometric Vital Signs History</div>
    ${vitals.length > 0 ? `
      <table>
        <thead>
          <tr>
            <th>Date / Time</th>
            <th>BP (mmHg)</th>
            <th>Heart Rate</th>
            <th>Temp (°C)</th>
            <th>SpO2</th>
            <th>Resp Rate</th>
            <th>BMI / Wt / Ht</th>
            <th>Clinician</th>
          </tr>
        </thead>
        <tbody>
          ${vitals.slice(0, 5).map(v => `
            <tr>
              <td class="mono">${v.recordedAt}</td>
              <td class="mono" style="font-weight: 700;">${v.bloodPressure}</td>
              <td class="mono">${v.heartRate} bpm</td>
              <td class="mono">${v.temperature}°C</td>
              <td class="mono" style="color: #047857; font-weight: 700;">${v.spo2}%</td>
              <td class="mono">${v.respiratoryRate}/min</td>
              <td>${v.bmi} (${v.weightKg}kg / ${v.heightCm}cm)</td>
              <td style="font-size: 8pt;">${v.recordedBy}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : '<p style="font-size: 9pt; color: #64748b; font-style: italic;">No vitals recorded.</p>'}

    <!-- Active Pharmaceutical Regimen -->
    <div class="section-title">Active Pharmaceutical Prescriptions & Regimen</div>
    ${meds.length > 0 ? `
      <table>
        <thead>
          <tr>
            <th>Medication & Dosage</th>
            <th>Route & Frequency</th>
            <th>Prescribing Clinician</th>
            <th>Instructions</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${meds.map(m => `
            <tr>
              <td><strong>${m.name}</strong> <span class="badge">${m.dosage}</span></td>
              <td>${m.route} • ${m.frequency}</td>
              <td>${m.prescribingDoctor}</td>
              <td style="font-style: italic; font-size: 8.5pt;">${m.instructions}</td>
              <td><span class="badge" style="background: #ecfdf5; color: #065f46;">${m.active ? 'Active' : 'Completed'}</span></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : '<p style="font-size: 9pt; color: #64748b; font-style: italic;">No active prescriptions.</p>'}

    <!-- Diagnostic Lab Results -->
    <div class="section-title">Diagnostic Laboratory & Pathology Results</div>
    ${labs.length > 0 ? `
      <table>
        <thead>
          <tr>
            <th>Test Name</th>
            <th>Category</th>
            <th>Date</th>
            <th>Measured Value</th>
            <th>Reference Range</th>
            <th>Flag Status</th>
          </tr>
        </thead>
        <tbody>
          ${labs.map(l => `
            <tr>
              <td><strong>${l.testName}</strong></td>
              <td>${l.category}</td>
              <td class="mono">${l.date}</td>
              <td class="mono" style="font-weight: 800;">${l.resultValue} ${l.unit}</td>
              <td class="mono">${l.referenceRange}</td>
              <td>
                <span class="badge ${l.status === 'CRITICAL' ? 'badge-critical' : l.status === 'ABNORMAL' ? 'badge-alert' : 'badge-hipaa'}">
                  ${l.status}
                </span>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : '<p style="font-size: 9pt; color: #64748b; font-style: italic;">No lab diagnostics recorded.</p>'}

    <!-- Clinical SOAP Progress Notes -->
    <div class="section-title">Clinical Progress Notes & Physician Directives</div>
    ${notes.length > 0 ? notes.map(n => `
      <div class="card" style="margin-bottom: 8px;">
        <div style="display: flex; justify-content: space-between; font-size: 8.5pt; color: #475569; margin-bottom: 4px; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px;">
          <span><strong>${n.category}</strong> • ${n.authorName} (${n.authorRole})</span>
          <span class="mono">${n.date}</span>
        </div>
        <div style="font-size: 9pt; color: #1e293b; line-height: 1.4;">${n.content || n.note || 'No narrative body.'}</div>
        ${n.icdCodes && n.icdCodes.length > 0 ? `
          <div style="margin-top: 6px; font-size: 8pt;">
            <strong>ICD-10 Diagnoses:</strong> ${n.icdCodes.join(', ')}
          </div>
        ` : ''}
      </div>
    `).join('') : '<p style="font-size: 9pt; color: #64748b; font-style: italic;">No clinical notes recorded.</p>'}

    <!-- Official Physician Seal & Attestation -->
    <div class="footer">
      <div>
        <div><strong>Verifying Clinician:</strong> ${doctorName} (${doctorRole})</div>
        <div><strong>Record Hash:</strong> <span class="mono">SHA256:${Array.from({ length: 24 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}</span></div>
        <div style="margin-top: 4px;">MediCore Certified Clinical EHR Record • Valid for Official Referral & Legal Medical Vault</div>
      </div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Attending Clinician Signature & Date</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `EHR_Chart_${patient.mrn}_${patient.name.replace(/\s+/g, '_')}`);
}

/**
 * 2. Direct Print: Physician Consultation & SOAP Referral Summary
 */
export function printConsultationSummary(patient: Patient, currentUser?: Partial<User> | null): void {
  printPatientCompleteRecord(patient, currentUser);
}

/**
 * 2b. Direct Print: Vital Signs Flowsheet specifically
 */
export function printVitalFlowsheet(patient: Patient, currentUserOrVitals?: Partial<User> | VitalSign[] | null, specificVitals?: VitalSign[]): void {
  let orgName = 'MEDICORE UNIVERSITY HEALTH SYSTEM';
  let vitals = patient.vitals || [];

  if (Array.isArray(currentUserOrVitals)) {
    vitals = currentUserOrVitals;
  } else if (currentUserOrVitals && typeof currentUserOrVitals === 'object') {
    orgName = currentUserOrVitals.organizationName || orgName;
  }

  if (specificVitals && Array.isArray(specificVitals)) {
    vitals = specificVitals;
  }

  const now = new Date().toLocaleString();

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Department of Clinical Nursing • Biometric Vital Signs & Telemetry Flowsheet</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">Telemetry Verified</span>
        <div style="margin-top: 4px;"><strong>Printed:</strong> ${now}</div>
        <div><strong>MRN:</strong> <span class="mono">${patient.mrn}</span></div>
      </div>
    </div>

    <div class="card">
      <div class="grid-3">
        <div>
          <div class="label">Patient Name</div>
          <div class="value">${patient.name}</div>
        </div>
        <div>
          <div class="label">Age / Gender / Blood</div>
          <div class="value">${patient.age}y / ${patient.gender} / ${patient.bloodType || 'N/A'}</div>
        </div>
        <div>
          <div class="label">Ward / Bed</div>
          <div class="value">${patient.assignedWard || 'Outpatient'} ${patient.assignedBed ? `(${patient.assignedBed})` : ''}</div>
        </div>
      </div>
    </div>

    <div class="section-title">Recorded Biometric Parameters History</div>
    ${vitals.length > 0 ? `
      <table>
        <thead>
          <tr>
            <th>Date & Time</th>
            <th>BP (mmHg)</th>
            <th>HR (bpm)</th>
            <th>Temp (°C)</th>
            <th>SpO2 (%)</th>
            <th>Resp (/min)</th>
            <th>Height & Weight</th>
            <th>BMI</th>
            <th>Recorded By</th>
          </tr>
        </thead>
        <tbody>
          ${vitals.map(v => `
            <tr>
              <td class="mono">${v.recordedAt}</td>
              <td class="mono font-bold">${v.bloodPressure}</td>
              <td class="mono">${v.heartRate}</td>
              <td class="mono">${v.temperature}°C</td>
              <td class="mono font-bold" style="color: #047857;">${v.spo2}%</td>
              <td class="mono">${v.respiratoryRate}</td>
              <td>${v.heightCm} cm / ${v.weightKg} kg</td>
              <td class="mono">${v.bmi}</td>
              <td>${v.recordedBy}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : '<p>No vitals recorded.</p>'}

    <div class="footer">
      <div>Clinical Telemetry Records Center</div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Nurse Supervisor Verification</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `Vitals_Flowsheet_${patient.mrn}`);
}

/**
 * 2c. Direct Print: Clinical SOAP Progress Notes specifically
 */
export function printClinicalSOAPNotes(patient: Patient, currentUserOrNotes?: Partial<User> | ClinicalNote[] | null, specificNotes?: ClinicalNote[]): void {
  let orgName = 'MEDICORE UNIVERSITY HEALTH SYSTEM';
  let notes = patient.clinicalNotes || [];

  if (Array.isArray(currentUserOrNotes)) {
    notes = currentUserOrNotes;
  } else if (currentUserOrNotes && typeof currentUserOrNotes === 'object') {
    orgName = currentUserOrNotes.organizationName || orgName;
  }

  if (specificNotes && Array.isArray(specificNotes)) {
    notes = specificNotes;
  }

  const now = new Date().toLocaleString();

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Division of Clinical Documentation • Physician SOAP Notes & Progress Reports</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">Physician Attested</span>
        <div style="margin-top: 4px;"><strong>Printed:</strong> ${now}</div>
        <div><strong>MRN:</strong> <span class="mono">${patient.mrn}</span></div>
      </div>
    </div>

    <div class="card">
      <div class="grid-3">
        <div>
          <div class="label">Patient Name</div>
          <div class="value">${patient.name}</div>
        </div>
        <div>
          <div class="label">MRN / DOB</div>
          <div class="value mono">${patient.mrn} (${patient.dob || 'N/A'})</div>
        </div>
        <div>
          <div class="label">Primary Diagnosis</div>
          <div class="value">${(patient.chronicConditions || patient.conditions || [])[0] || 'Clinical Evaluation'}</div>
        </div>
      </div>
    </div>

    <div class="section-title">Physician Clinical Progress Notes Archive</div>
    ${notes.length > 0 ? notes.map(n => `
      <div class="card" style="margin-bottom: 12px;">
        <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 6px;">
          <strong style="color: #042f2e;">${n.category} • ${n.authorName} (${n.authorRole})</strong>
          <span class="mono" style="font-size: 8.5pt;">${n.date}</span>
        </div>
        <p style="font-size: 9.5pt; line-height: 1.5; white-space: pre-wrap; margin: 0;">${n.content || n.note || 'No narrative.'}</p>
        ${n.icdCodes && n.icdCodes.length > 0 ? `
          <div style="margin-top: 8px; font-size: 8.5pt;">
            <strong>Associated ICD-10 Diagnostic Codes:</strong> ${n.icdCodes.join(', ')}
          </div>
        ` : ''}
      </div>
    `).join('') : '<p>No progress notes recorded.</p>'}

    <div class="footer">
      <div>Official Legal Medical Health Record • Retain for Medical Vault</div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Attending Clinician Signature</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `SOAP_Notes_${patient.mrn}`);
}

/**
 * 2d. Direct Print: Patient Prescription Rx Form
 */
export function printPrescriptionRx(patient: Patient, currentUserOrMeds?: Partial<User> | Medication[] | null, specificMeds?: Medication[]): void {
  let orgName = 'MEDICORE UNIVERSITY HEALTH SYSTEM';
  let doctorName = 'Dr. Evelyn Vance, MD';
  let meds = patient.medications || [];

  if (Array.isArray(currentUserOrMeds)) {
    meds = currentUserOrMeds;
  } else if (currentUserOrMeds && typeof currentUserOrMeds === 'object') {
    orgName = currentUserOrMeds.organizationName || orgName;
    doctorName = currentUserOrMeds.name || doctorName;
  }

  if (specificMeds && Array.isArray(specificMeds)) {
    meds = specificMeds;
  }

  const now = new Date().toLocaleString();

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Division of Outpatient Pharmacy & Pharmacotherapy • Official Rx Order</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">DEA / NPI Verified</span>
        <div style="margin-top: 4px;"><strong>Date:</strong> ${now}</div>
        <div><strong>MRN:</strong> <span class="mono">${patient.mrn}</span></div>
      </div>
    </div>

    <div class="card">
      <div class="grid-3">
        <div>
          <div class="label">Patient Legal Name</div>
          <div class="value">${patient.name}</div>
        </div>
        <div>
          <div class="label">DOB / Age / Gender</div>
          <div class="value">${patient.dob || 'N/A'} (${patient.age}y / ${patient.gender})</div>
        </div>
        <div>
          <div class="label">Allergies (Contraindication Check)</div>
          <div class="value" style="color: #991b1b;">${(patient.allergies || []).map(a => a.allergen).join(', ') || 'NKDA'}</div>
        </div>
      </div>
    </div>

    <div class="section-title">Prescribed Pharmaceutical Regimen (Rx)</div>
    <table>
      <thead>
        <tr>
          <th>Medication Name</th>
          <th>Dosage</th>
          <th>Route & Frequency</th>
          <th>Instructions for Patient</th>
          <th>Prescriber</th>
        </tr>
      </thead>
      <tbody>
        ${meds.map(m => `
          <tr>
            <td><strong>${m.name}</strong></td>
            <td class="mono font-bold">${m.dosage}</td>
            <td>${m.route} • ${m.frequency}</td>
            <td style="font-style: italic;">${m.instructions}</td>
            <td>${m.prescribingDoctor || doctorName}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="card" style="text-align: center; margin-top: 16px;">
      <div class="barcode-strip" style="font-size: 13pt;">*RX-${patient.mrn}-${new Date().getFullYear()}*</div>
      <div style="font-size: 8pt; color: #64748b; margin-top: 4px;">Present at participating institutional or retail pharmacy</div>
    </div>

    <div class="footer">
      <div>
        <div><strong>Prescribing Physician:</strong> ${doctorName}</div>
        <div>License: NPI #1982049210 • DEA: MB8291044</div>
      </div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Physician Authorized Signature</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `Prescription_Rx_${patient.mrn}`);
}

/**
 * 2e. Direct Print: Patient Lab History & Diagnostics Flowsheet
 */
export function printPatientLabHistory(patient: Patient, currentUserOrLabs?: Partial<User> | LabResult[] | null, specificLabs?: LabResult[]): void {
  let orgName = 'MEDICORE DIAGNOSTIC PATHOLOGY ENCLAVE';
  let labs = patient.labResults || [];

  if (Array.isArray(currentUserOrLabs)) {
    labs = currentUserOrLabs;
  } else if (currentUserOrLabs && typeof currentUserOrLabs === 'object') {
    orgName = currentUserOrLabs.organizationName || orgName;
  }

  if (specificLabs && Array.isArray(specificLabs)) {
    labs = specificLabs;
  }

  const now = new Date().toLocaleString();

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Diagnostic Pathology & Laboratory Panel Cumulative Report</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">CLIA & CAP Validated</span>
        <div style="margin-top: 4px;"><strong>Printed:</strong> ${now}</div>
        <div><strong>MRN:</strong> <span class="mono">${patient.mrn}</span></div>
      </div>
    </div>

    <div class="card">
      <div class="grid-3">
        <div>
          <div class="label">Patient Name</div>
          <div class="value">${patient.name}</div>
        </div>
        <div>
          <div class="label">MRN / DOB</div>
          <div class="value mono">${patient.mrn} (${patient.dob || 'N/A'})</div>
        </div>
        <div>
          <div class="label">Admission Status</div>
          <div class="value">${patient.admissionStatus} ${patient.assignedWard ? `(${patient.assignedWard})` : ''}</div>
        </div>
      </div>
    </div>

    <div class="section-title">Cumulative Laboratory Diagnostic Results</div>
    ${labs.length > 0 ? `
      <table>
        <thead>
          <tr>
            <th>Test Name</th>
            <th>Category</th>
            <th>Date</th>
            <th>Result Value</th>
            <th>Reference Range</th>
            <th>Flag Status</th>
          </tr>
        </thead>
        <tbody>
          ${labs.map(l => `
            <tr>
              <td><strong>${l.testName}</strong></td>
              <td>${l.category}</td>
              <td class="mono">${l.date}</td>
              <td class="mono" style="font-weight: 800;">${l.resultValue} ${l.unit}</td>
              <td class="mono">${l.referenceRange}</td>
              <td>
                <span class="badge ${l.status === 'CRITICAL' ? 'badge-critical' : l.status === 'ABNORMAL' ? 'badge-alert' : 'badge-hipaa'}">
                  ${l.status}
                </span>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : '<p>No laboratory diagnostics recorded.</p>'}

    <div class="footer">
      <div>Validated under CLIA Quality Control Regulations</div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Pathology Director Sign-off</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `Lab_History_${patient.mrn}`);
}

/**
 * 3. Direct Print: Diagnostic Laboratory Results & Order Requisition
 */
export function printLabOrderRequisition(labOrderOrPatient: LabOrder | Patient, patientOrLabs?: Patient | LabResult[] | null, currentUser?: Partial<User> | null): void {
  // If called with (patient, labs), route to printPatientLabHistory
  if ('admissionStatus' in labOrderOrPatient || ('mrn' in labOrderOrPatient && !('tests' in labOrderOrPatient) && !('orderNumber' in labOrderOrPatient))) {
    printPatientLabHistory(labOrderOrPatient as Patient, patientOrLabs as any, undefined);
    return;
  }

  const labOrder = labOrderOrPatient as LabOrder;
  const now = new Date().toLocaleString();
  const orgName = currentUser?.organizationName || 'MEDICORE DIAGNOSTIC PATHOLOGY ENCLAVE';
  const orderIdentifier = labOrder.orderNumber || labOrder.id;

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Clinical Laboratory & Diagnostic Pathology Services • CLIA #22D991048</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">CLIA & CAP Validated</span>
        <div style="margin-top: 4px;"><strong>Order ID:</strong> <span class="mono">${orderIdentifier}</span></div>
        <div><strong>Priority:</strong> <span class="badge ${labOrder.priority === 'STAT' ? 'badge-critical' : 'badge-hipaa'}">${labOrder.priority}</span></div>
      </div>
    </div>

    <!-- Patient Header -->
    <div class="card">
      <div class="grid-4">
        <div>
          <div class="label">Patient Name</div>
          <div class="value">${labOrder.patientName}</div>
        </div>
        <div>
          <div class="label">MRN</div>
          <div class="value mono">${labOrder.patientMrn}</div>
        </div>
        <div>
          <div class="label">Ordering Physician</div>
          <div class="value">${labOrder.orderingDoctorName || (labOrder as any).doctorName || 'Staff Physician'}</div>
        </div>
        <div>
          <div class="label">Clinical Department</div>
          <div class="value">${labOrder.orderingDoctorSpecialty || 'Diagnostics & Pathology'}</div>
        </div>
      </div>
      <div style="margin-top: 6px; font-size: 9pt; color: #334155;">
        <strong>Clinical Indication / Diagnosis:</strong> ${labOrder.clinicalIndication || 'Diagnostic Investigation'}
      </div>
    </div>

    <!-- Specimen Barcode & Chain of Custody -->
    <div class="card" style="display: flex; justify-content: space-between; align-items: center;">
      <div>
        <div class="label">Specimen Barcode & Lot</div>
        <div class="barcode-strip">SPEC-${orderIdentifier}-${labOrder.patientMrn.slice(-4)}</div>
      </div>
      <div style="text-align: right; font-size: 8.5pt;">
        <div><strong>Collection Date:</strong> ${labOrder.sampleCollectionTime || (labOrder as any).collectedAt || now}</div>
        <div><strong>Status:</strong> <span class="badge">${labOrder.status}</span></div>
      </div>
    </div>

    <!-- Ordered Diagnostic Tests & Values -->
    <div class="section-title">Diagnostic Test Battery & Results</div>
    <table>
      <thead>
        <tr>
          <th>Test Code</th>
          <th>Test Name & Description</th>
          <th>Result Value</th>
          <th>Units</th>
          <th>Reference Range</th>
          <th>Status Flag</th>
        </tr>
      </thead>
      <tbody>
        ${(labOrder.tests || []).map(t => `
          <tr>
            <td class="mono"><strong>${t.testCode || (t as any).code || '-'}</strong></td>
            <td>${t.testName}</td>
            <td class="mono" style="font-weight: 800;">${t.resultValue || 'PENDING'}</td>
            <td>${t.unit || '-'}</td>
            <td class="mono">${t.referenceRange || (t as any).normalRange || 'Standard'}</td>
            <td>
              <span class="badge ${t.status === 'CRITICAL' ? 'badge-critical' : t.status === 'ABNORMAL' ? 'badge-alert' : t.status === 'NORMAL' ? 'badge-hipaa' : ''}">
                ${t.status || 'ORDERED'}
              </span>
            </td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    ${labOrder.technicianNotes ? `
      <div class="card">
        <div class="label">Pathologist / Lab Technologist Interpretation:</div>
        <div style="font-size: 9pt; color: #0f172a;">${labOrder.technicianNotes}</div>
      </div>
    ` : ''}

    <div class="footer">
      <div>
        <div><strong>Validated By:</strong> ${labOrder.technicianName || 'David Okafor, MLS (ASCP)'}</div>
        <div>Automated LIS Interfacing • Certified Diagnostic Result</div>
      </div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Pathology Director Sign-off</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `Lab_Report_${orderIdentifier}_${labOrder.patientMrn}`);
}

/**
 * 4. Direct Print: Pharmacy E-Prescription & Barcode Administration Label
 */
export function printPharmacyPrescription(rx: PharmacyPrescription, patient?: Patient, currentUser?: Partial<User> | null): void {
  const orgName = currentUser?.organizationName || 'MEDICORE CENTRAL PHARMACY & DISPENSARY';
  const issueDateStr = rx.issueDate || (rx as any).issuedDate || new Date().toLocaleDateString();
  const prescriber = rx.prescribingDoctorName || (rx as any).doctorName || 'Attending Physician';
  const pharmacist = rx.dispensedBy || (rx as any).dispensedByPharmacistName || 'Dr. Maya Lin, PharmD, RPh';

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Institutional Pharmacy & Dispensing Services • DEA / NABP Verified</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">E-Prescription #${rx.rxNumber || rx.id}</span>
        <div style="margin-top: 4px;"><strong>Issued:</strong> ${issueDateStr}</div>
        <div><strong>Priority:</strong> <span class="badge">${rx.priority || 'ROUTINE'}</span></div>
      </div>
    </div>

    <!-- Patient Header -->
    <div class="card">
      <div class="grid-3">
        <div>
          <div class="label">Patient Full Name</div>
          <div class="value">${rx.patientName}</div>
        </div>
        <div>
          <div class="label">MRN / ID</div>
          <div class="value mono">${rx.patientMrn}</div>
        </div>
        <div>
          <div class="label">Prescribing Physician</div>
          <div class="value">${prescriber}</div>
        </div>
      </div>
      <div style="margin-top: 6px; font-size: 9pt; color: #334155;">
        <strong>Diagnosis Reference:</strong> ${rx.diagnosisReference || 'Prescription Order'}
      </div>
    </div>

    <!-- Prescribed Medications Table -->
    <div class="section-title">Authorized Pharmaceutical Items (Rx)</div>
    <table>
      <thead>
        <tr>
          <th>Medication Name</th>
          <th>Dosage / Form</th>
          <th>Route & Frequency</th>
          <th>Qty / Days</th>
          <th>Patient Instructions (SIG)</th>
          <th>Barcode Key</th>
        </tr>
      </thead>
      <tbody>
        ${(rx.items || []).map(item => `
          <tr>
            <td><strong>${item.name || (item as any).medicationName}</strong></td>
            <td>${item.dosage} (${item.form || 'Tablet'})</td>
            <td>${item.route} • ${item.frequency}</td>
            <td>${item.quantity} Qty (${item.daysSupply} days)</td>
            <td style="font-size: 8.5pt; font-style: italic;">${item.instructions}</td>
            <td class="mono" style="font-size: 8pt;">${item.barcode || 'MED-AUTO'}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <!-- Barcode for BCMA Scanning -->
    <div class="card" style="text-align: center; padding: 16px;">
      <div class="label" style="margin-bottom: 6px;">Bedside Barcode Medication Administration (BCMA) Optical Validation Key</div>
      <div class="barcode-strip" style="font-size: 14pt; padding: 8px 18px;">
        *RX-${rx.rxNumber || rx.id}-${rx.patientMrn}*
      </div>
      <div style="font-size: 8pt; color: #64748b; margin-top: 6px;">
        Nurse must scan patient wristband and this medication barcode before administration.
      </div>
    </div>

    <div class="footer">
      <div>
        <div><strong>Dispensing Pharmacist:</strong> ${pharmacist}</div>
        <div>Verified for Drug-Drug Interactions & Allergy Contraindications</div>
      </div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Pharmacist Verification Signature</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `Prescription_${rx.rxNumber || rx.id}_${rx.patientMrn}`);
}

/**
 * 5. Direct Print: Patient Billing Superbill & Payment Statement
 */
export function printBillingInvoiceDocument(inv: BillingInvoice, currentUser?: Partial<User> | null): void {
  const orgName = currentUser?.organizationName || 'MEDICORE UNIVERSITY HEALTH SYSTEM';

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Patient Financial Services & Clinical Billing Statement</div>
      </div>
      <div class="header-meta">
        <span class="badge ${inv.status === 'Paid' ? 'badge-hipaa' : 'badge-alert'}">Status: ${inv.status.replace('_', ' ')}</span>
        <div style="margin-top: 4px;"><strong>Invoice #:</strong> <span class="mono">${inv.invoiceNumber}</span></div>
        <div><strong>Issued:</strong> ${inv.issueDate} • <strong>Due:</strong> ${inv.dueDate}</div>
      </div>
    </div>

    <!-- Patient & Insurance Box -->
    <div class="card">
      <div class="grid-2">
        <div>
          <div class="label">Billed Patient</div>
          <div class="value" style="font-size: 11pt;">${inv.patientName}</div>
          <div class="mono" style="font-size: 8.5pt; color: #475569;">MRN: ${inv.patientMrn}</div>
        </div>
        <div>
          <div class="label">Primary Payer / Method</div>
          <div class="value">${inv.paymentMethod || 'Insurance Direct EDI'}</div>
          <div style="font-size: 8.5pt; color: #475569;">EDI Claim ID: <span class="mono">${inv.claimId || 'CLM-AUTO-882'}</span></div>
        </div>
      </div>
    </div>

    <!-- Itemized Clinical Procedures Table -->
    <div class="section-title">Itemized Clinical Services & CPT Procedures</div>
    <table>
      <thead>
        <tr>
          <th>CPT Code</th>
          <th>Description</th>
          <th>Category</th>
          <th>Qty</th>
          <th>Unit Price</th>
          <th style="text-align: right;">Total Price</th>
        </tr>
      </thead>
      <tbody>
        ${(inv.items || []).map(item => `
          <tr>
            <td class="mono"><strong>${item.code}</strong></td>
            <td>${item.description}</td>
            <td>${item.category}</td>
            <td>${item.quantity}</td>
            <td class="mono">$${(item.unitPrice || 0).toFixed(2)}</td>
            <td class="mono" style="text-align: right; font-weight: 700;">$${(item.totalPrice || 0).toFixed(2)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <!-- Financial Breakdown Card -->
    <div style="display: flex; justify-content: flex-end; margin-top: 12px;">
      <div style="width: 320px;" class="card">
        <div style="display: flex; justify-content: space-between; padding: 3px 0; font-size: 9pt;">
          <span>Gross Clinical Subtotal:</span>
          <span class="mono font-bold">$${(inv.subtotal || 0).toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 3px 0; font-size: 9pt; color: #047857;">
          <span>Insurance Coverage (${Math.round((inv.insuranceCoverageRate || 0.8) * 100)}%):</span>
          <span class="mono font-bold">-$${(inv.insurancePortion || 0).toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 3px 0; font-size: 9pt;">
          <span>Patient Standard Copay:</span>
          <span class="mono font-bold">$${(inv.patientCopay || 25).toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 3px 0; font-size: 9pt; color: #047857;">
          <span>Amount Paid to Date:</span>
          <span class="mono font-bold">-$${(inv.patientAmountPaid || 0).toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 6px 0; margin-top: 6px; border-top: 2px solid #0f172a; font-size: 11pt; font-weight: 900;">
          <span>Total Balance Due:</span>
          <span class="mono" style="color: #0f172a;">$${(inv.totalDue || 0).toFixed(2)}</span>
        </div>
      </div>
    </div>

    <div class="footer">
      <div>
        <div>Questions? Contact Hospital Billing Office: (555) 720-4100</div>
        <div>Official Healthcare Superbill • Form CMS-1500 / UB-04 Compliant</div>
      </div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Authorized Patient Accounting Officer</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `Invoice_${inv.invoiceNumber}_${inv.patientMrn}`);
}

/**
 * 6. Direct Print: Specialist Appointment Confirmation & Referral Pass
 */
export function printAppointmentSlip(apt: Appointment, currentUser?: Partial<User> | null): void {
  const orgName = currentUser?.organizationName || 'MEDICORE HEALTH SYSTEM';

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">Patient Appointment Slip & Specialist Referral Check-in Pass</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">Status: ${apt.status}</span>
        <div style="margin-top: 4px;"><strong>Apt #:</strong> <span class="mono">${apt.id}</span></div>
      </div>
    </div>

    <div class="card">
      <div class="grid-2">
        <div>
          <div class="label">Patient Name</div>
          <div class="value" style="font-size: 12pt;">${apt.patientName}</div>
          <div class="mono" style="font-size: 9pt; color: #475569;">MRN: ${apt.patientMrn}</div>
        </div>
        <div>
          <div class="label">Date & Time</div>
          <div class="value" style="font-size: 12pt; color: #042f2e;">${apt.date} at ${apt.time}</div>
          <div style="font-size: 8.5pt; color: #475569;">Duration: ${apt.durationMinutes || 30} mins</div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="grid-3">
        <div>
          <div class="label">Attending Specialist</div>
          <div class="value">${apt.doctorName}</div>
          <div style="font-size: 8.5pt; color: #475569;">${apt.doctorSpecialty || 'Clinical Specialist'}</div>
        </div>
        <div>
          <div class="label">Location / Department</div>
          <div class="value">${apt.department || 'Outpatient Clinic'}</div>
          <div style="font-size: 8.5pt; color: #475569;">${apt.roomNumber ? `Room / Suite: ${apt.roomNumber}` : 'Main Floor'}</div>
        </div>
        <div>
          <div class="label">Appointment Category</div>
          <div class="value">${apt.type}</div>
        </div>
      </div>
      <div style="margin-top: 8px; font-size: 9pt; color: #1e293b; border-top: 1px solid #e2e8f0; padding-top: 6px;">
        <strong>Reason for Consultation / Notes:</strong> ${apt.reasonForVisit || 'Routine Clinical Follow-up'}
      </div>
    </div>

    <div class="card" style="text-align: center; padding: 12px;">
      <div class="label">Express Fast-Track Optical Check-in Code</div>
      <div class="barcode-strip" style="font-size: 12pt; margin-top: 4px;">*APT-${apt.id}-${apt.patientMrn}*</div>
      <div style="font-size: 8pt; color: #64748b; margin-top: 4px;">Present this slip at reception kiosk upon arrival.</div>
    </div>

    <div class="footer">
      <div>Please arrive 15 minutes prior to your scheduled consultation time.</div>
      <div style="font-weight: 700;">MediCore Patient Scheduling Center</div>
    </div>
  `;

  printHtmlDirectly(html, `Appointment_${apt.id}_${apt.patientMrn}`);
}

/**
 * 7. Direct Print: Inpatient Identification Wristband & Bedside Chart
 */
export function printPatientWristbandAndChart(patient: Patient, wardName = 'Inpatient Medical Wing', bedNumber = 'Bed 101'): void {
  const html = `
    <div style="border: 2px dashed #0f172a; padding: 14px; border-radius: 8px; margin-bottom: 20px; background: #f8fafc;">
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1.5px solid #0f172a; padding-bottom: 6px; margin-bottom: 8px;">
        <div>
          <span style="font-weight: 900; font-size: 11pt; letter-spacing: 1px;">PATIENT IDENTIFICATION WRISTBAND (BCMA)</span>
        </div>
        <div>
          <span class="badge badge-critical">ALLERGIES: ${(patient.allergies || []).map(a => a.allergen).join(', ') || 'NKDA'}</span>
        </div>
      </div>

      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div style="font-size: 14pt; font-weight: 900;">${patient.name}</div>
          <div style="font-size: 9pt;">DOB: <strong>${patient.dob || patient.dateOfBirth || 'N/A'}</strong> (${patient.age}y / ${patient.gender}) • Blood: <strong style="color: #be123c;">${patient.bloodType}</strong></div>
          <div style="font-size: 9pt;">Ward: <strong>${wardName}</strong> • Bed: <strong>${bedNumber}</strong></div>
        </div>
        <div style="text-align: right;">
          <div class="barcode-strip" style="font-size: 13pt;">*${patient.mrn}*</div>
          <div style="font-size: 8pt; font-weight: 800; margin-top: 2px;">MRN: ${patient.mrn}</div>
        </div>
      </div>
    </div>

    <!-- Bedside Clinical Overview -->
    <div class="header">
      <div>
        <div class="header-title">MEDICORE HEALTH SYSTEM</div>
        <div class="header-subtitle">Inpatient Bedside Clinical Chart • ${wardName} (${bedNumber})</div>
      </div>
      <div class="header-meta">
        <div><strong>Admitted:</strong> ${patient.admissionDate || new Date().toISOString().slice(0, 10)}</div>
        <div><strong>MRN:</strong> <span class="mono">${patient.mrn}</span></div>
      </div>
    </div>

    <div class="card">
      <div class="label">Primary Diagnoses</div>
      <div><strong>${(patient.chronicConditions || patient.conditions || []).join(' • ') || 'Acute Inpatient Observation'}</strong></div>
    </div>

    <div class="footer">
      <div>Keep this chart mounted at patient bedside.</div>
      <div>Inpatient Care Quality & Safety Board</div>
    </div>
  `;

  printHtmlDirectly(html, `Wristband_Chart_${patient.mrn}`);
}

/**
 * 8. Direct Print: AI Clinical Triage & ICD-10 Specialist Report
 */
export function printTriageAssessmentReport(triage: TriageAssessment, currentUser?: Partial<User> | null): void {
  const orgName = currentUser?.organizationName || 'MEDICORE CLINICAL EMERGENCY & TRIAGE ENCLAVE';

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">AI-Assisted Emergency Triage & ICD-10 Specialist Direction Report</div>
      </div>
      <div class="header-meta">
        <span class="badge ${triage.acuityLevel === 'ESI_1_RESUSCITATION' || triage.acuityLevel === 'ESI_2_EMERGENT' ? 'badge-critical' : 'badge-hipaa'}">
          ${triage.acuityTitle} (${triage.acuityLevel})
        </span>
        <div style="margin-top: 4px;"><strong>Assessment ID:</strong> <span class="mono">${triage.id}</span></div>
        <div><strong>Evaluated:</strong> ${triage.timestamp}</div>
      </div>
    </div>

    <div class="card">
      <div class="grid-3">
        <div>
          <div class="label">Patient Name</div>
          <div class="value">${triage.patientName}</div>
        </div>
        <div>
          <div class="label">Age & Gender</div>
          <div class="value">${triage.patientAge} yrs • ${triage.patientGender}</div>
        </div>
        <div>
          <div class="label">Recommended Specialist</div>
          <div class="value" style="color: #042f2e;">${triage.recommendedSpecialistName || triage.recommendedDepartment}</div>
        </div>
      </div>
      <div style="margin-top: 8px; font-size: 9pt; border-top: 1px solid #e2e8f0; padding-top: 6px;">
        <strong>Chief Complaint:</strong> ${triage.chiefComplaint} (${triage.symptomDuration})
      </div>
    </div>

    <div class="section-title">Predicted Differential Diagnoses & ICD-10 Codes</div>
    <table>
      <thead>
        <tr>
          <th>ICD-10 Code</th>
          <th>Condition Name</th>
          <th>Clinical Probability</th>
          <th>Risk Rationale</th>
        </tr>
      </thead>
      <tbody>
        ${(triage.differentialDiagnoses || []).map(c => `
          <tr>
            <td class="mono"><strong>${c.icd10}</strong></td>
            <td><strong>${c.condition}</strong></td>
            <td class="mono font-bold">${Math.round(c.probability * 100)}%</td>
            <td style="font-size: 8.5pt;">${c.rationale}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="section-title">Recommended STAT Clinical Diagnostics</div>
    <div style="font-size: 9pt; margin-bottom: 10px;">
      ${(triage.suggestedDiagnosticOrders || []).map(t => `<span class="badge" style="margin-right: 6px; margin-bottom: 4px;">${t}</span>`).join('')}
    </div>

    <div class="card">
      <div class="label">Clinical Triage Summary & Recommendations</div>
      <div style="font-size: 9pt; line-height: 1.45; color: #0f172a;">${triage.clinicalSummary}</div>
      ${triage.redFlags && triage.redFlags.length > 0 ? `
        <div style="margin-top: 8px; color: #991b1b; font-size: 8.5pt;">
          <strong>RED FLAGS / ALERT CRITERIA:</strong> ${triage.redFlags.join(' • ')}
        </div>
      ` : ''}
    </div>

    <div class="footer">
      <div>AI Clinical Decision Support verified under Attending Physician Supervision</div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Triage Officer Signature</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `Triage_Report_${triage.id}_${triage.patientName.replace(/\s+/g, '_')}`);
}

/**
 * 9. Direct Print: HIPAA Compliance & Security Audit Incident Certificate
 */
export function printHipaaAuditReport(auditLogs: HipaaAuditLog[], filter = 'All Records', currentUser?: Partial<User> | null): void {
  const orgName = currentUser?.organizationName || 'MEDICORE HEALTH SECURITY & COMPLIANCE OFFICE';
  const now = new Date().toLocaleString();

  const html = `
    <div class="header">
      <div>
        <div class="header-title">${orgName}</div>
        <div class="header-subtitle">HIPAA HITECH 256-Bit Immutable Audit Trail & Access Certificate</div>
      </div>
      <div class="header-meta">
        <span class="badge badge-hipaa">Certified Encrypted</span>
        <div style="margin-top: 4px;"><strong>Generated:</strong> ${now}</div>
        <div><strong>Scope:</strong> ${filter} (${auditLogs.length} Events)</div>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>Timestamp</th>
          <th>Staff Actor</th>
          <th>Role</th>
          <th>Action Type</th>
          <th>Patient Reference</th>
          <th>Details & Cryptographic Checksum</th>
        </tr>
      </thead>
      <tbody>
        ${auditLogs.slice(0, 35).map(log => `
          <tr>
            <td class="mono" style="font-size: 8pt;">${log.timestamp}</td>
            <td><strong>${log.actorName}</strong></td>
            <td>${log.actorRole}</td>
            <td><span class="badge ${log.isGlassBreak ? 'badge-critical' : ''}">${log.action}</span></td>
            <td>${log.patientName ? `${log.patientName} (${log.patientId})` : '-'}</td>
            <td style="font-size: 8pt;">
              ${log.details}
              <div class="mono" style="color: #64748b; font-size: 7pt; margin-top: 2px;">Hash: ${log.checksumHash.slice(0, 20)}...</div>
            </td>
          </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="footer">
      <div>National Institute of Standards & Technology (NIST) SP 800-66 Rev 2 Audit Standard</div>
      <div style="text-align: right;">
        <div class="signature-line"></div>
        <div style="font-size: 8pt; font-weight: 700;">Chief Information Security Officer (CISO)</div>
      </div>
    </div>
  `;

  printHtmlDirectly(html, `HIPAA_Audit_Report_${new Date().toISOString().slice(0, 10)}`);
}

/**
 * 10. Direct Print: Batch Multi-Patient Clinical Summaries & Administrative Census Dossier
 * Allows administrators and clinicians to batch-print comprehensive clinical summaries
 * for multiple selected patients in a single unified, page-break optimized print job.
 */
export function printBatchPatientSummaries(patients: Patient[], currentUser?: Partial<User> | null): void {
  if (!patients || patients.length === 0) {
    return;
  }

  const doctorName = currentUser?.name || 'Administrator / Attending Clinician';
  const doctorRole = currentUser?.role || 'CLINICAL_ADMIN';
  const orgName = currentUser?.organizationName || 'MEDICORE UNIVERSITY HEALTH SYSTEM';
  const now = new Date().toLocaleString();

  // Generate Census Table
  const censusRows = patients.map((p, idx) => {
    const conds = (p.chronicConditions || p.conditions || []).join(', ') || 'Routine Evaluation';
    const allergiesCount = (p.allergies || []).length;
    const allergiesText = allergiesCount > 0 
      ? `${allergiesCount} recorded (${p.allergies?.map(a => a.allergen).slice(0, 2).join(', ')})` 
      : 'NKDA';
    
    return `
      <tr>
        <td class="mono font-bold">${idx + 1}</td>
        <td class="mono font-bold" style="color: #042f2e;">${p.mrn}</td>
        <td><strong>${p.name}</strong></td>
        <td>${p.dob || p.dateOfBirth || 'N/A'} (${p.age}y / ${p.gender?.[0] || 'U'})</td>
        <td class="mono" style="color: #be123c; font-weight: 700;">${p.bloodType || 'N/A'}</td>
        <td>
          <span class="badge ${p.admissionStatus === 'Inpatient' ? 'badge-alert' : 'badge-hipaa'}">
            ${p.admissionStatus}
          </span>
          <div style="font-size: 7.5pt; color: #475569; margin-top: 2px;">
            ${p.assignedWard || 'Outpatient'} ${p.assignedBed ? `• ${p.assignedBed}` : ''}
          </div>
        </td>
        <td style="font-size: 8.5pt;">${conds}</td>
        <td style="font-size: 8pt; color: ${allergiesCount > 0 ? '#991b1b' : '#065f46'}; font-weight: 600;">
          ${allergiesText}
        </td>
        <td style="font-size: 8pt;">
          <strong>${p.insurance?.provider || 'Self-Pay'}</strong>
          <div class="mono" style="font-size: 7pt; color: #64748b;">${p.phone || 'No phone'}</div>
        </td>
      </tr>
    `;
  }).join('');

  // Generate Individual Patient Summary Pages
  const individualSummaries = patients.map((patient, pIdx) => {
    const vitals = patient.vitals || [];
    const meds = patient.medications || [];
    const notes = patient.clinicalNotes || [];
    const labs = patient.labResults || [];
    const allergies = patient.allergies || [];
    const chronic = patient.chronicConditions || patient.conditions || [];

    return `
      <div style="page-break-before: always; break-before: page; padding-top: 10px;">
        <div class="header">
          <div>
            <div class="header-title">${orgName}</div>
            <div class="header-subtitle">Clinical Summary Dossier • Batch Export [Record ${pIdx + 1} of ${patients.length}]</div>
            <div style="font-size: 8pt; color: #64748b; margin-top: 2px;">
              75 Francis Street, Boston, MA 02115 • Tel: +1 (555) 720-4000 • HIPAA Encrypted Clinical Vault
            </div>
          </div>
          <div class="header-meta">
            <span class="badge badge-hipaa">EHR Batch Archive</span>
            <div style="margin-top: 4px;"><strong>Printed:</strong> ${now}</div>
            <div><strong>MRN:</strong> <span class="mono">${patient.mrn}</span></div>
          </div>
        </div>

        <!-- Demographics Card -->
        <div class="card">
          <div class="grid-4">
            <div>
              <div class="label">Patient Name</div>
              <div class="value" style="font-size: 11.5pt;">${patient.name}</div>
            </div>
            <div>
              <div class="label">DOB / Age / Gender</div>
              <div class="value">${patient.dob || patient.dateOfBirth || 'N/A'} (${patient.age}y / ${patient.gender})</div>
            </div>
            <div>
              <div class="label">Blood Type</div>
              <div class="value" style="color: #be123c;">${patient.bloodType || 'N/A'}</div>
            </div>
            <div>
              <div class="label">Admission & Ward</div>
              <div class="value">${patient.admissionStatus} ${patient.assignedWard ? `(${patient.assignedWard})` : ''}</div>
            </div>
          </div>

          <div class="grid-3" style="margin-top: 8px; margin-bottom: 0; padding-top: 8px; border-top: 1px solid #e2e8f0;">
            <div>
              <div class="label">Phone & Contact</div>
              <div style="font-size: 8.5pt;">${patient.phone || 'N/A'} • ${patient.email || 'N/A'}</div>
            </div>
            <div>
              <div class="label">Primary Payer / Insurance</div>
              <div style="font-size: 8.5pt;"><strong>${patient.insurance?.provider || 'Self-Pay'}</strong> (${patient.insurance?.policyNumber || 'N/A'})</div>
            </div>
            <div>
              <div class="label">Emergency Contact</div>
              <div style="font-size: 8.5pt;">${patient.emergencyContact?.name || 'N/A'} (${patient.emergencyContact?.relationship || 'Next of Kin'}) • ${patient.emergencyContact?.phone || 'N/A'}</div>
            </div>
          </div>
        </div>

        <!-- Allergies Banner -->
        <div class="card card-alert">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 3px;">
            <span class="label" style="color: #9f1239; font-weight: 900;">Allergies & Drug Reactions:</span>
            <span class="badge badge-alert">${allergies.length} Recorded</span>
          </div>
          <div style="font-size: 8.5pt;">
            ${allergies.length > 0 ? allergies.map(a => `
              <span style="display: inline-block; margin-right: 6px; margin-bottom: 2px; padding: 2px 6px; background: #ffffff; border: 1px solid #fca5a5; border-radius: 4px;">
                <strong>${a.allergen}</strong> (${a.reaction} - <span style="color: #991b1b; font-weight: 800;">${a.severity}</span>)
              </span>
            `).join('') : '<span style="color: #475569; font-style: italic;">No Known Drug Allergies (NKDA)</span>'}
          </div>
        </div>

        <!-- Diagnoses -->
        <div class="section-title">Active Clinical Diagnoses</div>
        <div style="margin-bottom: 8px; font-size: 9pt;">
          ${chronic.length > 0 ? chronic.map(c => `• <strong>${c}</strong>`).join(' &nbsp;|&nbsp; ') : '• General Clinical Health Evaluation (Z00.00)'}
        </div>

        <!-- Latest Vitals -->
        <div class="section-title">Latest Biometric Vital Signs</div>
        ${vitals.length > 0 ? `
          <table>
            <thead>
              <tr>
                <th>Date / Time</th>
                <th>BP (mmHg)</th>
                <th>Heart Rate</th>
                <th>Temp</th>
                <th>SpO2</th>
                <th>Resp</th>
                <th>Height / Weight / BMI</th>
                <th>Clinician</th>
              </tr>
            </thead>
            <tbody>
              ${vitals.slice(0, 3).map(v => `
                <tr>
                  <td class="mono">${v.recordedAt}</td>
                  <td class="mono font-bold">${v.bloodPressure}</td>
                  <td class="mono">${v.heartRate} bpm</td>
                  <td class="mono">${v.temperature}°C</td>
                  <td class="mono font-bold" style="color: #047857;">${v.spo2}%</td>
                  <td class="mono">${v.respiratoryRate}/m</td>
                  <td>${v.heightCm}cm / ${v.weightKg}kg (BMI: ${v.bmi})</td>
                  <td style="font-size: 8pt;">${v.recordedBy}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : '<p style="font-size: 8.5pt; color: #64748b; font-style: italic; margin-bottom: 8px;">No vital signs recorded.</p>'}

        <!-- Active Medications -->
        <div class="section-title">Active Pharmaceutical Regimen (Rx)</div>
        ${meds.length > 0 ? `
          <table>
            <thead>
              <tr>
                <th>Medication & Dosage</th>
                <th>Route & Frequency</th>
                <th>Instructions</th>
                <th>Prescriber</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${meds.slice(0, 4).map(m => `
                <tr>
                  <td><strong>${m.name}</strong> <span class="badge">${m.dosage}</span></td>
                  <td>${m.route} • ${m.frequency}</td>
                  <td style="font-size: 8pt; font-style: italic;">${m.instructions}</td>
                  <td>${m.prescribingDoctor}</td>
                  <td><span class="badge" style="background: #ecfdf5; color: #065f46;">${m.active ? 'Active' : 'Completed'}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : '<p style="font-size: 8.5pt; color: #64748b; font-style: italic; margin-bottom: 8px;">No active prescriptions.</p>'}

        <!-- Recent Labs -->
        ${labs.length > 0 ? `
          <div class="section-title">Recent Laboratory Findings</div>
          <table>
            <thead>
              <tr>
                <th>Test Name</th>
                <th>Date</th>
                <th>Result Value</th>
                <th>Reference Range</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${labs.slice(0, 4).map(l => `
                <tr>
                  <td><strong>${l.testName}</strong> (${l.category})</td>
                  <td class="mono">${l.date}</td>
                  <td class="mono font-bold">${l.resultValue} ${l.unit}</td>
                  <td class="mono">${l.referenceRange}</td>
                  <td>
                    <span class="badge ${l.status === 'CRITICAL' ? 'badge-critical' : l.status === 'ABNORMAL' ? 'badge-alert' : 'badge-hipaa'}">
                      ${l.status}
                    </span>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : ''}

        <!-- Latest Clinical Note -->
        ${notes.length > 0 ? `
          <div class="section-title">Most Recent Clinical Progress Note</div>
          <div class="card" style="margin-bottom: 8px;">
            <div style="display: flex; justify-content: space-between; font-size: 8pt; color: #475569; margin-bottom: 4px; border-bottom: 1px solid #e2e8f0; padding-bottom: 2px;">
              <span><strong>${notes[0].category}</strong> • ${notes[0].authorName} (${notes[0].authorRole})</span>
              <span class="mono">${notes[0].date}</span>
            </div>
            <div style="font-size: 8.5pt; color: #1e293b; line-height: 1.4;">${notes[0].content || notes[0].note || 'No narrative content.'}</div>
          </div>
        ` : ''}

        <!-- Footer / Attestation -->
        <div class="footer">
          <div>
            <div><strong>Batch Printed By:</strong> ${doctorName} (${doctorRole})</div>
            <div><strong>Batch Reference:</strong> <span class="mono">BATCH-PT-${patients.length}-${Date.now().toString().slice(-6)}</span></div>
            <div style="margin-top: 2px;">MediCore Multi-Patient Clinical Dossier • Official Certified EHR Export</div>
          </div>
          <div style="text-align: right;">
            <div class="signature-line"></div>
            <div style="font-size: 8pt; font-weight: 700;">Attending Clinician / Custodian of Records</div>
          </div>
        </div>
      </div>
    `;
  }).join('');

  const fullHtml = `
    <!-- 1. Executive Master Patient Census Summary Table -->
    <div>
      <div class="header">
        <div>
          <div class="header-title">${orgName}</div>
          <div class="header-subtitle">Department of Clinical Administration • Multi-Patient Census & Summary Roster</div>
          <div style="font-size: 8pt; color: #64748b; margin-top: 2px;">
            Official Administrative Batch Print • Total Selected Patients: <strong>${patients.length}</strong>
          </div>
        </div>
        <div class="header-meta">
          <span class="badge badge-hipaa">Census Batch Print</span>
          <div style="margin-top: 4px;"><strong>Generated:</strong> ${now}</div>
          <div><strong>Authorized By:</strong> ${doctorName}</div>
        </div>
      </div>

      <!-- Census Highlights Box -->
      <div class="card">
        <div class="grid-4">
          <div>
            <div class="label">Total Patients</div>
            <div class="value" style="font-size: 13pt; color: #0f172a;">${patients.length} Individuals</div>
          </div>
          <div>
            <div class="label">Inpatients / Outpatients</div>
            <div class="value">${patients.filter(p => p.admissionStatus === 'Inpatient').length} Inpatient / ${patients.filter(p => p.admissionStatus !== 'Inpatient').length} Outpatient</div>
          </div>
          <div>
            <div class="label">Allergies Flagged</div>
            <div class="value" style="color: #991b1b;">${patients.filter(p => (p.allergies || []).length > 0).length} Patients with Allergies</div>
          </div>
          <div>
            <div class="label">Batch Security</div>
            <div class="value" style="color: #065f46;">HIPAA HITECH Validated</div>
          </div>
        </div>
      </div>

      <!-- Master Census Table -->
      <div class="section-title">Selected Patients Master Clinical Roster</div>
      <table>
        <thead>
          <tr>
            <th style="width: 25px;">#</th>
            <th>MRN</th>
            <th>Patient Name</th>
            <th>DOB (Age/Gen)</th>
            <th>Blood</th>
            <th>Status / Ward</th>
            <th>Primary Diagnoses</th>
            <th>Allergies</th>
            <th>Insurance / Phone</th>
          </tr>
        </thead>
        <tbody>
          ${censusRows}
        </tbody>
      </table>

      <div class="footer">
        <div>
          <div>Executive Medical Census Archive • Page 1 of ${patients.length + 1}</div>
          <div style="font-size: 7.5pt; color: #94a3b8; margin-top: 2px;">Detailed individual clinical dossiers follow on subsequent pages.</div>
        </div>
        <div style="text-align: right;">
          <div class="signature-line"></div>
          <div style="font-size: 8pt; font-weight: 700;">Health Information Administrator Signature</div>
        </div>
      </div>
    </div>

    <!-- 2. Individual Patient Detailed Summaries -->
    ${individualSummaries}
  `;

  printHtmlDirectly(fullHtml, `Batch_Patient_Summaries_${patients.length}_Records_${new Date().toISOString().slice(0, 10)}`);
}
