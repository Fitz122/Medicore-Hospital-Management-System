import { Language } from '../types';

export interface TranslationDictionary {
  appName: string;
  appSubtitle: string;
  navDashboard: string;
  navPatients: string;
  navAppointments: string;
  navBilling: string;
  navWards: string;
  navAlerts: string;
  navChat: string;
  navAuditLogs: string;
  navBackup: string;
  navLabs: string;
  navPharmacy: string;
  navWorkflow: string;
  navBarcodeScanner: string;
  
  // Roles
  roleAdmin: string;
  rolePhysician: string;
  roleNurse: string;
  roleBilling: string;
  rolePatient: string;
  roleReceptionist: string;
  roleLabTech: string;
  rolePharmacist: string;
  
  // Dashboard & Metrics
  realTimeOccupancy: string;
  totalPatients: string;
  activeAppointments: string;
  pendingBilling: string;
  criticalAlerts: string;
  bedOccupancyRate: string;
  admissionsToday: string;
  dischargesToday: string;
  emergencyAlert: string;
  offlineStatusOnline: string;
  offlineStatusOffline: string;
  
  // Patient & EHR
  patientRecords: string;
  medicalRecordNumber: string;
  vitalsOverview: string;
  allergies: string;
  chronicConditions: string;
  prescriptions: string;
  labResults: string;
  clinicalNotes: string;
  exportConsultationReport: string;
  printReport: string;
  offlineCached: string;
  glassBreakEmergency: string;
  
  // Appointments
  scheduleAppointment: string;
  upcomingAlerts: string;
  doctor: string;
  room: string;
  status: string;
  
  // Billing
  invoices: string;
  generateInvoice: string;
  insuranceClaim: string;
  patientCopay: string;
  totalDue: string;
  
  // Accessibility & Senior Mode
  seniorFriendlyMode: string;
  highContrast: string;
  fontSize: string;
  audioAssistant: string;
  
  // Security & MFA
  mfaVerified: string;
  hipaaCompliantBadge: string;
  sessionTimeout: string;
  backupSynced: string;
}

export const translations: Record<Language, TranslationDictionary> = {
  en: {
    appName: 'MediCore HMS',
    appSubtitle: 'Enterprise Clinical & Hospital Management Platform',
    navDashboard: 'Clinical Dashboard',
    navPatients: 'Patient Records (EHR)',
    navAppointments: 'Appointments',
    navBilling: 'Billing & Claims',
    navWards: 'Ward Occupancy',
    navAlerts: 'Staff Alerts & Meds',
    navChat: 'Secure Provider Chat',
    navAuditLogs: 'HIPAA Audit Trail',
    navBackup: 'Cloud Backup & DR',
    navLabs: 'Diagnostic Laboratory',
    navPharmacy: 'Pharmacy & Dispensing',
    navWorkflow: 'Outpatient Care Journey',
    navBarcodeScanner: 'Camera BCMA Scanner',
    
    roleAdmin: 'System Administrator',
    rolePhysician: 'Specialist Physician',
    roleNurse: 'Ward Head Nurse',
    roleBilling: 'Billing Cashier',
    rolePatient: 'Patient Portal User',
    roleReceptionist: 'Front Receptionist',
    roleLabTech: 'Medical Lab Technician',
    rolePharmacist: 'Clinical Pharmacist',
    
    realTimeOccupancy: 'Real-Time Ward Occupancy',
    totalPatients: 'Active Inpatients',
    activeAppointments: "Today's Appointments",
    pendingBilling: 'Claims & Bills in Review',
    criticalAlerts: 'STAT Clinical Alerts',
    bedOccupancyRate: 'Total Bed Utilization',
    admissionsToday: 'Admitted Today',
    dischargesToday: 'Discharged Today',
    emergencyAlert: 'Emergency Broadcast',
    offlineStatusOnline: 'Cloud Connected (Encrypted)',
    offlineStatusOffline: 'Offline Mode Active (Local EHR Cache)',
    
    patientRecords: 'Patient Health Records',
    medicalRecordNumber: 'MRN',
    vitalsOverview: 'Vital Signs & Biometrics',
    allergies: 'Allergies & Sensitivities',
    chronicConditions: 'Active Diagnoses & Conditions',
    prescriptions: 'Active Medications',
    labResults: 'Diagnostic Lab Reports',
    clinicalNotes: 'Physician Clinical Notes',
    exportConsultationReport: 'Export Consultation PDF/Summary',
    printReport: 'Print Clinical Summary',
    offlineCached: 'Available Offline',
    glassBreakEmergency: 'Emergency Glass-Break Access',
    
    scheduleAppointment: 'Book New Appointment',
    upcomingAlerts: 'Upcoming Appointment Alerts',
    doctor: 'Attending Physician',
    room: 'Examination Room / Suite',
    status: 'Status',
    
    invoices: 'Billing & Invoice Ledger',
    generateInvoice: 'Create Itemized Bill',
    insuranceClaim: 'Automated Insurance Split',
    patientCopay: 'Patient Co-Pay Due',
    totalDue: 'Net Balance',
    
    seniorFriendlyMode: 'Senior / Elderly Friendly UI',
    highContrast: 'High Contrast Mode',
    fontSize: 'Text Size',
    audioAssistant: 'Voice Assistant Reader',
    
    mfaVerified: 'MFA 2-Factor Verified',
    hipaaCompliantBadge: 'HIPAA HITECH 256-bit Encrypted',
    sessionTimeout: 'Auto Secure Session',
    backupSynced: 'Cloud Disaster Recovery Synchronized',
  },
  es: {
    appName: 'MediCore HMS',
    appSubtitle: 'Plataforma Hospitalaria y de Gestión Clínica',
    navDashboard: 'Panel Clínico',
    navPatients: 'Expediente Médico (EHR)',
    navAppointments: 'Citas Médicas',
    navBilling: 'Facturación y Caja',
    navWards: 'Ocupación de Salas',
    navAlerts: 'Alertas y Medicación',
    navChat: 'Chat Seguro con Médico',
    navAuditLogs: 'Auditoría HIPAA',
    navBackup: 'Respaldo en la Nube',
    navLabs: 'Laboratorio de Diagnóstico',
    navPharmacy: 'Farmacia y Dispensación',
    navWorkflow: 'Flujo de Paciente Ambulatorio',
    navBarcodeScanner: 'Escáner BCMA de Cámara',
    
    roleAdmin: 'Administrador del Sistema',
    rolePhysician: 'Médico Especialista',
    roleNurse: 'Enfermera en Jefe',
    roleBilling: 'Cajero / Facturación',
    rolePatient: 'Portal del Paciente',
    roleReceptionist: 'Recepcionista',
    roleLabTech: 'Técnico de Laboratorio',
    rolePharmacist: 'Farmacéutico Clínico',
    
    realTimeOccupancy: 'Ocupación de Salas en Tiempo Real',
    totalPatients: 'Pacientes Internados',
    activeAppointments: 'Citas de Hoy',
    pendingBilling: 'Reclamaciones Pendientes',
    criticalAlerts: 'Alertas Médicas STAT',
    bedOccupancyRate: 'Tasa de Ocupación de Camas',
    admissionsToday: 'Ingresos de Hoy',
    dischargesToday: 'Altas de Hoy',
    emergencyAlert: 'Transmisión de Emergencia',
    offlineStatusOnline: 'Conectado a la Nube (Cifrado)',
    offlineStatusOffline: 'Modo Offline Activo (Caché Local)',
    
    patientRecords: 'Historial Clínico del Paciente',
    medicalRecordNumber: 'Nº Expediente (MRN)',
    vitalsOverview: 'Signos Vitales y Biometría',
    allergies: 'Alergias y Sensibilidades',
    chronicConditions: 'Diagnósticos y Condiciones',
    prescriptions: 'Medicamentos Activos',
    labResults: 'Resultados de Laboratorio',
    clinicalNotes: 'Notas Médicas de Evolución',
    exportConsultationReport: 'Exportar Resumen de Consulta',
    printReport: 'Imprimir Informe Clínico',
    offlineCached: 'Disponible sin Conexión',
    glassBreakEmergency: 'Acceso de Emergencia (Romper Cristal)',
    
    scheduleAppointment: 'Programar Nueva Cita',
    upcomingAlerts: 'Alertas de Próximas Citas',
    doctor: 'Médico Tratante',
    room: 'Consultorio / Sala',
    status: 'Estado',
    
    invoices: 'Facturación y Cuentas',
    generateInvoice: 'Crear Factura Detallada',
    insuranceClaim: 'Cálculo Automático de Seguro',
    patientCopay: 'Copago del Paciente',
    totalDue: 'Saldo Total',
    
    seniorFriendlyMode: 'Modo Adaptado para Adultos Mayores',
    highContrast: 'Modo Alto Contraste',
    fontSize: 'Tamaño de Texto',
    audioAssistant: 'Lector de Voz Asistido',
    
    mfaVerified: 'MFA Doble Factor Verificado',
    hipaaCompliantBadge: 'Cifrado Seguro HIPAA 256-bit',
    sessionTimeout: 'Sesión Segura',
    backupSynced: 'Respaldo en Nube Sincronizado',
  },
  fr: {
    appName: 'MediCore HMS',
    appSubtitle: 'Système Intégré de Gestion Hospitalière & Dossier Médical',
    navDashboard: 'Tableau de Bord',
    navPatients: 'Dossiers Patients (DPI)',
    navAppointments: 'Rendez-vous',
    navBilling: 'Facturation & Caisse',
    navWards: 'Occupation des Lits',
    navAlerts: 'Alertes Soignants & Traitements',
    navChat: 'Messagerie Sécurisée',
    navAuditLogs: 'Audit HIPAA / RGPD',
    navBackup: 'Sauvegarde Cloud & PRA',
    navLabs: 'Laboratoire Diagnostic',
    navPharmacy: 'Pharmacie & Délivrance',
    navWorkflow: 'Parcours Patient Ambulatoire',
    navBarcodeScanner: 'Scanner BCMA Caméra',
    
    roleAdmin: 'Administrateur Système',
    rolePhysician: 'Médecin Spécialiste',
    roleNurse: 'Infirmière Major',
    roleBilling: 'Caissier / Facturation',
    rolePatient: 'Portail Patient',
    roleReceptionist: 'Réceptionniste',
    roleLabTech: 'Technicien de Laboratoire',
    rolePharmacist: 'Pharmacien Hospitalier',
    
    realTimeOccupancy: 'Occupation des Services en Temps Réel',
    totalPatients: 'Patients Hospitalisés',
    activeAppointments: "Rendez-vous du Jour",
    pendingBilling: 'Dossiers Mutuelle en Cours',
    criticalAlerts: 'Alertes Cliniques Urgentes',
    bedOccupancyRate: "Taux d'Occupation des Lits",
    admissionsToday: 'Entrées du Jour',
    dischargesToday: 'Sorties du Jour',
    emergencyAlert: "Alerte d'Urgence",
    offlineStatusOnline: 'Connecté au Cloud Sécurisé',
    offlineStatusOffline: 'Mode Hors-ligne Actif (Cache DPI)',
    
    patientRecords: 'Dossier Médical Informatisé',
    medicalRecordNumber: 'N° Patient (IPP)',
    vitalsOverview: 'Constantes Vitales',
    allergies: 'Allergies & Intolérances',
    chronicConditions: 'Pathologies Actives',
    prescriptions: 'Traitements en Cours',
    labResults: "Analyses Médicales",
    clinicalNotes: 'Observations Médicales',
    exportConsultationReport: 'Exporter Rapport de Consultation',
    printReport: 'Imprimer Synthèse Médicale',
    offlineCached: 'Accessible Hors-Ligne',
    glassBreakEmergency: "Procédure d'Urgence Bris-de-Glace",
    
    scheduleAppointment: 'Planifier un Rendez-vous',
    upcomingAlerts: 'Alertes Rendez-vous Imminents',
    doctor: 'Praticien Responsable',
    room: 'Box / Salle de Consultation',
    status: 'Statut',
    
    invoices: 'Factures & Tiers Payant',
    generateInvoice: 'Générer Facture Détaillée',
    insuranceClaim: 'Calcul Partiel Sécurité Sociale',
    patientCopay: 'Ticket Modérateur Restant',
    totalDue: 'Reste à Payer',
    
    seniorFriendlyMode: 'Interface Simplifiée Seniors',
    highContrast: 'Contraste Élevé',
    fontSize: 'Taille du Texte',
    audioAssistant: 'Synthèse Vocale',
    
    mfaVerified: 'Double Authentification Validée',
    hipaaCompliantBadge: 'Certifié Données de Santé HDS / HIPAA',
    sessionTimeout: 'Sécurité Session Active',
    backupSynced: 'Sauvegarde Cloud Synchronisée',
  },
  zh: {
    appName: 'MediCore 医院管理系统',
    appSubtitle: '企业级电子病历、排班、计费与病区智能管理平台',
    navDashboard: '临床概览仪表盘',
    navPatients: '电子病历档案 (EHR)',
    navAppointments: '门诊与预约',
    navBilling: '门诊收费与医保',
    navWards: '病房床位实时监测',
    navAlerts: '医护紧急警报与服药提醒',
    navChat: '医患加密通信',
    navAuditLogs: 'HIPAA 安全审计日志',
    navBackup: '云端容灾与数据备份',
    navLabs: '医学检验与化验室',
    navPharmacy: '药房配药与核发',
    navWorkflow: '门诊闭环就诊全流程',
    navBarcodeScanner: '摄像头条码核对 (BCMA)',
    
    roleAdmin: '系统超级管理员',
    rolePhysician: '专科主治医师',
    roleNurse: '病区护士长',
    roleBilling: '门诊收费结账员',
    rolePatient: '患者本人端',
    roleReceptionist: '门诊前台接待员',
    roleLabTech: '医学检验技师',
    rolePharmacist: '临床执业药师',
    
    realTimeOccupancy: '全院病房床位实时监控',
    totalPatients: '在院患者总数',
    activeAppointments: '今日预约就诊',
    pendingBilling: '待结算医保账单',
    criticalAlerts: '急诊紧急警报',
    bedOccupancyRate: '全院病床使用率',
    admissionsToday: '今日新入院',
    dischargesToday: '今日已出院',
    emergencyAlert: '全院紧急广播',
    offlineStatusOnline: '云端加密连接正常',
    offlineStatusOffline: '离线紧急模式生效中 (本地病历缓存)',
    
    patientRecords: '患者完整健康档案',
    medicalRecordNumber: '病案号 (MRN)',
    vitalsOverview: '生命体征与生物监测',
    allergies: '药物及食物过敏史',
    chronicConditions: '现病史与基础疾病',
    prescriptions: '在用处方用药',
    labResults: '医学化验与检查报告',
    clinicalNotes: '医师查房与病程记录',
    exportConsultationReport: '导出问诊报告 / 打印病历',
    printReport: '打印临床总结',
    offlineCached: '已离线缓存就绪',
    glassBreakEmergency: '紧急破窗取阅机制 (Glass-Break)',
    
    scheduleAppointment: '新增门诊挂号预约',
    upcomingAlerts: '即将就诊提醒',
    doctor: '主治医生',
    room: '诊室 / 治疗室',
    status: '就诊状态',
    
    invoices: '医疗费用清单与结算',
    generateInvoice: '开具明细收费单',
    insuranceClaim: '医保与自费自动核算',
    patientCopay: '个人自付金额',
    totalDue: '应收总额',
    
    seniorFriendlyMode: '适老化大字简明模式',
    highContrast: '高对比度视力辅助',
    fontSize: '字体大小调节',
    audioAssistant: '智能语音朗读',
    
    mfaVerified: 'MFA 双重身份验证已通过',
    hipaaCompliantBadge: '符合 HIPAA 256位高等级加密',
    sessionTimeout: '超时安全保护已就绪',
    backupSynced: '云端容灾备份已完成',
  },
  ar: {
    appName: 'MediCore لإدارة المستشفيات',
    appSubtitle: 'المنظومة المتكاملة للسجلات الطبية والمواعيد والفوترة السحابية',
    navDashboard: 'لوحة التحكم السريرية',
    navPatients: 'السجلات الطبية (EHR)',
    navAppointments: 'جدول المواعيد',
    navBilling: 'الفوترة ومطالبات التأمين',
    navWards: 'إشغال الأجنحة والأسرة',
    navAlerts: 'تنبيهات الطواقم والأدوية',
    navChat: 'المحادثة الآمنة مع الطبيب',
    navAuditLogs: 'سجلات التدقيق الأمني HIPAA',
    navBackup: 'النسخ الاحتياطي السحابي',
    navLabs: 'المختبر والتحاليل الطبية',
    navPharmacy: 'الصيدلية وصرف الأدوية',
    navWorkflow: 'مسار المريض في العيادات',
    navBarcodeScanner: 'فاحص الباركود بالكاميرا (BCMA)',
    
    roleAdmin: 'مدير النظام',
    rolePhysician: 'طبيب استشاري متخصص',
    roleNurse: 'رئيسة التمريض',
    roleBilling: 'أمين الصندوق والفوترة',
    rolePatient: 'بوابة المريض',
    roleReceptionist: 'موظف الاستقبال',
    roleLabTech: 'فني المختبرات الطبية',
    rolePharmacist: 'صيدلي سريري',
    
    realTimeOccupancy: 'معدل إشغال الأسرة في الوقت الفعلي',
    totalPatients: 'المرضى المنومين',
    activeAppointments: 'مواعيد اليوم',
    pendingBilling: 'مطالبات قيد المراجعة',
    criticalAlerts: 'تنبيهات الطوارئ الفورية',
    bedOccupancyRate: 'نسبة استخدام الأسرة',
    admissionsToday: 'دخول اليوم',
    dischargesToday: 'خروج اليوم',
    emergencyAlert: 'نداء طوارئ عام',
    offlineStatusOnline: 'متصل بالسحابة المشفرة',
    offlineStatusOffline: 'الوضع غير المتصل نشط (سجلات محلية)',
    
    patientRecords: 'الملف الطبي الشامل للمريض',
    medicalRecordNumber: 'رقم السجل الطبي (MRN)',
    vitalsOverview: 'العلامات الحيوية',
    allergies: 'الحساسية والتفاعلات الدوائية',
    chronicConditions: 'الأمراض المزمنة والتشخيص',
    prescriptions: 'الأدوية الموصوفة',
    labResults: 'نتائج التحاليل المخبرية',
    clinicalNotes: 'ملاحظات الأطباء السريرية',
    exportConsultationReport: 'تصدير تقرير الاستشارة الطبية',
    printReport: 'طباعة التقرير السريري',
    offlineCached: 'متاح للعمل دون إنترنت',
    glassBreakEmergency: 'بروتوكول الوصول الطارئ للبيانات',
    
    scheduleAppointment: 'حجز موعد جديد',
    upcomingAlerts: 'تنبيهات المواعيد القادمة',
    doctor: 'الطبيب المعالج',
    room: 'غرفة الكشف / العيادة',
    status: 'الحالة',
    
    invoices: 'سجل الفواتير والمطالبات',
    generateInvoice: 'إنشاء فاتورة تفصيلية',
    insuranceClaim: 'التوزيع الآلي لمستحقات التأمين',
    patientCopay: 'المبلغ المدفوع من المريض',
    totalDue: 'إجمالي المستحق',
    
    seniorFriendlyMode: 'واجهة مخصصة لكبار السن',
    highContrast: 'وضع التباين العالي',
    fontSize: 'حجم الخط',
    audioAssistant: 'المساعد الصوتي للقراءة',
    
    mfaVerified: 'تم التحقق الثنائي MFA',
    hipaaCompliantBadge: 'متوافق مع معايير HIPAA المشفرة',
    sessionTimeout: 'حماية الجلسة الآمنة',
    backupSynced: 'النسخ السحابي متزامن',
  },
  de: {
    appName: 'MediCore KIS',
    appSubtitle: 'Integriertes Krankenhaus-Informationssystem & E-Health Plattform',
    navDashboard: 'Klinisches Dashboard',
    navPatients: 'Patientenakten (EPA)',
    navAppointments: 'Terminplanung',
    navBilling: 'Abrechnung & Kasse',
    navWards: 'Bettenbelegung',
    navAlerts: 'Personal-Alarme & Medikation',
    navChat: 'Sicherer Arzt-Patient Chat',
    navAuditLogs: 'HIPAA / DSGVO Protokoll',
    navBackup: 'Cloud-Backup & Recovery',
    navLabs: 'Klinisches Labor & Diagnostik',
    navPharmacy: 'Apotheke & Ausgabe',
    navWorkflow: 'Ambulanter Behandlungspfad',
    navBarcodeScanner: 'Kamera-Barcode Scanner (BCMA)',
    
    roleAdmin: 'Systemadministrator',
    rolePhysician: 'Facharzt / Spezialist',
    roleNurse: 'Stationsleitung Pflege',
    roleBilling: 'Kassierer / Abrechnung',
    rolePatient: 'Patientenportal',
    roleReceptionist: 'Empfang / Rezeptionist',
    roleLabTech: 'Medizinisch-technischer Assistent (MTA)',
    rolePharmacist: 'Klinischer Apotheker',
    
    realTimeOccupancy: 'Echtzeit-Bettenbelegung',
    totalPatients: 'Stationäre Patienten',
    activeAppointments: 'Heutige Termine',
    pendingBilling: 'Offene Kassenabrechnungen',
    criticalAlerts: 'Kritische Notfall-Alarme',
    bedOccupancyRate: 'Bettenauslastung Gesamt',
    admissionsToday: 'Aufnahmen Heute',
    dischargesToday: 'Entlassungen Heute',
    emergencyAlert: 'Notfall-Durchsage',
    offlineStatusOnline: 'Sichere Cloud-Verbindung',
    offlineStatusOffline: 'Offline-Modus aktiv (Lokaler EPA-Cache)',
    
    patientRecords: 'Elektronische Patientenakte',
    medicalRecordNumber: 'Patientennummer (MRN)',
    vitalsOverview: 'Vitalparameter & Biometrie',
    allergies: 'Allergien & Unverträglichkeiten',
    chronicConditions: 'Aktive Diagnosen & Vorerkrankungen',
    prescriptions: 'Aktuelle Medikation',
    labResults: 'Labor- & Diagnosebefunde',
    clinicalNotes: 'Klinische Verlaufsdokumentation',
    exportConsultationReport: 'Konsultationsbericht exportieren',
    printReport: 'Klinischen Bericht drucken',
    offlineCached: 'Offline verfügbar',
    glassBreakEmergency: 'Notfall-Zugriff (Glass-Break)',
    
    scheduleAppointment: 'Neuen Termin anlegen',
    upcomingAlerts: 'Anstehende Terminerinnerungen',
    doctor: 'Behandelnder Arzt',
    room: 'Behandlungsraum / Station',
    status: 'Status',
    
    invoices: 'Abrechnungsübersicht & Rechnungen',
    generateInvoice: 'Detaillierte Rechnung erstellen',
    insuranceClaim: 'Automatische Kassenabrechnung',
    patientCopay: 'Eigenanteil Patient',
    totalDue: 'Gesamtbetrag',
    
    seniorFriendlyMode: 'Seniorenfreundliche Ansicht',
    highContrast: 'Hoher Kontrast',
    fontSize: 'Schriftgröße',
    audioAssistant: 'Vorleseassistent',
    
    mfaVerified: '2-Faktor-Authentifizierung (MFA)',
    hipaaCompliantBadge: 'HIPAA & DSGVO konform 256-Bit',
    sessionTimeout: 'Automatische Abmeldung',
    backupSynced: 'Cloud-Wiederherstellung synchronisiert',
  }
};
