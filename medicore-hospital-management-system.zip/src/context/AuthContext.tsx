import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole, SaaSRegistrationData } from '../types';
import { INITIAL_USERS } from '../services/mockData';

interface AuthContextType {
  currentUser: User;
  isAuthenticated: boolean;
  login: (userOrRole: UserRole | string, password?: string) => boolean;
  signup: (data: SaaSRegistrationData) => { success: boolean; error?: string };
  logout: () => void;
  availableUsers: User[];
  registeredUsers: User[];
  switchRole: (role: UserRole) => void;
  isMfaModalOpen: boolean;
  openMfaModal: () => void;
  closeMfaModal: () => void;
  verifyMfa: (code: string) => boolean;
  isGlassBreakActive: boolean;
  triggerGlassBreak: (reason: string) => void;
  cancelGlassBreak: () => void;
  glassBreakReason: string | null;
  sessionTimeRemaining: number; // in seconds
  resetSessionTimer: () => void;
  isSessionLocked: boolean;
  isLocked: boolean;
  unlockSession: () => void;
  hasPermission: (requiredRole: UserRole | UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [registeredUsers, setRegisteredUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('medicore_custom_users');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const savedAuth = localStorage.getItem('medicore_is_authenticated');
    return savedAuth !== null ? savedAuth === 'true' : true;
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('medicore_current_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_USERS[0];
      }
    }
    return INITIAL_USERS[0]; // default to Admin
  });

  const [isMfaModalOpen, setIsMfaModalOpen] = useState<boolean>(false);
  const [isGlassBreakActive, setIsGlassBreakActive] = useState<boolean>(false);
  const [glassBreakReason, setGlassBreakReason] = useState<string | null>(null);
  
  // HIPAA Session Timeout (15 minutes in clinical environments, simulated as 300s / 5 mins for demo)
  const SESSION_DURATION = 300;
  const [sessionTimeRemaining, setSessionTimeRemaining] = useState<number>(SESSION_DURATION);
  const [isSessionLocked, setIsSessionLocked] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('medicore_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('medicore_custom_users', JSON.stringify(registeredUsers));
  }, [registeredUsers]);

  useEffect(() => {
    localStorage.setItem('medicore_is_authenticated', isAuthenticated ? 'true' : 'false');
  }, [isAuthenticated]);

  // Session timer countdown
  useEffect(() => {
    if (isSessionLocked || !isAuthenticated) return;
    const interval = setInterval(() => {
      setSessionTimeRemaining(prev => {
        if (prev <= 1) {
          setIsSessionLocked(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isSessionLocked, isAuthenticated]);

  const resetSessionTimer = () => {
    setSessionTimeRemaining(SESSION_DURATION);
    setIsSessionLocked(false);
  };

  const unlockSession = () => {
    resetSessionTimer();
  };

  const allAvailableUsers = [...registeredUsers, ...INITIAL_USERS];

  const login = (userOrRole: UserRole | string, _password?: string): boolean => {
    // Look up in both registered custom users and initial users
    const matched = allAvailableUsers.find(
      u => u.role === userOrRole || 
           u.email.toLowerCase() === userOrRole.toLowerCase() || 
           u.id === userOrRole
    ) || INITIAL_USERS[0];
    
    setCurrentUser(matched);
    setIsAuthenticated(true);
    setIsSessionLocked(false);
    resetSessionTimer();
    return true;
  };

  const signup = (data: SaaSRegistrationData): { success: boolean; error?: string } => {
    if (!data.email || !data.adminName || !data.organizationName) {
      return { success: false, error: 'Please provide all required organization and clinician details.' };
    }

    const emailClean = data.email.trim().toLowerCase();
    const existing = allAvailableUsers.find(u => u.email.toLowerCase() === emailClean);
    if (existing) {
      return { success: false, error: `An account with ${emailClean} is already registered. Please sign in instead.` };
    }

    // Role-specific professional avatars
    const roleAvatars: Record<UserRole, string> = {
      ADMIN: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      PHYSICIAN: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80',
      NURSE: 'https://images.unsplash.com/photo-1594824813596-f9479bbf8a5e?w=150&auto=format&fit=crop&q=80',
      LAB_TECHNICIAN: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&auto=format&fit=crop&q=80',
      PHARMACIST: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=150&auto=format&fit=crop&q=80',
      BILLING: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
      RECEPTIONIST: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
      PATIENT: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80'
    };

    const newUserId = `usr-org-${Date.now()}`;
    const newUser: User = {
      id: newUserId,
      name: data.adminName.trim(),
      email: emailClean,
      role: data.role || 'ADMIN',
      avatar: roleAvatars[data.role] || roleAvatars.ADMIN,
      department: data.department || 'Clinical Governance',
      organizationName: data.organizationName.trim(),
      organizationType: data.facilityType,
      planTier: data.planTier || 'PROFESSIONAL',
      licenseNumber: data.licenseNumber?.trim() || `LIC-${Math.floor(100000 + Math.random() * 900000)}`,
      cloudRegion: data.cloudRegion || 'us-east-hipaa',
      mfaEnabled: true,
      mfaVerified: true,
      isRegisteredAccount: true,
      registeredAt: new Date().toISOString()
    };

    setRegisteredUsers(prev => [newUser, ...prev]);
    setCurrentUser(newUser);
    setIsAuthenticated(true);
    setIsSessionLocked(false);
    resetSessionTimer();

    return { success: true };
  };

  const logout = () => {
    setIsAuthenticated(false);
    setIsSessionLocked(false);
  };

  const switchRole = (role: UserRole) => {
    const matchedUser = allAvailableUsers.find(u => u.role === role) || INITIAL_USERS[0];
    setCurrentUser(matchedUser);
    resetSessionTimer();
  };

  const hasPermission = (requiredRole: UserRole | UserRole[]): boolean => {
    if (currentUser.role === 'ADMIN') return true;
    if (Array.isArray(requiredRole)) {
      return requiredRole.includes(currentUser.role);
    }
    return currentUser.role === requiredRole;
  };

  const openMfaModal = () => setIsMfaModalOpen(true);
  const closeMfaModal = () => setIsMfaModalOpen(false);

  const verifyMfa = (code: string): boolean => {
    if (code.trim().length >= 4) {
      setCurrentUser(prev => ({ ...prev, mfaVerified: true }));
      setIsMfaModalOpen(false);
      resetSessionTimer();
      return true;
    }
    return false;
  };

  const triggerGlassBreak = (reason: string) => {
    setIsGlassBreakActive(true);
    setGlassBreakReason(reason);
    resetSessionTimer();
  };

  const cancelGlassBreak = () => {
    setIsGlassBreakActive(false);
    setGlassBreakReason(null);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        login,
        signup,
        logout,
        availableUsers: allAvailableUsers,
        registeredUsers,
        switchRole,
        isMfaModalOpen,
        openMfaModal,
        closeMfaModal,
        verifyMfa,
        isGlassBreakActive,
        triggerGlassBreak,
        cancelGlassBreak,
        glassBreakReason,
        sessionTimeRemaining,
        resetSessionTimer,
        isSessionLocked,
        isLocked: isSessionLocked,
        unlockSession,
        hasPermission
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
