import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Activity, 
  FileText, 
  Pill, 
  FlaskConical, 
  AlertOctagon, 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  Calendar, 
  Printer, 
  Wifi, 
  WifiOff, 
  HeartHandshake, 
  X,
  CheckCircle2,
  Stethoscope,
  Heart,
  Thermometer,
  Wind,
  Video,
  ExternalLink,
  QrCode,
  CheckSquare,
  Square,
  MinusSquare,
  ListChecks
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Patient, Allergy, VitalSign, Medication, LabResult, ClinicalNote } from '../../types';
import { ConsultationReportModal } from '../reports/ConsultationReportModal';
import { VideoConsultationModal } from '../telehealth/VideoConsultationModal';
import { NavTab } from '../layout/Sidebar';
import { 
  printPatientCompleteRecord, 
  printPatientWristbandAndChart, 
  printVitalFlowsheet, 
  printClinicalSOAPNotes, 
  printPrescriptionRx, 
  printLabOrderRequisition,
  printBatchPatientSummaries
} from '../../utils/printEngine';

interface PatientRecordsProps {
  onNavigate?: (tab: NavTab) => void;
}

export const PatientRecords: React.FC<PatientRecordsProps> = ({ onNavigate }) => {
  const { 
    patients, 
    selectedPatientId, 
    setSelectedPatientId, 
    selectedPatient, 
    addPatient, 
    updatePatient, 
    addVitalSign, 
    addClinicalNote, 
    addMedication, 
    addLabResult,
    logAuditAction,
    t 
  } = useHospital();

  const { currentUser, isGlassBreakActive } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatientIds, setSelectedPatientIds] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'vitals' | 'notes' | 'meds' | 'labs' | 'allergies'>('vitals');
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isTelehealthModalOpen, setIsTelehealthModalOpen] = useState(false);

  // Modals state
  const [isNewPatientModalOpen, setIsNewPatientModalOpen] = useState(false);
  const [isAddVitalModalOpen, setIsAddVitalModalOpen] = useState(false);
  const [isAddNoteModalOpen, setIsAddNoteModalOpen] = useState(false);
  const [isAddMedModalOpen, setIsAddMedModalOpen] = useState(false);
  const [isAddLabModalOpen, setIsAddLabModalOpen] = useState(false);

  // Form states
  const [newPatientName, setNewPatientName] = useState('');
  const [newPatientDob, setNewPatientDob] = useState('1980-01-01');
  const [newPatientGender, setNewPatientGender] = useState<'Male' | 'Female' | 'Other'>('Female');
  const [newPatientBlood, setNewPatientBlood] = useState<Patient['bloodType']>('O+');
  const [newPatientPhone, setNewPatientPhone] = useState('');
  const [newPatientInsurance, setNewPatientInsurance] = useState('');
  const [newPatientCondition, setNewPatientCondition] = useState('');

  // Vital Form state
  const [vitalBp, setVitalBp] = useState('120/80');
  const [vitalHr, setVitalHr] = useState(72);
  const [vitalTemp, setVitalTemp] = useState(36.8);
  const [vitalSpo2, setVitalSpo2] = useState(98);
  const [vitalResp, setVitalResp] = useState(16);
  const [vitalHeight, setVitalHeight] = useState(170);
  const [vitalWeight, setVitalWeight] = useState(70);

  // Note Form state
  const [noteCategory, setNoteCategory] = useState<ClinicalNote['category']>('Progress Note');
  const [noteContent, setNoteContent] = useState('');
  const [noteIcdCode, setNoteIcdCode] = useState('');

  // Med Form state
  const [medName, setMedName] = useState('');
  const [medDosage, setMedDosage] = useState('');
  const [medFrequency, setMedFrequency] = useState('Once Daily');
  const [medRoute, setMedRoute] = useState<Medication['route']>('Oral');
  const [medInstructions, setMedInstructions] = useState('');

  // Lab Form state
  const [labTestName, setLabTestName] = useState('');
  const [labCategory, setLabCategory] = useState<LabResult['category']>('Biochemistry');
  const [labResultVal, setLabResultVal] = useState('');
  const [labUnit, setLabUnit] = useState('mg/dL');
  const [labRefRange, setLabRefRange] = useState('');
  const [labStatus, setLabStatus] = useState<LabResult['status']>('NORMAL');

  // Safe patient filtering and resolution to prevent breaks
  const effectivePatients = Array.isArray(patients) ? patients : [];
  const filteredPatients = effectivePatients.filter(p => {
    if (!p) return false;
    const nameStr = (p.name || '').toLowerCase();
    const mrnStr = (p.mrn || '').toLowerCase();
    const q = searchQuery.toLowerCase();
    const conditions = Array.isArray(p.chronicConditions) ? p.chronicConditions : (Array.isArray(p.conditions) ? p.conditions : []);
    const condMatch = conditions.some(c => (c || '').toLowerCase().includes(q));
    return nameStr.includes(q) || mrnStr.includes(q) || condMatch;
  });

  const activePatient = selectedPatient || filteredPatients.find(p => p.id === selectedPatientId) || filteredPatients[0] || effectivePatients[0] || null;

  const calculateBmi = (heightCm: number, weightKg: number) => {
    if (!heightCm || !weightKg) return 0;
    const m = heightCm / 100;
    return parseFloat((weightKg / (m * m)).toFixed(1));
  };

  const handleRegisterPatient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPatientName.trim()) return;

    const birthYear = new Date(newPatientDob).getFullYear();
    const age = new Date().getFullYear() - birthYear;

    const created = addPatient({
      name: newPatientName,
      dob: newPatientDob,
      age: Math.max(1, age),
      gender: newPatientGender,
      bloodType: newPatientBlood,
      phone: newPatientPhone || '+1 (555) 000-0000',
      email: `${newPatientName.toLowerCase().replace(/\s+/g, '.')}@patient-portal.org`,
      address: '742 Evergreen Terrace, Boston, MA 02108',
      emergencyContact: {
        name: 'Primary Proxy',
        relationship: 'Spouse / Next of Kin',
        phone: '+1 (555) 999-8888',
      },
      insurance: {
        provider: newPatientInsurance || 'BlueCross Comprehensive Choice',
        policyNumber: `POL-${Math.floor(100000 + Math.random() * 900000)}`,
        groupNumber: 'GRP-BOS-101',
        coveragePercentage: 85,
        copayAmount: 25,
        deductibleMet: true,
      },
      allergies: [],
      chronicConditions: newPatientCondition ? [newPatientCondition] : ['General Evaluation (Z00.00)'],
      vitals: [],
      medications: [],
      labResults: [],
      clinicalNotes: [
        {
          id: `note-${Date.now()}`,
          date: new Date().toISOString().replace('T', ' ').slice(0, 16),
          authorName: currentUser.name,
          authorRole: currentUser.role,
          category: 'Admission Note',
          content: `Initial clinical intake and demographic registration performed by ${currentUser.name}. Baseline records established in hospital EHR vault.`,
          icdCodes: ['Z00.00 (General adult medical examination)']
        }
      ],
      admissionStatus: 'Outpatient'
    });

    setIsNewPatientModalOpen(false);
    setNewPatientName('');
    setSelectedPatientId(created.id);
  };

  const handleSaveVital = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient) return;

    const bmi = calculateBmi(vitalHeight, vitalWeight);
    addVitalSign(activePatient.id, {
      bloodPressure: vitalBp,
      heartRate: Number(vitalHr),
      temperature: Number(vitalTemp),
      spo2: Number(vitalSpo2),
      respiratoryRate: Number(vitalResp),
      heightCm: Number(vitalHeight),
      weightKg: Number(vitalWeight),
      bmi,
      recordedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      recordedBy: `${currentUser.name} (${currentUser.role})`
    });

    setIsAddVitalModalOpen(false);
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient || !noteContent.trim()) return;

    addClinicalNote(activePatient.id, {
      date: new Date().toISOString().replace('T', ' ').slice(0, 16),
      authorName: currentUser.name,
      authorRole: currentUser.role,
      category: noteCategory,
      content: noteContent,
      icdCodes: noteIcdCode ? [noteIcdCode] : undefined
    });

    setNoteContent('');
    setIsAddNoteModalOpen(false);
  };

  const handleSaveMed = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient || !medName.trim()) return;

    addMedication(activePatient.id, {
      name: medName,
      dosage: medDosage || '1 tablet',
      frequency: medFrequency,
      route: medRoute,
      startDate: new Date().toISOString().slice(0, 10),
      prescribingDoctor: currentUser.name,
      active: true,
      instructions: medInstructions || 'Take as directed with water.'
    });

    setMedName('');
    setMedDosage('');
    setMedInstructions('');
    setIsAddMedModalOpen(false);
  };

  const handleSaveLab = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePatient || !labTestName.trim()) return;

    addLabResult(activePatient.id, {
      testName: labTestName,
      category: labCategory,
      date: new Date().toISOString().slice(0, 10),
      resultValue: labResultVal,
      unit: labUnit,
      referenceRange: labRefRange || 'Standard reference interval',
      status: labStatus,
      orderingDoctor: currentUser.name
    });

    setLabTestName('');
    setLabResultVal('');
    setIsAddLabModalOpen(false);
  };

  // Bulk Selection Handlers
  const isAllFilteredSelected = filteredPatients.length > 0 && filteredPatients.every(p => selectedPatientIds.includes(p.id));
  const isSomeFilteredSelected = filteredPatients.some(p => selectedPatientIds.includes(p.id)) && !isAllFilteredSelected;

  const handleToggleSelectAll = () => {
    if (isAllFilteredSelected) {
      const filteredIdSet = new Set(filteredPatients.map(p => p.id));
      setSelectedPatientIds(prev => prev.filter(id => !filteredIdSet.has(id)));
    } else {
      const newIds = Array.from(new Set([...selectedPatientIds, ...filteredPatients.map(p => p.id)]));
      setSelectedPatientIds(newIds);
    }
  };

  const handleTogglePatient = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedPatientIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleClearSelection = () => {
    setSelectedPatientIds([]);
  };

  const handleBatchPrintSelected = () => {
    const patientsToPrint = effectivePatients.filter(p => selectedPatientIds.includes(p.id));
    if (patientsToPrint.length === 0) return;

    logAuditAction(
      'REPORT_EXPORTED',
      `Batch printed clinical summaries for ${patientsToPrint.length} patients (${patientsToPrint.map(p => p.mrn).join(', ')})`,
      undefined,
      `Batch Print (${patientsToPrint.length} patients)`
    );

    printBatchPatientSummaries(patientsToPrint, currentUser);
  };

  return (
    <div className="space-y-6">
      {/* Patient EHR Directory & Detail Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Patient Selector Directory */}
        <div className="lg:col-span-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-teal-700" />
                {t.patientRecords}
              </h2>
              <p className="text-[11px] text-slate-500">
                Encrypted Medical Records ({effectivePatients.length} Registered)
              </p>
            </div>
            <button
              onClick={() => setIsNewPatientModalOpen(true)}
              className="p-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1"
              title="Register Patient"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Register</span>
            </button>
          </div>

          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search by Name, MRN, Diagnosis..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-600"
            />
          </div>

          {/* Bulk Selection & Batch Print Action Bar */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 space-y-2.5">
            <div className="flex items-center justify-between">
              <button
                type="button"
                id="btn-toggle-select-all"
                onClick={handleToggleSelectAll}
                className="flex items-center gap-2 text-xs font-bold text-slate-700 hover:text-teal-700 transition"
                title={isAllFilteredSelected ? "Deselect all filtered patients" : "Select all filtered patients"}
              >
                {isAllFilteredSelected ? (
                  <CheckSquare className="w-4 h-4 text-teal-700" />
                ) : isSomeFilteredSelected ? (
                  <MinusSquare className="w-4 h-4 text-teal-600" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400" />
                )}
                <span>
                  {isAllFilteredSelected ? 'Deselect All' : 'Select All'} ({filteredPatients.length})
                </span>
              </button>

              {selectedPatientIds.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-teal-800 bg-teal-100/80 px-2 py-0.5 rounded-full">
                    {selectedPatientIds.length} selected
                  </span>
                  <button
                    type="button"
                    onClick={handleClearSelection}
                    className="text-[11px] text-slate-500 hover:text-rose-600 font-semibold underline transition"
                  >
                    Clear
                  </button>
                </div>
              )}
            </div>

            {/* Prominent Batch Print Button */}
            {selectedPatientIds.length > 0 && (
              <button
                type="button"
                id="btn-batch-print-selected"
                onClick={handleBatchPrintSelected}
                className="w-full py-2 px-3 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-xs"
                title="Batch print multi-patient clinical summaries & census dossier"
              >
                <Printer className="w-4 h-4" />
                <span>Print Selected ({selectedPatientIds.length} {selectedPatientIds.length === 1 ? 'Patient' : 'Patients'})</span>
              </button>
            )}
          </div>

          {/* Patient Cards List */}
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filteredPatients.map((patient) => {
              const isSelected = activePatient && patient.id === activePatient.id;
              const isChecked = selectedPatientIds.includes(patient.id);
              const condList = Array.isArray(patient.chronicConditions) ? patient.chronicConditions : (Array.isArray(patient.conditions) ? patient.conditions : []);
              return (
                <div
                  key={patient.id}
                  onClick={() => setSelectedPatientId(patient.id)}
                  className={`p-3.5 rounded-2xl border text-xs cursor-pointer transition space-y-1.5 group relative ${
                    isSelected
                      ? 'bg-teal-50/70 border-teal-600 shadow-xs ring-1 ring-teal-600/30'
                      : isChecked
                      ? 'bg-emerald-50/40 border-teal-400 shadow-2xs'
                      : 'bg-slate-50/70 border-slate-200 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 truncate pr-2">
                      <button
                        type="button"
                        onClick={(e) => handleTogglePatient(patient.id, e)}
                        className="p-0.5 text-slate-400 hover:text-teal-700 transition focus:outline-hidden"
                        title={isChecked ? "Deselect for batch print" : "Select for batch print"}
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-teal-700" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-300 group-hover:text-slate-400" />
                        )}
                      </button>
                      <span className="font-bold text-slate-900 text-sm truncate">
                        {patient.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          printPatientCompleteRecord(patient, currentUser);
                        }}
                        title="Print patient records directly to printer"
                        className="p-1 rounded-md text-slate-400 hover:text-teal-700 hover:bg-slate-200 transition"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600">
                        {patient.mrn}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-[11px] text-slate-500 pl-6">
                    <span>{patient.age}y ({patient.gender?.[0] || 'U'})</span>
                    <span>•</span>
                    <span className="font-bold text-rose-700">{patient.bloodType || 'N/A'}</span>
                    <span>•</span>
                    <span className={`px-1.5 py-0.2 rounded-md font-medium text-[10px] ${
                      patient.admissionStatus === 'Inpatient' ? 'bg-indigo-100 text-indigo-800 font-bold' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {patient.admissionStatus}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 truncate pl-6">
                    {condList[0] || 'Routine Health Screening'}
                  </p>

                  <div className="flex items-center justify-between pt-1 text-[10px] pl-6">
                    <span className="text-slate-400 truncate max-w-[140px]">
                      {patient.assignedWard ? patient.assignedWard.split('(')[0] : 'Outpatient'}
                    </span>
                    {patient.isOfflineCached && (
                      <span className="text-emerald-700 font-semibold flex items-center gap-1 bg-emerald-50 px-1.5 py-0.2 rounded-md">
                        <Wifi className="w-2.5 h-2.5" /> Cached
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Full EHR Document View for Selected Patient */}
        <div className="lg:col-span-8 bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-6">
          {activePatient ? (
            <>
              {/* Selected Patient Banner Header */}
              <div className="p-5 bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-3xl space-y-4 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white flex items-center justify-center font-bold text-xl shadow-md">
                      {activePatient.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg sm:text-xl font-black tracking-tight text-white">
                          {activePatient.name}
                        </h2>
                        <span className="font-mono text-xs bg-white/10 px-2.5 py-0.5 rounded-full font-bold text-teal-300">
                          {activePatient.mrn}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300">
                        DOB: {activePatient.dob || activePatient.dateOfBirth || 'N/A'} ({activePatient.age} yrs • {activePatient.gender}) • Blood: <strong className="text-rose-400">{activePatient.bloodType || 'N/A'}</strong>
                      </p>
                    </div>
                  </div>

                  {/* Primary Actions: Direct Print, Wristband Print, Telehealth & Report Modal */}
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      id="btn-direct-print-record"
                      onClick={() => printPatientCompleteRecord(activePatient, currentUser)}
                      className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                      title="Print complete patient clinical record directly to printer"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Print Record</span>
                    </button>

                    <button
                      id="btn-print-wristband-chart"
                      onClick={() => printPatientWristbandAndChart(activePatient)}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs border border-slate-700"
                      title="Print ID wristband and bedside clipboard chart"
                    >
                      <QrCode className="w-4 h-4 text-amber-400" />
                      <span>Wristband / Chart</span>
                    </button>

                    <button
                      id="btn-patient-video-consultation"
                      onClick={() => setIsTelehealthModalOpen(true)}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm border border-slate-700"
                    >
                      <Video className="w-4 h-4 text-cyan-400" />
                      <span className="hidden sm:inline">Telehealth</span>
                    </button>

                    <button
                      id="btn-export-print-report"
                      onClick={() => setIsReportModalOpen(true)}
                      className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs border border-slate-600"
                      title="Open full consultation report and export options"
                    >
                      <FileText className="w-4 h-4" />
                      <span className="hidden sm:inline">Report Preview</span>
                    </button>
                  </div>
                </div>

                {/* Patient Metadata Pills */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-700/80 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400">Ward / Room</span>
                    <p className="font-semibold text-white truncate">
                      {activePatient.assignedWard || 'Outpatient'} {activePatient.assignedBed && `(${activePatient.assignedBed})`}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Insurance Provider</span>
                    <p className="font-semibold text-teal-300 truncate">
                      {activePatient.insurance?.provider || 'Self-Pay / Private'}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Emergency Contact</span>
                    <p className="font-semibold text-white truncate">
                      {activePatient.emergencyContact?.name || 'On Record'}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Security & Privacy</span>
                    <p className="font-bold text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> HIPAA Sealed
                    </p>
                  </div>
                </div>
              </div>

              {/* Navigation Tabs */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-200">
                {[
                  { id: 'vitals' as const, label: 'Vital Signs & Biometrics', icon: Activity, count: (activePatient.vitals || []).length },
                  { id: 'notes' as const, label: 'Clinical Notes (SOAP)', icon: FileText, count: (activePatient.clinicalNotes || []).length },
                  { id: 'meds' as const, label: 'Prescriptions', icon: Pill, count: (activePatient.medications || []).length },
                  { id: 'labs' as const, label: 'Lab Diagnostics', icon: FlaskConical, count: (activePatient.labResults || []).length },
                  { id: 'allergies' as const, label: 'Allergies & Sensitivities', icon: AlertOctagon, count: (activePatient.allergies || []).length },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                        isActive
                          ? 'bg-teal-700 text-white shadow-xs'
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{tab.label}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        isActive ? 'bg-white text-teal-800' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {tab.count}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Tab 1: Vitals & Biometrics */}
              {activeTab === 'vitals' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900">Biometric Vital Signs History</h3>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => printVitalFlowsheet(activePatient, activePatient.vitals || [])}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-slate-300"
                        title="Directly print continuous vital sign flowsheet"
                      >
                        <Printer className="w-3.5 h-3.5 text-teal-700" />
                        Print Flowsheet
                      </button>
                      <button
                        onClick={() => setIsAddVitalModalOpen(true)}
                        className="px-3 py-1.5 bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Record New Vitals
                      </button>
                    </div>
                  </div>

                  {(activePatient.vitals || []).length > 0 ? (
                    <div className="space-y-3">
                      {(activePatient.vitals || []).map((v) => (
                        <div key={v.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                          <div className="flex items-center justify-between text-xs text-slate-500">
                            <span className="font-bold text-slate-800">Recorded: {v.recordedAt}</span>
                            <span>Recorded by: <strong className="text-slate-700">{v.recordedBy}</strong></span>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-center text-xs">
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                                <Heart className="w-3 h-3 text-rose-500" /> BP
                              </span>
                              <p className="font-mono font-bold text-sm text-slate-900 mt-0.5">{v.bloodPressure}</p>
                              <span className="text-[9px] text-slate-400">mmHg</span>
                            </div>
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                                <Activity className="w-3 h-3 text-red-500" /> Heart Rate
                              </span>
                              <p className="font-mono font-bold text-sm text-slate-900 mt-0.5">{v.heartRate}</p>
                              <span className="text-[9px] text-slate-400">bpm</span>
                            </div>
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                                <Thermometer className="w-3 h-3 text-amber-500" /> Temp
                              </span>
                              <p className="font-mono font-bold text-sm text-slate-900 mt-0.5">{v.temperature}</p>
                              <span className="text-[9px] text-slate-400">°C</span>
                            </div>
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
                                <Wind className="w-3 h-3 text-cyan-500" /> SpO2
                              </span>
                              <p className="font-mono font-bold text-sm text-emerald-700 mt-0.5">{v.spo2}%</p>
                              <span className="text-[9px] text-slate-400">O2 Sat</span>
                            </div>
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="text-[10px] text-slate-400">Resp Rate</span>
                              <p className="font-mono font-bold text-sm text-slate-900 mt-0.5">{v.respiratoryRate}</p>
                              <span className="text-[9px] text-slate-400">/min</span>
                            </div>
                            <div className="p-2 bg-white rounded-xl border border-slate-200">
                              <span className="text-[10px] text-slate-400">BMI</span>
                              <p className="font-mono font-bold text-sm text-slate-900 mt-0.5">{v.bmi}</p>
                              <span className="text-[9px] text-slate-400">{v.weightKg}kg / {v.heightCm}cm</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300 text-slate-500 text-xs">
                      No vitals recorded yet. Click "Record New Vitals" to add telemetry data.
                    </div>
                  )}
                </div>
              )}

              {/* Tab 2: Clinical Notes (SOAP) */}
              {activeTab === 'notes' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900">Physician Clinical Progress Notes</h3>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => printClinicalSOAPNotes(activePatient, activePatient.clinicalNotes || [])}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-slate-300"
                        title="Directly print clinical SOAP progress notes"
                      >
                        <Printer className="w-3.5 h-3.5 text-teal-700" />
                        Print SOAP Notes
                      </button>
                      <button
                        onClick={() => setIsAddNoteModalOpen(true)}
                        className="px-3 py-1.5 bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Add Progress Note
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {(activePatient.clinicalNotes || []).map((note) => (
                      <div key={note.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                        <div className="flex items-center justify-between pb-1.5 border-b border-slate-200">
                          <span className="font-bold text-teal-800 text-xs">
                            {note.category} • {note.authorName} ({note.authorRole})
                          </span>
                          <span className="text-slate-500 font-mono text-[11px]">{note.date}</span>
                        </div>
                        <p className="text-slate-800 leading-relaxed text-xs">
                          {note.content || note.note || ''}
                        </p>
                        {note.icdCodes && note.icdCodes.length > 0 && (
                          <div className="flex flex-wrap gap-1.5 pt-1">
                            {note.icdCodes.map((code, i) => (
                              <span key={i} className="text-[10px] font-mono bg-white px-2 py-0.5 rounded-md border border-slate-300 font-medium">
                                {code}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 3: Prescriptions */}
              {activeTab === 'meds' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900">Active Medication & Prescriptions</h3>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => printPrescriptionRx(activePatient, activePatient.medications || [])}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-slate-300"
                        title="Directly print legal Rx prescription pad sheet"
                      >
                        <Printer className="w-3.5 h-3.5 text-teal-700" />
                        Print Rx Pad
                      </button>
                      <button
                        onClick={() => setIsAddMedModalOpen(true)}
                        className="px-3 py-1.5 bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Prescribe Medication
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {(activePatient.medications || []).map((m) => (
                      <div key={m.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-sm">{m.name}</span>
                            <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-bold rounded-md text-[10px]">
                              {m.dosage}
                            </span>
                            <span className="px-2 py-0.5 bg-slate-200 text-slate-700 rounded-md text-[10px]">
                              {m.route}
                            </span>
                          </div>
                          <p className="text-slate-600">{m.frequency} • Prescribed by: <strong className="text-slate-800">{m.prescribingDoctor}</strong></p>
                          <p className="text-slate-500 italic text-[11px]">{m.instructions}</p>
                        </div>

                        <div className="flex items-center gap-2 self-start sm:self-center">
                          <button
                            onClick={() => printPrescriptionRx(activePatient, [m])}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-[10px] border border-slate-300 flex items-center gap-1"
                            title="Print single Rx order"
                          >
                            <Printer className="w-3 h-3 text-teal-700" />
                            Print Rx
                          </button>
                          <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold rounded-full text-[10px]">
                            Active
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 4: Lab Diagnostics */}
              {activeTab === 'labs' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900">Diagnostic Laboratory Results</h3>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => printLabOrderRequisition(activePatient, activePatient.labResults || [])}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-slate-300"
                        title="Directly print lab panel report and requisition"
                      >
                        <Printer className="w-3.5 h-3.5 text-teal-700" />
                        Print Lab Report
                      </button>
                      <button
                        onClick={() => setIsAddLabModalOpen(true)}
                        className="px-3 py-1.5 bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Enter Lab Result
                      </button>
                    </div>
                  </div>

                  <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-slate-100 text-slate-600 text-[11px] uppercase">
                        <tr>
                          <th className="p-3">Test Name & Category</th>
                          <th className="p-3">Result</th>
                          <th className="p-3">Ref Range</th>
                          <th className="p-3">Date</th>
                          <th className="p-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {(activePatient.labResults || []).map((lab) => (
                          <tr key={lab.id} className="hover:bg-slate-50">
                            <td className="p-3">
                              <p className="font-bold text-slate-900">{lab.testName}</p>
                              <span className="text-[10px] text-slate-400">{lab.category}</span>
                            </td>
                            <td className="p-3 font-mono font-bold text-slate-900">
                              {lab.resultValue} {lab.unit}
                            </td>
                            <td className="p-3 text-slate-500 font-mono">
                              {lab.referenceRange}
                            </td>
                            <td className="p-3 text-slate-600">{lab.date}</td>
                            <td className="p-3">
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                lab.status === 'NORMAL' ? 'bg-emerald-100 text-emerald-800' :
                                lab.status === 'CRITICAL' ? 'bg-rose-100 text-rose-800 font-extrabold animate-pulse' : 'bg-amber-100 text-amber-800'
                              }`}>
                                {lab.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Tab 5: Allergies & Sensitivities */}
              {activeTab === 'allergies' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900">Documented Allergies & Drug Sensitivities</h3>
                    <button
                      onClick={() => printPatientCompleteRecord(activePatient, currentUser)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-slate-300"
                    >
                      <Printer className="w-3.5 h-3.5 text-teal-700" />
                      Print Allergy Chart
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(activePatient.allergies || []).map((allergy) => (
                      <div key={allergy.id} className="p-4 bg-rose-50/60 rounded-2xl border border-rose-200 space-y-1 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-rose-950 text-sm">{allergy.allergen}</span>
                          <span className={`px-2 py-0.5 rounded-full font-extrabold text-[10px] ${
                            allergy.severity === 'LIFE_THREATENING' ? 'bg-rose-600 text-white' :
                            allergy.severity === 'SEVERE' ? 'bg-rose-200 text-rose-900' : 'bg-amber-100 text-amber-900'
                          }`}>
                            {allergy.severity}
                          </span>
                        </div>
                        <p className="text-rose-800 text-[11px]">
                          Reaction: <strong className="font-semibold">{allergy.reaction}</strong>
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="p-12 text-center text-slate-400">
              Select a patient from the directory to view complete clinical health records.
            </div>
          )}
        </div>
      </div>

      {/* Consultation Report Printable Modal */}
      {activePatient && (
        <ConsultationReportModal
          patient={activePatient}
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
        />
      )}

      {/* Video Consultation Modal */}
      {activePatient && (
        <VideoConsultationModal
          patient={activePatient}
          isOpen={isTelehealthModalOpen}
          onClose={() => setIsTelehealthModalOpen(false)}
        />
      )}

      {/* Register New Patient Modal */}
      {isNewPatientModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="bg-teal-800 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-xl">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-base">Register Inpatient / Outpatient</h3>
                  <p className="text-xs text-teal-100">Create Encrypted Hospital EMR Record</p>
                </div>
              </div>
              <button 
                onClick={() => setIsNewPatientModalOpen(false)}
                className="p-1 text-teal-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterPatient} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Patient Full Legal Name:</label>
                <input
                  type="text"
                  required
                  value={newPatientName}
                  onChange={(e) => setNewPatientName(e.target.value)}
                  placeholder="e.g. Benjamin Franklin Hayes"
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Date of Birth:</label>
                  <input
                    type="date"
                    required
                    value={newPatientDob}
                    onChange={(e) => setNewPatientDob(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Gender:</label>
                  <select
                    value={newPatientGender}
                    onChange={(e) => setNewPatientGender(e.target.value as any)}
                    className="w-full p-2 rounded-xl border border-slate-300"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Blood Group:</label>
                  <select
                    value={newPatientBlood}
                    onChange={(e) => setNewPatientBlood(e.target.value as any)}
                    className="w-full p-2 rounded-xl border border-slate-300"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Contact Phone:</label>
                  <input
                    type="tel"
                    value={newPatientPhone}
                    onChange={(e) => setNewPatientPhone(e.target.value)}
                    placeholder="+1 (555) 019-2834"
                    className="w-full p-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Insurance Plan:</label>
                  <input
                    type="text"
                    value={newPatientInsurance}
                    onChange={(e) => setNewPatientInsurance(e.target.value)}
                    placeholder="e.g. Aetna PPO Premier"
                    className="w-full p-2 rounded-xl border border-slate-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Primary Clinical Diagnosis / Admission Reason:</label>
                <input
                  type="text"
                  value={newPatientCondition}
                  onChange={(e) => setNewPatientCondition(e.target.value)}
                  placeholder="e.g. Type 2 Diabetes Mellitus, Essential Hypertension"
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewPatientModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl font-bold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl font-bold transition shadow-sm"
                >
                  Register & Open EMR
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Vital Modal */}
      {isAddVitalModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="bg-teal-800 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                <h3 className="font-bold text-sm">Record Patient Vital Signs</h3>
              </div>
              <button onClick={() => setIsAddVitalModalOpen(false)}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSaveVital} className="p-6 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Blood Pressure (mmHg):</label>
                  <input 
                    type="text" 
                    required 
                    value={vitalBp} 
                    onChange={e => setVitalBp(e.target.value)} 
                    placeholder="120/80" 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Heart Rate (bpm):</label>
                  <input 
                    type="number" 
                    required 
                    value={vitalHr} 
                    onChange={e => setVitalHr(Number(e.target.value))} 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Temperature (°C):</label>
                  <input 
                    type="number" 
                    step="0.1" 
                    required 
                    value={vitalTemp} 
                    onChange={e => setVitalTemp(Number(e.target.value))} 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Oxygen Sat (SpO2 %):</label>
                  <input 
                    type="number" 
                    required 
                    value={vitalSpo2} 
                    onChange={e => setVitalSpo2(Number(e.target.value))} 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Respiratory Rate (/min):</label>
                  <input 
                    type="number" 
                    required 
                    value={vitalResp} 
                    onChange={e => setVitalResp(Number(e.target.value))} 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Weight (kg):</label>
                  <input 
                    type="number" 
                    required 
                    value={vitalWeight} 
                    onChange={e => setVitalWeight(Number(e.target.value))} 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddVitalModalOpen(false)} 
                  className="px-3 py-1.5 border rounded-xl text-slate-600"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-1.5 bg-teal-700 text-white rounded-xl font-bold"
                >
                  Save Telemetry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Clinical Progress Note Modal */}
      {isAddNoteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="bg-teal-800 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                <h3 className="font-bold text-sm">Add SOAP Clinical Progress Note</h3>
              </div>
              <button onClick={() => setIsAddNoteModalOpen(false)}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSaveNote} className="p-6 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Note Category:</label>
                <select 
                  value={noteCategory} 
                  onChange={e => setNoteCategory(e.target.value as any)}
                  className="w-full p-2 border rounded-xl"
                >
                  <option value="Progress Note">Progress Note (SOAP)</option>
                  <option value="Consultation Note">Consultation Note</option>
                  <option value="Nursing Note">Nursing Note</option>
                  <option value="Procedure Note">Procedure Note</option>
                  <option value="Discharge Summary">Discharge Summary</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Associated ICD-10 Code (Optional):</label>
                <input 
                  type="text" 
                  value={noteIcdCode} 
                  onChange={e => setNoteIcdCode(e.target.value)} 
                  placeholder="e.g. I10 (Essential Hypertension)" 
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Clinical Evaluation & Management Plan:</label>
                <textarea 
                  required 
                  rows={5} 
                  value={noteContent} 
                  onChange={e => setNoteContent(e.target.value)} 
                  placeholder="Subjective, Objective, Assessment, and Plan details..." 
                  className="w-full p-2.5 border rounded-xl focus:ring-2 focus:ring-teal-600"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddNoteModalOpen(false)} 
                  className="px-3 py-1.5 border rounded-xl text-slate-600"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-1.5 bg-teal-700 text-white rounded-xl font-bold"
                >
                  Sign & Commit Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Medication Modal */}
      {isAddMedModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="bg-teal-800 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Pill className="w-5 h-5" />
                <h3 className="font-bold text-sm">Issue Pharmaceutical Prescription</h3>
              </div>
              <button onClick={() => setIsAddMedModalOpen(false)}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSaveMed} className="p-6 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Pharmaceutical Name:</label>
                <input 
                  type="text" 
                  required 
                  value={medName} 
                  onChange={e => setMedName(e.target.value)} 
                  placeholder="e.g. Lisinopril, Metformin" 
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Dosage:</label>
                  <input 
                    type="text" 
                    required 
                    value={medDosage} 
                    onChange={e => setMedDosage(e.target.value)} 
                    placeholder="e.g. 10mg PO" 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Route:</label>
                  <select 
                    value={medRoute} 
                    onChange={e => setMedRoute(e.target.value as any)} 
                    className="w-full p-2 border rounded-xl"
                  >
                    <option value="Oral">Oral (PO)</option>
                    <option value="IV">Intravenous (IV)</option>
                    <option value="Subcutaneous">Subcutaneous (SC)</option>
                    <option value="Inhalation">Inhalation</option>
                    <option value="Topical">Topical</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Administration Frequency:</label>
                <input 
                  type="text" 
                  value={medFrequency} 
                  onChange={e => setMedFrequency(e.target.value)} 
                  placeholder="e.g. Once Daily, BID with meals" 
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Patient Instructions:</label>
                <input 
                  type="text" 
                  value={medInstructions} 
                  onChange={e => setMedInstructions(e.target.value)} 
                  placeholder="e.g. Take daily in morning with water." 
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddMedModalOpen(false)} 
                  className="px-3 py-1.5 border rounded-xl text-slate-600"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-1.5 bg-teal-700 text-white rounded-xl font-bold"
                >
                  Prescribe & Authorize
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Lab Result Modal */}
      {isAddLabModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="bg-teal-800 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FlaskConical className="w-5 h-5" />
                <h3 className="font-bold text-sm">Enter Diagnostic Laboratory Finding</h3>
              </div>
              <button onClick={() => setIsAddLabModalOpen(false)}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSaveLab} className="p-6 space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Laboratory Test Name:</label>
                <input 
                  type="text" 
                  required 
                  value={labTestName} 
                  onChange={e => setLabTestName(e.target.value)} 
                  placeholder="e.g. Hemoglobin A1c, Serum Creatinine" 
                  className="w-full p-2 border rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Result Value:</label>
                  <input 
                    type="text" 
                    required 
                    value={labResultVal} 
                    onChange={e => setLabResultVal(e.target.value)} 
                    placeholder="e.g. 5.7" 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Measurement Unit:</label>
                  <input 
                    type="text" 
                    value={labUnit} 
                    onChange={e => setLabUnit(e.target.value)} 
                    placeholder="e.g. %, mg/dL, mmol/L" 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Reference Range:</label>
                  <input 
                    type="text" 
                    value={labRefRange} 
                    onChange={e => setLabRefRange(e.target.value)} 
                    placeholder="e.g. 4.0 - 5.6" 
                    className="w-full p-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Diagnostic Status:</label>
                  <select 
                    value={labStatus} 
                    onChange={e => setLabStatus(e.target.value as any)} 
                    className="w-full p-2 border rounded-xl"
                  >
                    <option value="NORMAL">Normal</option>
                    <option value="ABNORMAL">Abnormal</option>
                    <option value="CRITICAL">Critical Flag</option>
                  </select>
                </div>
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setIsAddLabModalOpen(false)} 
                  className="px-3 py-1.5 border rounded-xl text-slate-600"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-1.5 bg-teal-700 text-white rounded-xl font-bold"
                >
                  Save Result
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
