import React, { useState } from 'react';
import { 
  CloudDownload, 
  CloudUpload, 
  Database, 
  ShieldCheck, 
  Clock, 
  HardDrive, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Download, 
  Upload,
  Lock
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { CloudBackupSnapshot } from '../../types';

export const CloudBackupModule: React.FC = () => {
  const { 
    backupSnapshots, 
    triggerCloudBackup, 
    restoreFromSnapshot, 
    downloadDataJson,
    patients, 
    wards, 
    appointments, 
    invoices, 
    auditLogs 
  } = useHospital();

  const { currentUser } = useAuth();
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleCreateSnapshot = async () => {
    setIsBackingUp(true);
    await new Promise((res) => setTimeout(res, 800));
    const newSnap = triggerCloudBackup();
    setIsBackingUp(false);
    setSuccessMessage(`Cloud snapshot created successfully (${newSnap.id}) with SHA-256 integrity seal.`);
    setTimeout(() => setSuccessMessage(null), 4000);
  };

  const lastBackup = backupSnapshots[0]?.timestamp || 'Just now';

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-teal-500/20 text-teal-400 rounded-2xl">
              <CloudDownload className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base sm:text-lg text-white">
                  Cloud-Based Backups & Disaster Recovery (DR) Vault
                </h2>
                <span className="px-2.5 py-0.5 bg-teal-500/20 text-teal-300 border border-teal-500/40 rounded-full text-[10px] font-mono font-bold">
                  Active Replication
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Continuous geo-redundant snapshotting with AES-256 at-rest encryption and instant rollback capabilities.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCreateSnapshot}
              disabled={isBackingUp}
              className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-xs"
            >
              <RefreshCw className={`w-4 h-4 ${isBackingUp ? 'animate-spin' : ''}`} />
              {isBackingUp ? 'Syncing...' : 'Take Cloud Snapshot Now'}
            </button>
            <button
              onClick={downloadDataJson}
              className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              Download Vault JSON
            </button>
          </div>
        </div>

        {/* Snapshot Status Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800 text-xs">
          <div>
            <span className="text-[10px] text-slate-400">Last Successful Sync</span>
            <p className="font-mono font-bold text-sm text-white">{lastBackup}</p>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Geo-Replication Nodes</span>
            <p className="font-bold text-teal-300">US-East (Primary), US-Central (Hot Standby)</p>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Recovery Point Objective (RPO)</span>
            <p className="font-bold text-emerald-400">&lt; 15 Seconds (Real-Time)</p>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Total Encrypted Snapshots</span>
            <p className="font-mono font-bold text-white">{backupSnapshots.length} Stored</p>
          </div>
        </div>
      </div>

      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-2xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Snapshots Table */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
        <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
          <Database className="w-5 h-5 text-teal-700" />
          Cloud Snapshot History & Rollback Points
        </h3>

        <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase font-bold">
              <tr>
                <th className="p-3">Snapshot ID</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Scope / Census</th>
                <th className="p-3">Triggered By</th>
                <th className="p-3">Checksum</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {backupSnapshots.map((snap) => (
                <tr key={snap.id} className="hover:bg-slate-50">
                  <td className="p-3 font-mono font-bold text-slate-900">{snap.id}</td>
                  <td className="p-3 font-mono text-slate-600">{snap.timestamp}</td>
                  <td className="p-3">
                    <span className="font-semibold text-slate-800">
                      {snap.counts.patients} Patients • {snap.counts.wards} Wards • {snap.counts.invoices} Invoices
                    </span>
                    <span className="block text-[10px] text-slate-400">{snap.sizeKb} KB</span>
                  </td>
                  <td className="p-3 font-medium text-slate-700">{snap.triggeredBy}</td>
                  <td className="p-3 font-mono text-[10px] text-teal-800 font-bold">{snap.checksum}</td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => {
                        restoreFromSnapshot(snap.id);
                        setSuccessMessage(`System state successfully restored from snapshot ${snap.id}.`);
                        setTimeout(() => setSuccessMessage(null), 4000);
                      }}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition"
                    >
                      Rollback to this Snapshot
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
