import React, { useState } from 'react';
import { 
  BedDouble, 
  Users, 
  Sparkles, 
  Wrench, 
  CheckCircle2, 
  AlertTriangle, 
  ChevronRight, 
  Search, 
  UserCheck, 
  UserX, 
  ArrowRightLeft,
  X,
  Building,
  HeartPulse
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Bed, BedStatus, Ward } from '../../types';
import { NavTab } from '../layout/Sidebar';

interface WardOccupancyProps {
  onNavigate?: (tab: NavTab) => void;
}

export const WardOccupancy: React.FC<WardOccupancyProps> = ({ onNavigate }) => {
  const { 
    wards, 
    patients, 
    updateBedStatus, 
    totalBedsCount, 
    occupiedBedsCount, 
    availableBedsCount, 
    cleaningBedsCount, 
    overallOccupancyPercent,
    setSelectedPatientId,
    t 
  } = useHospital();

  const { currentUser } = useAuth();
  const [selectedWardId, setSelectedWardId] = useState<string>(wards[0]?.id || '');
  const [selectedBed, setSelectedBed] = useState<{ wardId: string; bed: Bed } | null>(null);
  const [isAdmitModalOpen, setIsAdmitModalOpen] = useState(false);
  const [admitPatientId, setAdmitPatientId] = useState<string>(patients[0]?.id || '');

  const activeWard = wards.find(w => w.id === selectedWardId) || wards[0];

  const handleBedClick = (wardId: string, bed: Bed) => {
    setSelectedBed({ wardId, bed });
  };

  const handleQuickStatusChange = (newStatus: BedStatus) => {
    if (!selectedBed) return;
    if (newStatus === 'Available') {
      updateBedStatus(selectedBed.wardId, selectedBed.bed.id, newStatus, undefined, undefined);
    } else {
      updateBedStatus(selectedBed.wardId, selectedBed.bed.id, newStatus, selectedBed.bed.patientId, selectedBed.bed.patientName);
    }
    setSelectedBed({
      ...selectedBed,
      bed: { ...selectedBed.bed, status: newStatus }
    });
  };

  const handleAdmitToBed = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBed) return;
    const patient = patients.find(p => p.id === admitPatientId);
    if (!patient) return;

    updateBedStatus(
      selectedBed.wardId, 
      selectedBed.bed.id, 
      'Occupied', 
      patient.id, 
      patient.name, 
      new Date().toISOString().replace('T', ' ').slice(0, 16)
    );

    setSelectedBed({
      ...selectedBed,
      bed: {
        ...selectedBed.bed,
        status: 'Occupied',
        patientId: patient.id,
        patientName: patient.name,
        occupiedSince: new Date().toISOString().replace('T', ' ').slice(0, 16)
      }
    });

    setIsAdmitModalOpen(false);
  };

  const handleDischargeFromBed = () => {
    if (!selectedBed) return;
    updateBedStatus(selectedBed.wardId, selectedBed.bed.id, 'Cleaning');
    setSelectedBed({
      ...selectedBed,
      bed: {
        ...selectedBed.bed,
        status: 'Cleaning',
        patientId: undefined,
        patientName: undefined,
        occupiedSince: undefined
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Hospital Occupancy</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1 font-mono">
            {overallOccupancyPercent}%
          </p>
          <p className="text-[11px] text-slate-500 mt-1">{occupiedBedsCount} of {totalBedsCount} Inpatient Beds</p>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-emerald-600 uppercase">Available Immediately</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-emerald-700 mt-1 font-mono">
            {availableBedsCount}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Sanitized & Ready for Intake</p>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-amber-600 uppercase">Turnover / Cleaning</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-amber-700 mt-1 font-mono">
            {cleaningBedsCount}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">Housekeeping Disinfection Active</p>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-indigo-600 uppercase">Active Units</span>
          <p className="text-2xl sm:text-3xl font-extrabold text-indigo-700 mt-1 font-mono">
            {wards.length} Wards
          </p>
          <p className="text-[11px] text-slate-500 mt-1">ICU, Cardio, Surg, Peds, Mat</p>
        </div>
      </div>

      {/* Ward Selector Navigation Tabs */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {wards.map((ward) => {
            const isSelected = ward.id === selectedWardId;
            const occupied = ward.beds.filter(b => b.status === 'Occupied').length;
            const rate = Math.round((occupied / ward.beds.length) * 100);
            return (
              <button
                key={ward.id}
                onClick={() => setSelectedWardId(ward.id)}
                className={`flex items-center gap-2.5 px-4 py-3 rounded-2xl text-xs font-bold transition whitespace-nowrap border ${
                  isSelected
                    ? 'bg-teal-800 text-white border-teal-800 shadow-md shadow-teal-800/20'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span 
                  className="w-2.5 h-2.5 rounded-full shrink-0" 
                  style={{ backgroundColor: isSelected ? '#ffffff' : ward.color }} 
                />
                <span>{ward.name}</span>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-800'
                }`}>
                  {occupied}/{ward.beds.length} ({rate}%)
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected Ward Visual Room / Bed Grid */}
        {activeWard && (
          <div className="space-y-6 pt-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <Building className="w-5 h-5 text-teal-700" />
                  {activeWard.name} ({activeWard.code}) — Floor {activeWard.floor}
                </h3>
                <p className="text-xs text-slate-500">
                  Unit Nurse Station Lead: <strong className="text-slate-800">{activeWard.nurseInCharge}</strong> • Capacity: {activeWard.beds.length} Beds
                </p>
              </div>

              {/* Status Legend */}
              <div className="flex items-center gap-3 text-[11px] font-semibold">
                <span className="flex items-center gap-1.5 text-rose-800">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Occupied
                </span>
                <span className="flex items-center gap-1.5 text-emerald-800">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Available
                </span>
                <span className="flex items-center gap-1.5 text-amber-800">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Cleaning
                </span>
                <span className="flex items-center gap-1.5 text-slate-700">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-400" /> Maintenance
                </span>
              </div>
            </div>

            {/* Interactive Bed Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {activeWard.beds.map((bed) => {
                const isSelected = selectedBed?.bed.id === bed.id;
                return (
                  <div
                    key={bed.id}
                    onClick={() => handleBedClick(activeWard.id, bed)}
                    className={`p-4 rounded-3xl border-2 text-xs transition cursor-pointer space-y-3 ${
                      isSelected
                        ? 'border-teal-600 shadow-md bg-white ring-2 ring-teal-600/20'
                        : bed.status === 'Occupied'
                        ? 'border-rose-200 bg-rose-50/40 hover:bg-rose-50'
                        : bed.status === 'Available'
                        ? 'border-emerald-200 bg-emerald-50/40 hover:bg-emerald-50'
                        : bed.status === 'Cleaning'
                        ? 'border-amber-200 bg-amber-50/40 hover:bg-amber-50'
                        : 'border-slate-200 bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <BedDouble className={`w-4 h-4 ${
                          bed.status === 'Occupied' ? 'text-rose-600' :
                          bed.status === 'Available' ? 'text-emerald-600' :
                          bed.status === 'Cleaning' ? 'text-amber-600' : 'text-slate-500'
                        }`} />
                        <span className="font-bold text-slate-900 font-mono text-sm">
                          {bed.bedNumber}
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        bed.status === 'Occupied' ? 'bg-rose-100 text-rose-800' :
                        bed.status === 'Available' ? 'bg-emerald-100 text-emerald-800' :
                        bed.status === 'Cleaning' ? 'bg-amber-100 text-amber-800' : 'bg-slate-200 text-slate-800'
                      }`}>
                        {bed.status}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-600">
                      <p>Room: <strong className="text-slate-800">{bed.roomNumber}</strong></p>
                      {bed.patientName ? (
                        <p className="font-bold text-slate-900 mt-1 truncate">
                          👤 {bed.patientName}
                        </p>
                      ) : (
                        <p className="text-slate-400 italic mt-1">No Inpatient Assigned</p>
                      )}
                    </div>

                    {bed.occupiedSince && (
                      <p className="text-[10px] text-slate-500 pt-1 border-t border-slate-200">
                        Admitted: {bed.occupiedSince}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Selected Bed Quick Control Drawer / Card */}
      {selectedBed && (
        <div className="bg-slate-900 text-white p-6 rounded-3xl shadow-xl space-y-4 animate-in fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-teal-600/30 text-teal-300 rounded-2xl">
                <BedDouble className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-base text-white">
                  Bed Control: {selectedBed.bed.bedNumber} ({selectedBed.bed.roomNumber})
                </h4>
                <p className="text-xs text-slate-400">
                  Status: <strong className="text-teal-300">{selectedBed.bed.status}</strong>
                  {selectedBed.bed.patientName && ` • Occupant: ${selectedBed.bed.patientName}`}
                </p>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              {selectedBed.bed.status === 'Available' && (
                <button
                  onClick={() => setIsAdmitModalOpen(true)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <UserCheck className="w-4 h-4" />
                  Admit Patient to Bed
                </button>
              )}

              {selectedBed.bed.status === 'Occupied' && (
                <>
                  <button
                    onClick={() => {
                      if (selectedBed.bed.patientId) {
                        setSelectedPatientId(selectedBed.bed.patientId);
                        if (onNavigate) onNavigate('patients');
                      }
                    }}
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-teal-300 rounded-xl text-xs font-bold transition"
                  >
                    Open Patient EHR
                  </button>
                  <button
                    onClick={handleDischargeFromBed}
                    className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                  >
                    <UserX className="w-4 h-4" />
                    Discharge & Mark Cleaning
                  </button>
                </>
              )}

              {selectedBed.bed.status === 'Cleaning' && (
                <button
                  onClick={() => handleQuickStatusChange('Available')}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  Sanitization Complete &rarr; Set Available
                </button>
              )}

              <button
                onClick={() => setSelectedBed(null)}
                className="p-2 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admit Patient Modal */}
      {isAdmitModalOpen && selectedBed && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-teal-700" />
                Admit Patient to {selectedBed.bed.bedNumber}
              </h3>
              <button onClick={() => setIsAdmitModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleAdmitToBed} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Patient to Admit:</label>
                <select
                  value={admitPatientId}
                  onChange={(e) => setAdmitPatientId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-semibold"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.mrn} • Blood: {p.bloodType})
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 bg-teal-50 rounded-2xl border border-teal-100 text-teal-900 text-xs">
                Ward Bed: <strong>{selectedBed.bed.bedNumber} ({selectedBed.bed.roomNumber})</strong>
                <p className="text-[11px] text-teal-700 mt-0.5">
                  Admission will automatically update EHR location tags and trigger nursing station intake.
                </p>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsAdmitModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-xs"
                >
                  Confirm Inpatient Bed Intake
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
