import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Wifi, 
  WifiOff, 
  Globe, 
  Lock, 
  AlertOctagon, 
  HeartHandshake, 
  Bell, 
  ChevronDown, 
  Clock, 
  LogOut,
  RefreshCw,
  Sparkles,
  PlusCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useHospital } from '../../context/HospitalContext';
import { UserRole, Language } from '../../types';
import { GlassBreakModal } from '../security/MfaModal';
import { AccessibilityModal } from '../accessibility/AccessibilityModal';

const LANGUAGE_LABELS: Record<Language, { label: string; flag: string }> = {
  en: { label: 'English (US)', flag: '🇺🇸' },
  es: { label: 'Español (ES)', flag: '🇪🇸' },
  fr: { label: 'Français (FR)', flag: '🇫🇷' },
  zh: { label: '中文 (简体)', flag: '🇨🇳' },
  ar: { label: 'العربية (AR)', flag: '🇸🇦' },
  de: { label: 'Deutsch (DE)', flag: '🇩🇪' },
};

export const Header: React.FC<{ onNavigateAlerts?: () => void }> = ({ onNavigateAlerts }) => {
  const { 
    currentUser, 
    switchRole, 
    openMfaModal, 
    sessionTimeRemaining, 
    resetSessionTimer,
    isGlassBreakActive, 
    cancelGlassBreak,
    glassBreakReason,
    logout
  } = useAuth();

  const { 
    language, 
    setLanguage, 
    t, 
    isOfflineMode, 
    toggleOfflineMode, 
    activeCriticalAlertsCount,
    accessibility
  } = useHospital();

  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [isGlassBreakModalOpen, setIsGlassBreakModalOpen] = useState(false);
  const [isAccessibilityModalOpen, setIsAccessibilityModalOpen] = useState(false);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleRoleSelect = (role: UserRole) => {
    switchRole(role);
    setIsRoleDropdownOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        {/* Urgent Glass-Break active banner if triggered */}
        {isGlassBreakActive && (
          <div className="bg-red-600 text-white px-4 py-2 text-xs font-semibold flex items-center justify-between animate-pulse">
            <div className="flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-white" />
              <span>EMERGENCY GLASS-BREAK MODE ACTIVE — Rationale: {glassBreakReason}</span>
            </div>
            <button
              onClick={cancelGlassBreak}
              className="px-2.5 py-0.5 bg-white text-red-700 hover:bg-red-50 rounded-md font-bold text-xs transition"
            >
              Terminate Override
            </button>
          </div>
        )}

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Hospital Brand */}
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-teal-700 to-cyan-600 flex items-center justify-center text-white shadow-md shadow-teal-700/20">
                <Building2 className="w-6 h-6 sm:w-7 sm:h-7" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="font-extrabold text-base sm:text-xl tracking-tight text-slate-900">
                    {currentUser.organizationName || t.appName}
                  </h1>
                  {currentUser.organizationName ? (
                    <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-teal-100 text-teal-900 border border-teal-300 shadow-2xs">
                      <Sparkles className="w-3 h-3 text-teal-600" />
                      {currentUser.planTier || 'PRO'} SaaS
                    </span>
                  ) : (
                    <span className="hidden md:inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200">
                      <ShieldCheck className="w-3 h-3 text-teal-600" />
                      HIPAA HITECH 256-bit
                    </span>
                  )}
                </div>
                <p className="text-[11px] sm:text-xs text-slate-500 font-medium truncate max-w-[200px] sm:max-w-xs">
                  {currentUser.organizationName ? `${currentUser.department || 'Clinical Node'} • HIPAA Enclave` : t.appSubtitle}
                </p>
              </div>
            </div>

            {/* Quick Status & Control Toolbar */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Offline / Online Sync Pill */}
              <button
                onClick={toggleOfflineMode}
                title={isOfflineMode ? t.offlineStatusOffline : t.offlineStatusOnline}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition ${
                  isOfflineMode
                    ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-xs'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100'
                }`}
              >
                {isOfflineMode ? (
                  <>
                    <WifiOff className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                    <span className="hidden sm:inline">Offline EHR Cache</span>
                  </>
                ) : (
                  <>
                    <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="hidden sm:inline">Cloud Synced</span>
                  </>
                )}
              </button>

              {/* STAT Alert Notification Bell */}
              <button
                onClick={onNavigateAlerts}
                className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition"
                title="Clinical Alerts"
              >
                <Bell className="w-5 h-5" />
                {activeCriticalAlertsCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-bounce">
                    {activeCriticalAlertsCount}
                  </span>
                )}
              </button>

              {/* Senior / Accessibility Toggle Button */}
              <button
                onClick={() => setIsAccessibilityModalOpen(true)}
                className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition ${
                  accessibility.seniorMode || accessibility.highContrast
                    ? 'bg-teal-100 border-teal-300 text-teal-900 font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
                title="Senior Friendly & Accessibility Settings"
              >
                <HeartHandshake className="w-4 h-4 text-teal-700" />
                <span className="hidden md:inline font-medium">Senior UI</span>
              </button>

              {/* Multi-Language Selector */}
              <div className="relative">
                <button
                  onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 transition"
                  title="Language"
                >
                  <Globe className="w-3.5 h-3.5 text-slate-500" />
                  <span>{LANGUAGE_LABELS[language].flag}</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {isLangDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in duration-100">
                    <div className="px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Select Language
                    </div>
                    {Object.entries(LANGUAGE_LABELS).map(([code, info]) => (
                      <button
                        key={code}
                        onClick={() => {
                          setLanguage(code as Language);
                          setIsLangDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition ${
                          language === code ? 'text-teal-700 font-bold bg-teal-50/60' : 'text-slate-700'
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <span>{info.flag}</span>
                          <span>{info.label}</span>
                        </span>
                        {language === code && <span className="w-1.5 h-1.5 rounded-full bg-teal-600" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Session Security Timer */}
              <div 
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-100 rounded-xl text-[11px] font-medium text-slate-600 border border-slate-200"
                title="HIPAA Session Auto-Lock Countdown"
              >
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span className="font-mono font-semibold">{formatTime(sessionTimeRemaining)}</span>
                <button
                  onClick={resetSessionTimer}
                  className="text-teal-700 hover:text-teal-900 ml-1 p-0.5 hover:bg-white rounded-md"
                  title="Extend session"
                >
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>

              {/* Emergency Glass-Break Trigger */}
              <button
                onClick={() => setIsGlassBreakModalOpen(true)}
                className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-bold transition shadow-2xs"
                title="HIPAA Emergency Glass-Break Protocol"
              >
                <AlertOctagon className="w-3.5 h-3.5 text-red-600" />
                <span>Glass Break</span>
              </button>

              {/* Role Switcher & User Profile Menu */}
              <div className="relative">
                <button
                  onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl transition"
                >
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover ring-2 ring-teal-600/30"
                  />
                  <div className="text-left hidden xl:block">
                    <p className="text-xs font-bold text-slate-900 leading-tight">
                      {currentUser.name}
                    </p>
                    <p className="text-[10px] font-medium text-teal-700">
                      {currentUser.role} • {currentUser.department}
                    </p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {isRoleDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-3xl shadow-2xl border border-slate-200 p-2 z-50 animate-in fade-in zoom-in duration-100">
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 mb-2 space-y-1">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-slate-900">{currentUser.name}</p>
                        {currentUser.organizationName && (
                          <span className="text-[9px] font-extrabold text-teal-800 bg-teal-100 px-1.5 py-0.5 rounded-full border border-teal-200">
                            {currentUser.planTier || 'PRO'} TIER
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">{currentUser.email}</p>
                      {currentUser.organizationName && (
                        <p className="text-[10px] text-teal-700 font-semibold truncate flex items-center gap-1 pt-0.5">
                          <Building2 className="w-3 h-3 text-teal-600" />
                          {currentUser.organizationName}
                        </p>
                      )}
                      <div className="mt-2 flex items-center justify-between text-[10px] pt-1 border-t border-slate-200/60">
                        <span className="font-semibold text-slate-600">MFA Status:</span>
                        <span className="text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full">
                          <ShieldCheck className="w-3 h-3" /> Active
                        </span>
                      </div>
                    </div>

                    <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Switch Role (RBAC Simulation)
                    </div>

                    <div className="space-y-1">
                      {[
                        { role: 'ADMIN' as UserRole, title: t.roleAdmin, dept: 'Governance & Security' },
                        { role: 'PHYSICIAN' as UserRole, title: t.rolePhysician, dept: 'Cardiology & Internal' },
                        { role: 'NURSE' as UserRole, title: t.roleNurse, dept: 'ICU & Clinical Vitals' },
                        { role: 'BILLING' as UserRole, title: t.roleBilling, dept: 'Revenue & Insurance' },
                        { role: 'PATIENT' as UserRole, title: t.rolePatient, dept: 'Patient Self-Portal' }
                      ].map((item) => (
                        <button
                          key={item.role}
                          onClick={() => handleRoleSelect(item.role)}
                          className={`w-full text-left p-2.5 rounded-xl text-xs flex items-center justify-between transition ${
                            currentUser.role === item.role
                              ? 'bg-teal-50 text-teal-900 font-bold border border-teal-200'
                              : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <div>
                            <p className="leading-tight">{item.title}</p>
                            <p className="text-[10px] font-normal text-slate-400">{item.dept}</p>
                          </div>
                          {currentUser.role === item.role && (
                            <span className="w-2 h-2 rounded-full bg-teal-600" />
                          )}
                        </button>
                      ))}
                    </div>

                    <div className="border-t border-slate-100 mt-2 pt-2 space-y-1">
                      <button
                        id="btn-header-provision-tenant"
                        onClick={() => {
                          setIsRoleDropdownOpen(false);
                          logout();
                        }}
                        className="w-full text-left p-2 text-xs text-indigo-700 font-semibold hover:bg-indigo-50 rounded-xl flex items-center gap-2 transition"
                      >
                        <PlusCircle className="w-4 h-4 text-indigo-600" />
                        Sign Up New Facility / Clinician
                      </button>

                      <button
                        onClick={() => {
                          openMfaModal();
                          setIsRoleDropdownOpen(false);
                        }}
                        className="w-full text-left p-2 text-xs text-teal-800 font-semibold hover:bg-teal-50 rounded-xl flex items-center gap-2 transition"
                      >
                        <ShieldCheck className="w-4 h-4 text-teal-600" />
                        Verify MFA Passcode
                      </button>

                      <button
                        id="btn-header-signout"
                        onClick={() => {
                          setIsRoleDropdownOpen(false);
                          logout();
                        }}
                        className="w-full text-left p-2 text-xs text-rose-700 font-semibold hover:bg-rose-50 rounded-xl flex items-center gap-2 transition"
                      >
                        <LogOut className="w-4 h-4 text-rose-600" />
                        Sign Out / Switch Account
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <GlassBreakModal 
        isOpen={isGlassBreakModalOpen} 
        onClose={() => setIsGlassBreakModalOpen(false)} 
      />

      <AccessibilityModal 
        isOpen={isAccessibilityModalOpen} 
        onClose={() => setIsAccessibilityModalOpen(false)} 
      />
    </>
  );
};
