import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  Receipt, 
  BedDouble, 
  BellRing, 
  MessageSquare, 
  ShieldAlert, 
  CloudDownload,
  Activity,
  FlaskConical,
  Pill,
  Scan,
  GitFork,
  BrainCircuit,
  Building2
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';

export type NavTab = 
  | 'dashboard' 
  | 'adminBottlenecks'
  | 'triage'
  | 'workflow'
  | 'labs'
  | 'pharmacy'
  | 'scanner'
  | 'patients' 
  | 'appointments' 
  | 'billing' 
  | 'wards' 
  | 'alerts' 
  | 'chat' 
  | 'audit' 
  | 'backup';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const { 
    t, 
    activeCriticalAlertsCount, 
    todayAppointmentsCount,
    pendingLabOrdersCount,
    pendingPharmacyPrescriptionsCount,
    triageAssessments
  } = useHospital();
  const { currentUser } = useAuth();

  const allNavItems: { 
    id: NavTab; 
    label: string; 
    icon: React.FC<{ className?: string }>; 
    badge?: number; 
    badgeColor?: string;
    roles?: string[];
  }[] = [
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
    { id: 'adminBottlenecks', label: 'Bottleneck Monitor', icon: Building2, badge: 1, badgeColor: 'bg-rose-100 text-rose-700 font-bold', roles: ['ADMIN', 'PHYSICIAN'] },
    { id: 'triage', label: 'AI Triage & ICD-10', icon: BrainCircuit, badge: triageAssessments.length, badgeColor: 'bg-teal-100 text-teal-800', roles: ['ADMIN', 'PHYSICIAN', 'NURSE', 'RECEPTIONIST'] },
    { id: 'workflow', label: t.navWorkflow, icon: GitFork, roles: ['ADMIN', 'PHYSICIAN', 'NURSE', 'RECEPTIONIST', 'BILLING', 'LAB_TECHNICIAN', 'PHARMACIST'] },
    { id: 'labs', label: t.navLabs, icon: FlaskConical, badge: pendingLabOrdersCount, badgeColor: 'bg-indigo-100 text-indigo-700', roles: ['ADMIN', 'PHYSICIAN', 'LAB_TECHNICIAN', 'NURSE', 'PATIENT'] },
    { id: 'pharmacy', label: t.navPharmacy, icon: Pill, badge: pendingPharmacyPrescriptionsCount, badgeColor: 'bg-emerald-100 text-emerald-700', roles: ['ADMIN', 'PHYSICIAN', 'PHARMACIST', 'NURSE'] },
    { id: 'scanner', label: t.navBarcodeScanner, icon: Scan, roles: ['ADMIN', 'NURSE', 'PHARMACIST'] },
    { id: 'patients', label: t.navPatients, icon: Users, roles: ['ADMIN', 'PHYSICIAN', 'NURSE', 'RECEPTIONIST', 'LAB_TECHNICIAN', 'BILLING'] },
    { id: 'appointments', label: t.navAppointments, icon: Calendar, badge: todayAppointmentsCount, roles: ['ADMIN', 'PHYSICIAN', 'NURSE', 'RECEPTIONIST', 'PATIENT'] },
    { id: 'billing', label: t.navBilling, icon: Receipt, roles: ['ADMIN', 'BILLING', 'RECEPTIONIST', 'PATIENT'] },
    { id: 'wards', label: t.navWards, icon: BedDouble, roles: ['ADMIN', 'NURSE', 'PHYSICIAN'] },
    { id: 'alerts', label: t.navAlerts, icon: BellRing, badge: activeCriticalAlertsCount, roles: ['ADMIN', 'PHYSICIAN', 'NURSE', 'LAB_TECHNICIAN', 'PHARMACIST'] },
    { id: 'chat', label: t.navChat, icon: MessageSquare },
    { id: 'audit', label: t.navAuditLogs, icon: ShieldAlert, roles: ['ADMIN'] },
    { id: 'backup', label: t.navBackup, icon: CloudDownload, roles: ['ADMIN'] },
  ];

  const navItems = allNavItems.filter(item => {
    if (!item.roles || currentUser.role === 'ADMIN') return true;
    return item.roles.includes(currentUser.role);
  });

  return (
    <aside className="w-64 bg-white border-r border-slate-200 hidden lg:flex flex-col justify-between p-4 min-h-[calc(100vh-5rem)]">
      <div className="space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Clinical Operations
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition group ${
                isActive
                  ? 'bg-teal-700 text-white shadow-md shadow-teal-700/20'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 transition ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-teal-700'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span
                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                    isActive
                      ? 'bg-white text-teal-800'
                      : (item.badgeColor || 'bg-red-100 text-red-700')
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Clinical Telemetry Summary Card */}
      <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5 mt-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-slate-800 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-teal-600 animate-pulse" />
            Live Network
          </span>
          <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-1.5 py-0.5 rounded-md">
            Operational
          </span>
        </div>
        <p className="text-[11px] text-slate-500">
          TLS 1.3 encrypted tunnel with camera BCMA safety & HIPAA audit verification.
        </p>
      </div>
    </aside>
  );
};

export const MobileNav: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const { activeCriticalAlertsCount, pendingLabOrdersCount, pendingPharmacyPrescriptionsCount } = useHospital();

  const mobileTabs: { id: NavTab; label: string; icon: React.FC<{ className?: string }>; badge?: number }[] = [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'workflow', label: 'Journey', icon: GitFork },
    { id: 'labs', label: 'Labs', icon: FlaskConical, badge: pendingLabOrdersCount },
    { id: 'pharmacy', label: 'Pharmacy', icon: Pill, badge: pendingPharmacyPrescriptionsCount },
    { id: 'scanner', label: 'BCMA', icon: Scan },
    { id: 'patients', label: 'EHR', icon: Users },
    { id: 'billing', label: 'Billing', icon: Receipt },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 py-1 px-2 shadow-lg">
      <div className="flex items-center justify-around">
        {mobileTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center py-1 px-1.5 rounded-xl transition relative min-w-[44px] ${
                isActive ? 'text-teal-700 font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'text-teal-700 stroke-[2.5]' : 'text-slate-500'}`} />
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1 -right-2 w-3.5 h-3.5 bg-red-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

