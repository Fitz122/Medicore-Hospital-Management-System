import React, { useState, useEffect, useRef } from 'react';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  PhoneOff, 
  ShieldCheck, 
  Lock, 
  Activity, 
  FileText, 
  Pill, 
  Calendar, 
  Sparkles, 
  Maximize2, 
  Minimize2, 
  Share2, 
  Users, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Heart,
  Thermometer,
  Wind,
  Stethoscope,
  Copy,
  Send,
  MessageSquare
} from 'lucide-react';
import { Patient, User } from '../../types';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';

interface VideoConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: Patient;
}

export const VideoConsultationModal: React.FC<VideoConsultationModalProps> = ({
  isOpen,
  onClose,
  patient
}) => {
  const { addClinicalNote, logAuditAction } = useHospital();
  const { currentUser } = useAuth();

  // Call Controls State
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);
  const [isVideoDisabled, setIsVideoDisabled] = useState<boolean>(false);
  const [isScreenSharing, setIsScreenSharing] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [callStatus, setCallStatus] = useState<'CONNECTING' | 'CONNECTED' | 'ENDED'>('CONNECTED');
  const [activeSidebarTab, setActiveSidebarTab] = useState<'soap' | 'vitals' | 'prescribe' | 'chat'>('soap');

  // Encryption handshake telemetry
  const [encryptionFingerprint] = useState<string>(() => {
    return `SHA256:7F:A9:E2:${Math.random().toString(36).substring(2, 6).toUpperCase()}:${Math.random().toString(36).substring(2, 6).toUpperCase()}:DTLS-SRTP`;
  });

  // SOAP Clinical Notes State
  const [subjective, setSubjective] = useState<string>(
    `Patient presents for scheduled remote follow-up. Reports mild improvements in cardiovascular endurance. No active chest discomfort at rest.`
  );
  const [objective, setObjective] = useState<string>(
    `BP: ${patient.vitals[0]?.bloodPressure || '120/80'} mmHg, HR: ${patient.vitals[0]?.heartRate || 72} bpm, SpO2: ${patient.vitals[0]?.spo2 || 98}%. Alert, oriented x4, no acute respiratory distress during video review.`
  );
  const [assessment, setAssessment] = useState<string>(
    `Primary: ${patient.chronicConditions[0] || 'Essential Hypertension, Benign'}. Condition remains well-managed with current regimen.`
  );
  const [plan, setPlan] = useState<string>(
    `Continue prescribed maintenance therapy. Maintain sodium restriction (<2g/day). Schedule 3-month remote telehealth review.`
  );

  // Quick In-Call Chat Messages
  const [inCallChat, setInCallChat] = useState<Array<{ sender: string; text: string; time: string; isDoctor: boolean }>>([
    { sender: 'System', text: 'End-to-End Encrypted Peer Session Established (AES-256-GCM).', time: '00:01', isDoctor: false },
    { sender: patient.name, text: 'Hello Doctor Vance, can you hear and see me clearly?', time: '00:05', isDoctor: false },
    { sender: currentUser.name, text: 'Good morning! Audio and video are crystal clear. How are you feeling today?', time: '00:12', isDoctor: true }
  ]);
  const [chatInput, setChatInput] = useState<string>('');

  // Call duration counter
  useEffect(() => {
    if (!isOpen || callStatus !== 'CONNECTED') return;
    const timer = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen, callStatus]);

  if (!isOpen) return null;

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setInCallChat(prev => [
      ...prev,
      {
        sender: currentUser.name,
        text: chatInput,
        time: formatDuration(callDuration),
        isDoctor: true
      }
    ]);
    setChatInput('');
  };

  const handleInsertTemplate = (type: 'cardio' | 'postop' | 'general') => {
    if (type === 'cardio') {
      setSubjective('Follow-up for cardiovascular assessment. Patient reports adherence to anti-hypertensives without orthostatic dizziness.');
      setObjective('Heart rhythm regular, peripheral perfusion intact, no lower extremity edema noted on visual inspection.');
      setAssessment('Controlled Hypertension (I10) & Post-cardiac observation.');
      setPlan('Maintain ACE-inhibitor dosage. Re-check lipid panel and serum electrolytes in 6 weeks.');
    } else if (type === 'postop') {
      setSubjective('Post-operative telehealth review. Surgical incision sites clean, dry, and intact with no erythema or purulent drainage.');
      setObjective('Pain score 2/10 at surgical site. Range of motion within expected post-op limits.');
      setAssessment('Healing surgical post-op without signs of wound dehiscence or infection.');
      setPlan('Advance physical activity as tolerated. Resume standard diet. Follow-up clinic appointment in 2 weeks.');
    } else {
      setSubjective('Routine clinical wellness check-in. Patient reports normal energy levels, appetite, and sleep architecture.');
      setObjective('Vitals stable at baseline. General appearance healthy, responsive, and oriented.');
      setAssessment('Routine clinical health maintenance (Z00.00).');
      setPlan('Continue healthy lifestyle practices. Update annual immunizations as indicated.');
    }
  };

  const handleEndCall = () => {
    // 1. Save SOAP note to EHR
    const combinedSoapContent = `[REMOTE TELEHEALTH CONSULTATION - E2EE SESSION]
Duration: ${formatDuration(callDuration)} | Protocol: AES-256-GCM / WebRTC DTLS-SRTP 1.2
Specialist: ${currentUser.name} (${currentUser.department})
Key Fingerprint: ${encryptionFingerprint}

SUBJECTIVE:
${subjective}

OBJECTIVE:
${objective}

ASSESSMENT:
${assessment}

PLAN:
${plan}`;

    addClinicalNote(patient.id, {
      date: new Date().toISOString().split('T')[0],
      authorName: currentUser.name,
      authorRole: currentUser.role,
      category: 'Consultation',
      content: combinedSoapContent,
      note: combinedSoapContent,
      isEncrypted: true
    });

    // 2. Log in HIPAA Audit Trail
    logAuditAction(
      'REMOTE_VIDEO_CONSULTATION_CONDUCTED',
      `Conducted remote video consultation for ${formatDuration(callDuration)}. AES-256-GCM tunnel verified. Fingerprint: ${encryptionFingerprint}. SOAP record committed to EHR.`,
      patient.id,
      patient.name
    );

    setCallStatus('ENDED');
    setTimeout(() => {
      onClose();
    }, 600);
  };

  return (
    <div 
      id="modal-video-consultation"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-2 sm:p-4 overflow-hidden"
    >
      <div className={`bg-slate-900 text-white rounded-3xl shadow-2xl border border-slate-700/80 flex flex-col overflow-hidden transition-all duration-300 w-full ${
        isFullscreen ? 'h-full max-w-full rounded-none' : 'max-w-6xl h-[90vh]'
      }`}>
        
        {/* Top Header Bar with End-to-End Encryption Guarantee */}
        <div className="bg-slate-850 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/20 text-teal-400 rounded-xl border border-teal-500/30">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  Specialist Remote Consultation
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    LIVE ({formatDuration(callDuration)})
                  </span>
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                Patient: <strong className="text-teal-300">{patient.name}</strong> • MRN: <span className="font-mono text-slate-300">{patient.mrn}</span> ({patient.age}y, {patient.gender})
              </p>
            </div>
          </div>

          {/* E2EE Security Badge & Telemetry */}
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-teal-500/40 rounded-xl text-xs text-teal-300">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <div className="text-[11px] leading-tight text-left">
                <p className="font-bold">E2E Encrypted (AES-256-GCM)</p>
                <p className="text-[9px] text-slate-400 font-mono">{encryptionFingerprint}</p>
              </div>
            </div>

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Main Grid: Video Feeds (Left 7-8 cols) + Clinical Telemetry / SOAP HUD (Right 4-5 cols) */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          
          {/* Left Column: Video Stage */}
          <div className="lg:col-span-7 xl:col-span-8 bg-slate-950 p-4 flex flex-col justify-between relative overflow-hidden">
            
            {/* Primary Patient Video View */}
            <div className="relative flex-1 bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 shadow-inner flex items-center justify-center">
              
              {/* Simulated Patient Video Stream */}
              <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-slate-800 to-slate-950">
                <img
                  src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&auto=format&fit=crop&q=80"
                  alt={patient.name}
                  className="w-full h-full object-cover opacity-85 scale-105 filter brightness-95 contrast-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/40 pointer-events-none" />
              </div>

              {/* Patient Live Overlay HUD */}
              <div className="absolute top-3 left-3 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-bold text-white">{patient.name} (Remote)</span>
                <span className="text-[10px] text-slate-400 font-mono">1080p 60fps • 22ms</span>
              </div>

              {/* Patient Live Vitals Overlay Pill */}
              <div className="absolute top-3 right-3 hidden sm:flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 text-[11px] font-mono">
                <span className="text-rose-400 font-bold flex items-center gap-1">
                  <Heart className="w-3 h-3 text-rose-500 animate-pulse" /> {patient.vitals[0]?.heartRate || 72} bpm
                </span>
                <span className="text-slate-500">|</span>
                <span className="text-teal-300 font-bold">
                  SpO2: {patient.vitals[0]?.spo2 || 98}%
                </span>
                <span className="text-slate-500">|</span>
                <span className="text-amber-300 font-bold">
                  BP: {patient.vitals[0]?.bloodPressure || '120/80'}
                </span>
              </div>

              {/* Doctor PiP (Picture-in-Picture) Stream */}
              <div className="absolute bottom-4 right-4 w-36 h-28 sm:w-44 sm:h-32 bg-slate-800 rounded-2xl overflow-hidden border-2 border-teal-500 shadow-2xl z-20 group">
                {isVideoDisabled ? (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-slate-850 text-slate-400 p-2 text-center">
                    <VideoOff className="w-6 h-6 text-slate-500 mb-1" />
                    <span className="text-[10px] font-semibold">Camera Paused</span>
                  </div>
                ) : (
                  <div className="relative w-full h-full">
                    <img
                      src={currentUser.avatar || "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&auto=format&fit=crop&q=80"}
                      alt={currentUser.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-1 left-1 bg-slate-900/80 backdrop-blur-xs px-2 py-0.5 rounded-md text-[9px] font-bold text-teal-300">
                      You ({currentUser.name.split(' ')[0]})
                    </div>
                  </div>
                )}
              </div>

              {/* Dynamic Live Audio Waveform bar at bottom */}
              <div className="absolute bottom-3 left-4 flex items-center gap-1 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 text-xs">
                <span className="text-[10px] text-slate-400 font-semibold mr-1">Mic:</span>
                <div className="flex items-center gap-0.5 h-3">
                  {[40, 75, 100, 60, 90, 45, 80, 50].map((h, i) => (
                    <span
                      key={i}
                      className={`w-1 bg-emerald-400 rounded-full transition-all duration-150 ${isAudioMuted ? 'h-1 bg-slate-600' : ''}`}
                      style={{ height: isAudioMuted ? '3px' : `${h}%` }}
                    />
                  ))}
                </div>
                <span className="text-[10px] text-emerald-400 font-bold ml-1.5 font-mono">Encrypted</span>
              </div>

            </div>

            {/* In-Call Media & Session Control Toolbar */}
            <div className="mt-3 bg-slate-900/90 border border-slate-800 p-3 rounded-2xl flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {/* Microphone Toggle */}
                <button
                  id="btn-toggle-mic"
                  onClick={() => setIsAudioMuted(!isAudioMuted)}
                  className={`p-3 rounded-xl transition flex items-center gap-1.5 text-xs font-bold ${
                    isAudioMuted 
                      ? 'bg-rose-600/90 hover:bg-rose-700 text-white' 
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                  }`}
                  title={isAudioMuted ? 'Unmute Microphone' : 'Mute Microphone'}
                >
                  {isAudioMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  <span className="hidden sm:inline">{isAudioMuted ? 'Muted' : 'Mic On'}</span>
                </button>

                {/* Camera Video Toggle */}
                <button
                  id="btn-toggle-video"
                  onClick={() => setIsVideoDisabled(!isVideoDisabled)}
                  className={`p-3 rounded-xl transition flex items-center gap-1.5 text-xs font-bold ${
                    isVideoDisabled 
                      ? 'bg-rose-600/90 hover:bg-rose-700 text-white' 
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                  }`}
                  title={isVideoDisabled ? 'Start Video' : 'Stop Video'}
                >
                  {isVideoDisabled ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
                  <span className="hidden sm:inline">{isVideoDisabled ? 'Camera Off' : 'Camera On'}</span>
                </button>

                {/* Screen Sharing Toggle */}
                <button
                  onClick={() => setIsScreenSharing(!isScreenSharing)}
                  className={`p-3 rounded-xl transition flex items-center gap-1.5 text-xs font-bold ${
                    isScreenSharing ? 'bg-indigo-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                  title="Share Medical Imaging / Lab Charts"
                >
                  <Share2 className="w-4 h-4" />
                  <span className="hidden md:inline">{isScreenSharing ? 'Sharing EHR' : 'Share Screen'}</span>
                </button>
              </div>

              {/* End Call & Log Action */}
              <div className="flex items-center gap-2">
                <button
                  id="btn-end-video-consultation"
                  onClick={handleEndCall}
                  className="px-5 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-lg shadow-red-600/30 transition flex items-center gap-2"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span>End Call & Commit to EHR</span>
                </button>
              </div>
            </div>

          </div>

          {/* Right Column: In-Call Clinical Workspace & SOAP Editor */}
          <div className="lg:col-span-5 xl:col-span-4 bg-slate-850 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col justify-between overflow-hidden">
            
            {/* Top Workspace Tabs */}
            <div className="p-3 border-b border-slate-800 bg-slate-900 flex items-center gap-1.5">
              {[
                { id: 'soap' as const, label: 'SOAP Notes', icon: FileText },
                { id: 'vitals' as const, label: 'EHR Vitals', icon: Activity },
                { id: 'chat' as const, label: 'In-Call Chat', icon: MessageSquare, count: inCallChat.length },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeSidebarTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveSidebarTab(tab.id)}
                    className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      isActive
                        ? 'bg-teal-600 text-white shadow-sm'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                    {tab.count !== undefined && (
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded-full text-slate-300">
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Tab Body */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              
              {/* TAB 1: Real-Time SOAP Notes */}
              {activeSidebarTab === 'soap' && (
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                      Clinical Consultation Record
                    </span>
                    
                    {/* Quick Insert Templates */}
                    <div className="flex items-center gap-1 text-[10px]">
                      <button
                        type="button"
                        onClick={() => handleInsertTemplate('cardio')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-teal-300 rounded border border-slate-700"
                      >
                        + Cardio
                      </button>
                      <button
                        type="button"
                        onClick={() => handleInsertTemplate('postop')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-teal-300 rounded border border-slate-700"
                      >
                        + Post-Op
                      </button>
                      <button
                        type="button"
                        onClick={() => handleInsertTemplate('general')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-teal-300 rounded border border-slate-700"
                      >
                        + General
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[11px] font-bold text-teal-400 mb-1">
                        S — Subjective (Patient Statements & Symptoms):
                      </label>
                      <textarea
                        rows={2}
                        value={subjective}
                        onChange={(e) => setSubjective(e.target.value)}
                        className="w-full text-xs p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:ring-1 focus:ring-teal-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-teal-400 mb-1">
                        O — Objective (Exam, Video Observations, Vitals):
                      </label>
                      <textarea
                        rows={2}
                        value={objective}
                        onChange={(e) => setObjective(e.target.value)}
                        className="w-full text-xs p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:ring-1 focus:ring-teal-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-teal-400 mb-1">
                        A — Assessment (Clinical Impression & ICD-10):
                      </label>
                      <textarea
                        rows={2}
                        value={assessment}
                        onChange={(e) => setAssessment(e.target.value)}
                        className="w-full text-xs p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:ring-1 focus:ring-teal-500 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-teal-400 mb-1">
                        P — Plan (Therapeutics, e-Prescriptions, Review):
                      </label>
                      <textarea
                        rows={2}
                        value={plan}
                        onChange={(e) => setPlan(e.target.value)}
                        className="w-full text-xs p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-200 focus:ring-1 focus:ring-teal-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: Patient EHR Baseline & Vitals */}
              {activeSidebarTab === 'vitals' && (
                <div className="space-y-4">
                  <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
                    <h4 className="text-xs font-bold text-white flex items-center gap-2">
                      <Stethoscope className="w-4 h-4 text-teal-400" />
                      Active Patient Diagnoses & Conditions
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {patient.chronicConditions.map((cond, idx) => (
                        <span key={idx} className="text-xs bg-slate-800 border border-slate-700 text-teal-300 px-2.5 py-1 rounded-lg">
                          {cond}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
                    <h4 className="text-xs font-bold text-white flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400" />
                      Known Allergies & Sensitivities
                    </h4>
                    {patient.allergies.length > 0 ? (
                      <div className="space-y-1.5">
                        {patient.allergies.map((al, idx) => (
                          <div key={idx} className="text-xs flex items-center justify-between p-2 bg-rose-950/40 border border-rose-900/50 rounded-lg text-rose-200">
                            <span className="font-bold">{al.allergen}</span>
                            <span className="text-[10px] font-mono">{al.severity}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">No known drug allergies (NKDA)</p>
                    )}
                  </div>

                  <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
                    <h4 className="text-xs font-bold text-white flex items-center gap-2">
                      <Pill className="w-4 h-4 text-emerald-400" />
                      Current Active Medications ({patient.medications.length})
                    </h4>
                    <div className="space-y-1.5">
                      {patient.medications.map((med) => (
                        <div key={med.id} className="text-xs p-2 bg-slate-800/80 rounded-lg border border-slate-700 flex items-center justify-between">
                          <div>
                            <span className="font-bold text-white">{med.name}</span>
                            <span className="text-slate-400 ml-1.5">({med.dosage})</span>
                          </div>
                          <span className="text-[10px] text-teal-300 font-semibold">{med.frequency}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: In-Call Encrypted Chat */}
              {activeSidebarTab === 'chat' && (
                <div className="flex flex-col h-full justify-between space-y-3">
                  <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                    {inCallChat.map((msg, index) => (
                      <div
                        key={index}
                        className={`p-2.5 rounded-xl text-xs space-y-0.5 max-w-[90%] ${
                          msg.isDoctor 
                            ? 'ml-auto bg-teal-600 text-white' 
                            : msg.sender === 'System'
                            ? 'mx-auto bg-slate-900 border border-slate-700 text-teal-300 text-[11px] text-center'
                            : 'bg-slate-800 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[10px] opacity-75 font-semibold">
                          <span>{msg.sender}</span>
                          <span>{msg.time}</span>
                        </div>
                        <p>{msg.text}</p>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={handleSendChatMessage} className="flex gap-2 pt-2 border-t border-slate-800">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Type secure in-call message..."
                      className="flex-1 text-xs px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                    <button
                      type="submit"
                      className="p-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl transition"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}

            </div>

            {/* Bottom Audit Notice */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                Auto-appends to HIPAA Audit Trail
              </span>
              <span className="font-mono text-slate-500">Node: TELE-EHR-ENC-1</span>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
