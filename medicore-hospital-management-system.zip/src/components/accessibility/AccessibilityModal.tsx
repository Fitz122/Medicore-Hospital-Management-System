import React from 'react';
import { Volume2, Eye, Type, HeartHandshake, X, Check } from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';

export const AccessibilityModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { accessibility, updateAccessibility, speakText, t } = useHospital();

  if (!isOpen) return null;

  const handleTestSpeech = () => {
    speakText('Senior Accessibility Mode is active. Hospital appointments, medication reminders, and vital signs will be read with clear voice guidance.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
        <div className="bg-gradient-to-r from-teal-700 to-emerald-800 p-6 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl">
              <HeartHandshake className="w-7 h-7 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">{t.seniorFriendlyMode}</h3>
              <p className="text-xs text-teal-100">Accessible Medical Interface & Assisted Living</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-teal-100 hover:text-white hover:bg-white/10 rounded-lg transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Senior Master Toggle */}
          <div className="p-4 bg-teal-50/70 border border-teal-200 rounded-2xl flex items-center justify-between">
            <div className="space-y-1">
              <span className="font-bold text-sm text-teal-950 flex items-center gap-2">
                <HeartHandshake className="w-4 h-4 text-teal-700" />
                Senior / Elderly Mode (Large Touch Targets)
              </span>
              <p className="text-xs text-teal-800">
                Enlarges buttons to minimum 48px, widens click areas, and simplifies layouts for easier reading.
              </p>
            </div>
            <button
              onClick={() => updateAccessibility({ seniorMode: !accessibility.seniorMode })}
              className={`w-14 h-8 flex items-center rounded-full p-1 transition duration-300 ${
                accessibility.seniorMode ? 'bg-teal-700 justify-end' : 'bg-slate-300 justify-start'
              }`}
            >
              <span className="bg-white w-6 h-6 rounded-full shadow-md transform transition" />
            </button>
          </div>

          {/* High Contrast */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
            <div className="space-y-1">
              <span className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Eye className="w-4 h-4 text-slate-700" />
                {t.highContrast}
              </span>
              <p className="text-xs text-slate-600">
                Boosts visual contrast and darkens borders for low-vision clarity and glare reduction.
              </p>
            </div>
            <button
              onClick={() => updateAccessibility({ highContrast: !accessibility.highContrast })}
              className={`w-14 h-8 flex items-center rounded-full p-1 transition duration-300 ${
                accessibility.highContrast ? 'bg-teal-700 justify-end' : 'bg-slate-300 justify-start'
              }`}
            >
              <span className="bg-white w-6 h-6 rounded-full shadow-md transform transition" />
            </button>
          </div>

          {/* Font Sizing Scale */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-2">
              <Type className="w-4 h-4 text-slate-600" />
              {t.fontSize} Sizing
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['normal', 'large', 'extra-large'] as const).map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => updateAccessibility({ fontSize: size })}
                  className={`py-3 px-3 rounded-xl border font-medium text-xs flex items-center justify-center gap-1.5 transition ${
                    accessibility.fontSize === size
                      ? 'border-teal-600 bg-teal-50 text-teal-800 font-bold shadow-xs'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {accessibility.fontSize === size && <Check className="w-3.5 h-3.5" />}
                  <span className="capitalize">{size === 'extra-large' ? 'Extra Large' : size}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Audio Voice Synthesizer */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
            <div className="space-y-1">
              <span className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-teal-700" />
                {t.audioAssistant}
              </span>
              <p className="text-xs text-slate-600">
                Speaks STAT alerts, appointment reminders, and medication schedule aloud.
              </p>
            </div>
            <div className="flex items-center gap-2">
              {accessibility.textToSpeechEnabled && (
                <button
                  onClick={handleTestSpeech}
                  className="px-2.5 py-1 text-xs bg-teal-100 text-teal-800 hover:bg-teal-200 rounded-lg font-medium"
                >
                  Test Voice
                </button>
              )}
              <button
                onClick={() => updateAccessibility({ textToSpeechEnabled: !accessibility.textToSpeechEnabled })}
                className={`w-14 h-8 flex items-center rounded-full p-1 transition duration-300 ${
                  accessibility.textToSpeechEnabled ? 'bg-teal-700 justify-end' : 'bg-slate-300 justify-start'
                }`}
              >
                <span className="bg-white w-6 h-6 rounded-full shadow-md transform transition" />
              </button>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={onClose}
              className="w-full py-3 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl text-sm transition shadow-sm"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
