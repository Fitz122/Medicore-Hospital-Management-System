import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Lock, 
  User, 
  KeyRound, 
  ArrowRight, 
  Stethoscope, 
  FlaskConical, 
  Pill, 
  Receipt, 
  Users, 
  ShieldAlert, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  Eye,
  EyeOff,
  Fingerprint,
  PlusCircle,
  Briefcase,
  Globe,
  Award,
  CreditCard,
  Zap,
  Building,
  Check,
  ChevronRight,
  Shield,
  Layers,
  HeartHandshake
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole, SaaSSubscriptionPlan, SaaSFacilityType, SaaSRegistrationData } from '../../types';

type AuthMode = 'SIGN_IN' | 'SIGN_UP_ORG' | 'JOIN_FACILITY';

export const LoginView: React.FC = () => {
  const { login, signup, availableUsers, registeredUsers } = useAuth();
  
  const [authMode, setAuthMode] = useState<AuthMode>('SIGN_IN');
  
  // Sign In State
  const [selectedRole, setSelectedRole] = useState<UserRole>('ADMIN');
  const [signInEmail, setSignInEmail] = useState<string>('admin.sterling@medicore.health');
  const [signInPassword, setSignInPassword] = useState<string>('••••••••••••');
  const [showSignInPassword, setShowSignInPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // SaaS Organization Sign Up State
  const [orgName, setOrgName] = useState<string>('');
  const [facilityType, setFacilityType] = useState<SaaSFacilityType>('HOSPITAL');
  const [planTier, setPlanTier] = useState<SaaSSubscriptionPlan>('PROFESSIONAL');
  const [cloudRegion, setCloudRegion] = useState<string>('us-east-hipaa');
  const [adminName, setAdminName] = useState<string>('');
  const [signUpRole, setSignUpRole] = useState<UserRole>('ADMIN');
  const [signUpEmail, setSignUpEmail] = useState<string>('');
  const [signUpPassword, setSignUpPassword] = useState<string>('');
  const [signUpDepartment, setSignUpDepartment] = useState<string>('Hospital Governance & Executive');
  const [licenseNumber, setLicenseNumber] = useState<string>('');
  const [acceptBaa, setAcceptBaa] = useState<boolean>(true);

  // Join Facility State
  const [inviteCode, setInviteCode] = useState<string>('HOSP-PACIFIC-8821');
  const [joinName, setJoinName] = useState<string>('');
  const [joinEmail, setJoinEmail] = useState<string>('');
  const [joinPassword, setJoinPassword] = useState<string>('');
  const [joinRole, setJoinRole] = useState<UserRole>('PHYSICIAN');
  const [joinDept, setJoinDept] = useState<string>('Cardiology & Internal Medicine');

  // Async & UI Feedback state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [provisioningStep, setProvisioningStep] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const roleProfiles: Array<{
    role: UserRole;
    title: string;
    department: string;
    icon: React.FC<{ className?: string }>;
    color: string;
    description: string;
    defaultEmail: string;
  }> = [
    {
      role: 'ADMIN',
      title: 'Hospital Administrator',
      department: 'Executive Governance & Security',
      icon: ShieldAlert,
      color: 'bg-indigo-600 text-white',
      description: 'Full oversight: Department Bottlenecks, HIPAA audit trail, EHR census, Cloud recovery',
      defaultEmail: 'admin.sterling@medicore.health'
    },
    {
      role: 'PHYSICIAN',
      title: 'Attending Specialist (MD)',
      department: 'Cardiovascular & Internal Medicine',
      icon: Stethoscope,
      color: 'bg-teal-700 text-white',
      description: 'Patient EHR records, Remote Encrypted Video Consultations, AI Triage, e-Prescribing',
      defaultEmail: 'e.vance@medicore.health'
    },
    {
      role: 'NURSE',
      title: 'Clinical Care Nurse (RN)',
      department: 'Critical Care ICU & Inpatient Wards',
      icon: Users,
      color: 'bg-cyan-700 text-white',
      description: 'Biometrics logging, Bed heatmap allocation, Optical BCMA safety scanning, Alerts',
      defaultEmail: 'm.holloway@medicore.health'
    },
    {
      role: 'LAB_TECHNICIAN',
      title: 'Pathology Diagnostics (MLS)',
      department: 'Diagnostic Pathology & Chemistry',
      icon: FlaskConical,
      color: 'bg-purple-700 text-white',
      description: 'Specimen processing, Printable Diagnostic Reports with Encrypted QR Integrity',
      defaultEmail: 'd.okafor@medicore.health'
    },
    {
      role: 'PHARMACIST',
      title: 'Clinical Pharmacist (PharmD)',
      department: 'Central Pharmacy & Dispensing',
      icon: Pill,
      color: 'bg-emerald-700 text-white',
      description: 'Prescription queue verification, BCMA barcode validation, Drug interactions',
      defaultEmail: 'm.lin@medicore.health'
    },
    {
      role: 'BILLING',
      title: 'Revenue Cycle Specialist (CPC)',
      department: 'Patient Accounts & Insurance Claims',
      icon: Receipt,
      color: 'bg-amber-700 text-white',
      description: 'CPT/ICD-10 fee schedules, Split billing, Same-day outpatient cashier clearance',
      defaultEmail: 's.chen@medicore.health'
    }
  ];

  const handleRoleSelect = (role: UserRole, email: string) => {
    setSelectedRole(role);
    setSignInEmail(email);
    setSignInPassword('••••••••••••');
    setError(null);
  };

  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signInEmail.trim()) {
      setError('Please enter your institutional email or staff username.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    setTimeout(() => {
      login(signInEmail, signInPassword);
      setIsSubmitting(false);
    }, 400);
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orgName.trim() || !adminName.trim() || !signUpEmail.trim()) {
      setError('Please fill in all required organization and clinician fields.');
      return;
    }

    if (!acceptBaa) {
      setError('You must accept the HIPAA Business Associate Agreement (BAA) to provision clinical tenant.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    // Multi-stage simulated HIPAA cloud provisioning experience
    setProvisioningStep('1/3: Provisioning Dedicated HIPAA Multi-Tenant Enclave...');
    
    setTimeout(() => {
      setProvisioningStep('2/3: Configuring Zero-Trust RBAC & 256-Bit Telehealth Keys...');
      
      setTimeout(() => {
        setProvisioningStep('3/3: Initializing Practice Workspace & Clinical Data Stores...');
        
        setTimeout(() => {
          const regData: SaaSRegistrationData = {
            organizationName: orgName,
            facilityType,
            planTier,
            adminName,
            email: signUpEmail,
            password: signUpPassword,
            role: signUpRole,
            department: signUpDepartment,
            licenseNumber: licenseNumber || `NPI-${Math.floor(1000000000 + Math.random() * 9000000000)}`,
            cloudRegion,
            isTrial: true
          };

          const result = signup(regData);
          setIsSubmitting(false);
          setProvisioningStep(null);

          if (!result.success) {
            setError(result.error || 'Failed to complete registration.');
          }
        }, 600);
      }, 600);
    }, 600);
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinName.trim() || !joinEmail.trim() || !inviteCode.trim()) {
      setError('Please provide your name, institutional email, and facility invite code.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    setProvisioningStep('Validating Facility Code & Enrolling Clinician...');

    setTimeout(() => {
      const regData: SaaSRegistrationData = {
        organizationName: `Facility [${inviteCode.trim().toUpperCase()}]`,
        facilityType: 'HOSPITAL',
        planTier: 'ENTERPRISE',
        adminName: joinName,
        email: joinEmail,
        password: joinPassword,
        role: joinRole,
        department: joinDept,
        licenseNumber: `NPI-${Math.floor(1000000000 + Math.random() * 9000000000)}`,
        inviteCode: inviteCode.trim()
      };

      const result = signup(regData);
      setIsSubmitting(false);
      setProvisioningStep(null);

      if (!result.success) {
        setError(result.error || 'Failed to join facility.');
      }
    }, 900);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-center py-10 sm:px-6 lg:px-8 relative overflow-hidden font-sans">
      {/* Subtle background ambient mesh */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-teal-900/30 via-slate-900 to-slate-950 pointer-events-none" />
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-teal-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-5xl z-10 px-4">
        {/* Header Branding */}
        <div className="text-center space-y-3 mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-3xl bg-gradient-to-tr from-teal-600 to-cyan-500 shadow-xl shadow-teal-500/20 text-white mx-auto">
            <Building2 className="w-7 h-7" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            MediCore Health SaaS
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
            Next-Generation Cloud Clinical Operating System for Hospitals, Multi-Specialty Clinics & Diagnostic Networks
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1 text-[11px] font-medium text-slate-400">
            <span className="flex items-center gap-1 bg-slate-800/80 border border-slate-700 px-2.5 py-1 rounded-full text-teal-300">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
              HIPAA / HITECH 256-bit Encrypted
            </span>
            <span className="bg-slate-800/80 border border-slate-700 px-2.5 py-1 rounded-full text-slate-300">
              CLIA / CAP Pathology Accredited
            </span>
            <span className="bg-slate-800/80 border border-slate-700 px-2.5 py-1 rounded-full text-slate-300">
              SOC-2 Type II Certified
            </span>
          </div>
        </div>

        {/* Mode Selector Navigation Tabs (Sign In vs Sign Up Organization vs Join Facility) */}
        <div className="flex items-center justify-center mb-6">
          <div className="bg-slate-800/90 p-1.5 rounded-2xl border border-slate-700 flex flex-wrap items-center gap-1 shadow-lg max-w-2xl w-full">
            <button
              id="tab-mode-signin"
              onClick={() => {
                setAuthMode('SIGN_IN');
                setError(null);
              }}
              className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                authMode === 'SIGN_IN'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Sign In (Staff SSO)</span>
            </button>

            <button
              id="tab-mode-signup"
              onClick={() => {
                setAuthMode('SIGN_UP_ORG');
                setError(null);
              }}
              className={`flex-1 min-w-[180px] py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                authMode === 'SIGN_UP_ORG'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5 text-amber-300" />
              <span>Create Practice (Free Trial)</span>
            </button>

            <button
              id="tab-mode-join"
              onClick={() => {
                setAuthMode('JOIN_FACILITY');
                setError(null);
              }}
              className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                authMode === 'JOIN_FACILITY'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/50'
              }`}
            >
              <Building className="w-3.5 h-3.5" />
              <span>Join with Facility Code</span>
            </button>
          </div>
        </div>

        {/* Global Error Notice */}
        {error && (
          <div className="mb-4 p-3.5 bg-rose-950/70 border border-rose-600/60 rounded-2xl text-xs text-rose-200 flex items-center gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Provisioning Progress Modal / Banner */}
        {provisioningStep && (
          <div className="mb-4 p-4 bg-teal-950/80 border border-teal-500/80 rounded-2xl text-xs text-teal-200 flex items-center gap-3 animate-pulse shadow-xl">
            <div className="w-5 h-5 border-2 border-teal-400 border-t-transparent rounded-full animate-spin shrink-0" />
            <div className="space-y-0.5">
              <p className="font-bold text-white text-sm">{provisioningStep}</p>
              <p className="text-[11px] text-teal-300">Allocating encrypted tenant storage and initializing clinical protocols...</p>
            </div>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 1: SIGN IN (STAFF SSO & RBAC PRESETS) */}
        {/* ------------------------------------------------------------- */}
        {authMode === 'SIGN_IN' && (
          <div className="bg-slate-800/90 border border-slate-700 rounded-3xl shadow-2xl backdrop-blur-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
            
            {/* Left: Role Persona Fast-Switch Selector (7 cols) */}
            <div className="lg:col-span-7 p-6 sm:p-8 border-b lg:border-b-0 lg:border-r border-slate-700 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <User className="w-4 h-4 text-teal-400" />
                    Select Clinical Persona (RBAC Simulation)
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Choose an institutional profile to experience role-specific privileges.
                  </p>
                </div>
              </div>

              {/* Registered custom accounts banner if any exist */}
              {registeredUsers.length > 0 && (
                <div className="p-3 bg-teal-950/50 border border-teal-700/60 rounded-2xl space-y-2">
                  <span className="text-[10px] font-bold text-teal-400 uppercase tracking-wider block">
                    Your Newly Created SaaS Accounts ({registeredUsers.length})
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {registeredUsers.map(regUser => (
                      <button
                        key={regUser.id}
                        type="button"
                        onClick={() => {
                          setSelectedRole(regUser.role);
                          setSignInEmail(regUser.email);
                          setSignInPassword('••••••••••••');
                        }}
                        className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2.5 ${
                          signInEmail === regUser.email
                            ? 'bg-teal-900/60 border-teal-400 text-white'
                            : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:border-slate-600'
                        }`}
                      >
                        <img src={regUser.avatar} alt="" className="w-7 h-7 rounded-full object-cover ring-1 ring-teal-500" />
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold truncate">{regUser.name}</p>
                          <p className="text-[10px] text-teal-400 truncate">{regUser.organizationName}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {roleProfiles.map((prof) => {
                  const isSelected = selectedRole === prof.role && !registeredUsers.some(r => r.email === signInEmail);
                  const Icon = prof.icon;
                  return (
                    <button
                      key={prof.role}
                      type="button"
                      id={`login-role-${prof.role.toLowerCase()}`}
                      onClick={() => handleRoleSelect(prof.role, prof.defaultEmail)}
                      className={`p-3.5 rounded-2xl text-left transition-all border flex flex-col justify-between ${
                        isSelected
                          ? 'bg-teal-950/70 border-teal-500 shadow-md ring-1 ring-teal-500'
                          : 'bg-slate-900/60 border-slate-700/80 hover:bg-slate-900 hover:border-slate-600'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <div className={`p-2 rounded-xl ${prof.color}`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          {isSelected && (
                            <span className="text-[10px] font-bold text-teal-300 bg-teal-500/20 px-2 py-0.5 rounded-full border border-teal-500/30 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> Selected
                            </span>
                          )}
                        </div>
                        <h3 className="text-xs font-bold text-white">{prof.title}</h3>
                        <p className="text-[10px] text-teal-400/90 font-medium">{prof.department}</p>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                        {prof.description}
                      </p>
                    </button>
                  );
                })}
              </div>

              <div className="p-3 bg-slate-900/80 rounded-2xl border border-slate-700/60 text-xs text-slate-400 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">
                  Want to register your own hospital or clinic? Click <button onClick={() => setAuthMode('SIGN_UP_ORG')} className="text-teal-400 underline font-bold hover:text-teal-300">Create Practice</button> above to launch a dedicated multi-tenant instance.
                </p>
              </div>
            </div>

            {/* Right: Institutional Authentication Form (5 cols) */}
            <div className="lg:col-span-5 p-6 sm:p-8 bg-slate-850 flex flex-col justify-between space-y-6">
              <div>
                <div className="border-b border-slate-700/80 pb-4">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 bg-teal-950/60 px-2 py-0.5 rounded-md border border-teal-800/50">
                    Institutional SSO
                  </span>
                  <h3 className="text-base font-bold text-white mt-1.5">
                    Clinical User Login
                  </h3>
                  <p className="text-xs text-slate-400">
                    Secure single sign-on access to hospital EHR & diagnostics.
                  </p>
                </div>

                <form onSubmit={handleSignInSubmit} className="mt-5 space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Institutional Email / Staff ID
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        id="login-input-email"
                        value={signInEmail}
                        onChange={(e) => setSignInEmail(e.target.value)}
                        placeholder="e.g. staff.member@medicore.health"
                        required
                        className="w-full pl-10 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-300">
                        Security Password / Passcode
                      </label>
                      <span className="text-[10px] text-teal-400 hover:text-teal-300 cursor-pointer">
                        SmartCard / PIV
                      </span>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type={showSignInPassword ? 'text' : 'password'}
                        id="login-input-password"
                        value={signInPassword}
                        onChange={(e) => setSignInPassword(e.target.value)}
                        required
                        className="w-full pl-10 pr-10 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignInPassword(!showSignInPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                      >
                        {showSignInPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="rounded bg-slate-900 border-slate-700 text-teal-600 focus:ring-teal-500"
                      />
                      <span>Remember terminal</span>
                    </label>
                    <span className="text-[11px] text-teal-400 flex items-center gap-1">
                      <Fingerprint className="w-3.5 h-3.5" /> Biometrics Enabled
                    </span>
                  </div>

                  <button
                    type="submit"
                    id="btn-login-submit"
                    disabled={isSubmitting}
                    className="w-full py-3 px-4 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-teal-600/30 transition flex items-center justify-center gap-2 mt-2 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Authenticating Credentials...</span>
                    ) : (
                      <>
                        <span>Sign In to Clinical Workspace</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              </div>

              <div className="pt-4 border-t border-slate-700/80 text-[11px] text-slate-500 text-center space-y-1">
                <p>Protected by Enterprise Zero-Trust Gateway</p>
                <p className="font-mono text-[10px] text-slate-400">Node ID: MC-HOSP-AUTH-09 • Session TLS 1.3</p>
              </div>
            </div>

          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 2: CREATE SAAS ORGANIZATION / 14-DAY FREE TRIAL */}
        {/* ------------------------------------------------------------- */}
        {authMode === 'SIGN_UP_ORG' && (
          <div className="bg-slate-800/90 border border-slate-700 rounded-3xl shadow-2xl backdrop-blur-xl overflow-hidden p-6 sm:p-8 space-y-6">
            
            <div className="border-b border-slate-700 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 px-2.5 py-0.5 rounded-full border border-amber-800/60 inline-block mb-1">
                  14-Day Free Clinical Trial • No Credit Card Required
                </span>
                <h2 className="text-xl font-bold text-white">
                  Register New Hospital, Clinic, or Practice
                </h2>
                <p className="text-xs text-slate-400">
                  Instantly provision a HIPAA-compliant tenant with AI Triage, E2EE Telehealth, and Barcode Safety.
                </p>
              </div>
              
              <div className="flex items-center gap-2 text-xs text-teal-400 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-slate-700">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Instant Provisioning in ~2s</span>
              </div>
            </div>

            <form onSubmit={handleSignUpSubmit} className="space-y-6">
              
              {/* Step 1: Organization Details & Facility Type */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Building2 className="w-4 h-4 text-teal-400" />
                  1. Healthcare Facility & Organization
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Organization / Hospital / Practice Name *
                    </label>
                    <input
                      type="text"
                      id="signup-org-name"
                      value={orgName}
                      onChange={(e) => setOrgName(e.target.value)}
                      placeholder="e.g. Pacific Crest Health System"
                      required
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Facility Architecture & Care Model
                    </label>
                    <select
                      value={facilityType}
                      onChange={(e) => setFacilityType(e.target.value as SaaSFacilityType)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                    >
                      <option value="HOSPITAL">General Hospital & Inpatient Medical Center</option>
                      <option value="OUTPATIENT_CLINIC">Outpatient Specialty & Primary Care Clinic</option>
                      <option value="URGENT_CARE">Urgent Care & Immediate Walk-In Center</option>
                      <option value="DIAGNOSTIC_LAB">Diagnostic Pathology & Clinical Laboratory</option>
                      <option value="TELEHEALTH_GROUP">Telehealth & Remote Virtual Practice</option>
                      <option value="SPECIALTY_SURGICAL">Ambulatory Surgery Center (ASC)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Step 2: SaaS Tier Selection */}
              <div className="space-y-3 pt-2 border-t border-slate-700/80">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-teal-400" />
                  2. Select SaaS Subscription Plan
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {[
                    {
                      id: 'STARTER' as SaaSSubscriptionPlan,
                      name: 'Starter Practice',
                      price: '$199',
                      period: '/month',
                      badge: 'Solo & Small Clinics',
                      features: ['Up to 5 Practitioners', 'EHR Patient Records', 'Appointment Scheduling', 'e-Prescribing & Pharmacy', 'HIPAA 256-bit Cloud']
                    },
                    {
                      id: 'PROFESSIONAL' as SaaSSubscriptionPlan,
                      name: 'Professional Network',
                      price: '$599',
                      period: '/month',
                      badge: 'Most Popular',
                      highlight: true,
                      features: ['Up to 25 Practitioners', 'AI Symptom Triage & ICD-10', 'E2EE Remote Video Consults', 'BCMA Optical Barcode Scanner', 'Printable Diagnostic QR Reports']
                    },
                    {
                      id: 'ENTERPRISE' as SaaSSubscriptionPlan,
                      name: 'Enterprise Health System',
                      price: '$1,499',
                      period: '/month',
                      badge: 'Hospitals & Networks',
                      features: ['Unlimited Providers & Beds', 'Department Bottleneck Radar', 'Multi-Ward Real-Time Census', 'Automated CPT Split Billing', '99.99% Dedicated Cloud SLA']
                    }
                  ].map((plan) => {
                    const isSelected = planTier === plan.id;
                    return (
                      <div
                        key={plan.id}
                        onClick={() => setPlanTier(plan.id)}
                        className={`p-4 rounded-2xl border transition-all cursor-pointer relative flex flex-col justify-between ${
                          isSelected
                            ? 'bg-teal-950/80 border-teal-400 ring-2 ring-teal-500 shadow-lg'
                            : 'bg-slate-900/80 border-slate-700 hover:border-slate-600'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-1 mb-1.5">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-teal-300 bg-teal-900/60 px-2 py-0.5 rounded-full border border-teal-700/60">
                              {plan.badge}
                            </span>
                            {isSelected && (
                              <CheckCircle2 className="w-4 h-4 text-teal-400" />
                            )}
                          </div>
                          
                          <h4 className="font-bold text-sm text-white">{plan.name}</h4>
                          <div className="mt-1 flex items-baseline gap-1">
                            <span className="text-xl font-black text-white">{plan.price}</span>
                            <span className="text-xs text-slate-400">{plan.period}</span>
                          </div>

                          <ul className="mt-3 space-y-1.5 text-[11px] text-slate-300">
                            {plan.features.map((feat, idx) => (
                              <li key={idx} className="flex items-center gap-1.5">
                                <Check className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                                <span>{feat}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="mt-4 pt-3 border-t border-slate-700/60 text-[10px] text-teal-400 font-semibold flex items-center justify-between">
                          <span>Includes 14-Day Free Trial</span>
                          <span>Cancel Anytime</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Step 3: Administrator & Primary Clinician Details */}
              <div className="space-y-3 pt-2 border-t border-slate-700/80">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Stethoscope className="w-4 h-4 text-teal-400" />
                  3. Primary Administrator / Lead Clinician Profile
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Full Name & Title *
                    </label>
                    <input
                      type="text"
                      id="signup-admin-name"
                      value={adminName}
                      onChange={(e) => setAdminName(e.target.value)}
                      placeholder="e.g. Dr. Katherine Price, MD"
                      required
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Clinical Role
                    </label>
                    <select
                      value={signUpRole}
                      onChange={(e) => setSignUpRole(e.target.value as UserRole)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                    >
                      <option value="ADMIN">Hospital Administrator / Executive</option>
                      <option value="PHYSICIAN">Attending Physician / Specialist (MD/DO)</option>
                      <option value="NURSE">Clinical Care Nurse (RN/NP)</option>
                      <option value="LAB_TECHNICIAN">Diagnostic Pathology Specialist (MLS)</option>
                      <option value="PHARMACIST">Clinical Pharmacist (PharmD)</option>
                      <option value="BILLING">Revenue & Billing Specialist (CPC)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Primary Department
                    </label>
                    <input
                      type="text"
                      value={signUpDepartment}
                      onChange={(e) => setSignUpDepartment(e.target.value)}
                      placeholder="e.g. Emergency Medicine / Cardiology"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Work / Institutional Email *
                    </label>
                    <input
                      type="email"
                      id="signup-email"
                      value={signUpEmail}
                      onChange={(e) => setSignUpEmail(e.target.value)}
                      placeholder="k.price@pacificcrest.health"
                      required
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      Password *
                    </label>
                    <input
                      type="password"
                      id="signup-password"
                      value={signUpPassword}
                      onChange={(e) => setSignUpPassword(e.target.value)}
                      placeholder="••••••••••••"
                      required
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      NPI / Medical License # (Optional)
                    </label>
                    <input
                      type="text"
                      value={licenseNumber}
                      onChange={(e) => setLicenseNumber(e.target.value)}
                      placeholder="e.g. NPI-194029481"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Step 4: Cloud Region & BAA Agreement */}
              <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-700 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-teal-400" />
                    <span className="font-bold text-slate-300">Data Residency Cloud Region:</span>
                  </div>
                  <select
                    value={cloudRegion}
                    onChange={(e) => setCloudRegion(e.target.value)}
                    className="px-3 py-1.5 bg-slate-800 border border-slate-600 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="us-east-hipaa">🇺🇸 US-East (N. Virginia HIPAA Compliant Cloud)</option>
                    <option value="us-west-hipaa">🇺🇸 US-West (Oregon HITECH Enclave)</option>
                    <option value="eu-central-gdpr">🇪🇺 EU-Central (Frankfurt GDPR / BSI Cloud)</option>
                    <option value="ap-southwest">🇸🇬 AP-Southeast (Singapore MedTech Zone)</option>
                  </select>
                </div>

                <label className="flex items-start gap-2.5 cursor-pointer pt-2 border-t border-slate-700/60 text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={acceptBaa}
                    onChange={(e) => setAcceptBaa(e.target.checked)}
                    className="mt-0.5 rounded bg-slate-800 border-slate-600 text-teal-600 focus:ring-teal-500"
                  />
                  <span>
                    I confirm authority to bind this organization and agree to the <strong>HIPAA Business Associate Agreement (BAA)</strong>, SOC-2 Data Governance Standards, and 14-day trial terms.
                  </span>
                </label>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setAuthMode('SIGN_IN')}
                  className="text-xs font-semibold text-slate-400 hover:text-white"
                >
                  ← Back to Existing Staff Login
                </button>

                <button
                  type="submit"
                  id="btn-signup-org-submit"
                  disabled={isSubmitting}
                  className="py-3 px-6 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-teal-600/30 transition flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>Provisioning Instance...</span>
                  ) : (
                    <>
                      <span>Launch 14-Day Free Practice Trial</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 3: JOIN EXISTING FACILITY WITH INVITE CODE */}
        {/* ------------------------------------------------------------- */}
        {authMode === 'JOIN_FACILITY' && (
          <div className="bg-slate-800/90 border border-slate-700 rounded-3xl shadow-2xl backdrop-blur-xl overflow-hidden p-6 sm:p-8 space-y-6 max-w-2xl mx-auto">
            
            <div className="border-b border-slate-700 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400 bg-teal-950/60 px-2.5 py-0.5 rounded-full border border-teal-800/60 inline-block mb-1">
                Facility Network Enrollment
              </span>
              <h2 className="text-xl font-bold text-white">
                Join an Existing Hospital or Practice
              </h2>
              <p className="text-xs text-slate-400">
                Enter the facility invite code provided by your hospital IT or department director.
              </p>
            </div>

            <form onSubmit={handleJoinSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Facility Invite Code / Node ID *
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    id="input-join-facility-code"
                    value={inviteCode}
                    onChange={(e) => setInviteCode(e.target.value)}
                    placeholder="e.g. HOSP-PACIFIC-8821"
                    required
                    className="w-full pl-10 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono tracking-wider"
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Demo Invite Codes: <code className="text-teal-400">HOSP-PACIFIC-8821</code> or <code className="text-teal-400">CLINIC-EAST-102</code>
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Your Full Name & Credential *
                  </label>
                  <input
                    type="text"
                    value={joinName}
                    onChange={(e) => setJoinName(e.target.value)}
                    placeholder="e.g. Dr. Raymond Hayes, MD"
                    required
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Assigned Clinical Role
                  </label>
                  <select
                    value={joinRole}
                    onChange={(e) => setJoinRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="PHYSICIAN">Attending Physician (MD/DO)</option>
                    <option value="NURSE">Clinical Nurse (RN)</option>
                    <option value="LAB_TECHNICIAN">Lab Diagnostics (MLS)</option>
                    <option value="PHARMACIST">Pharmacist (PharmD)</option>
                    <option value="BILLING">Billing Specialist (CPC)</option>
                    <option value="RECEPTIONIST">Intake & Reception</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Staff Institutional Email *
                  </label>
                  <input
                    type="email"
                    value={joinEmail}
                    onChange={(e) => setJoinEmail(e.target.value)}
                    placeholder="r.hayes@pacificcrest.health"
                    required
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Clinical Department
                  </label>
                  <input
                    type="text"
                    value={joinDept}
                    onChange={(e) => setJoinDept(e.target.value)}
                    placeholder="e.g. Cardiology & ICU"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Create Password *
                </label>
                <input
                  type="password"
                  value={joinPassword}
                  onChange={(e) => setJoinPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
                />
              </div>

              <div className="pt-3 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setAuthMode('SIGN_IN')}
                  className="text-xs font-semibold text-slate-400 hover:text-white"
                >
                  ← Back to Sign In
                </button>

                <button
                  type="submit"
                  id="btn-join-facility-submit"
                  disabled={isSubmitting}
                  className="py-3 px-6 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-teal-600/30 transition flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>Enrolling Clinician...</span>
                  ) : (
                    <>
                      <span>Join Facility Workspace</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>

          </div>
        )}

      </div>
    </div>
  );
};
