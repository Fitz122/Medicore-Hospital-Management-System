import React, { useState } from 'react';
import { 
  Receipt, 
  DollarSign, 
  Plus, 
  Search, 
  Printer, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ShieldCheck, 
  Building2, 
  FileText, 
  CreditCard,
  X,
  Send
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { BillingInvoice, BillingItem, InvoiceStatus } from '../../types';
import { printBillingInvoiceDocument } from '../../utils/printEngine';

export const BillingModule: React.FC = () => {
  const { 
    invoices, 
    patients, 
    addInvoice, 
    updateInvoiceStatus, 
    pendingClaimsTotalValue,
    logAuditAction,
    t 
  } = useHospital();

  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [selectedInvoice, setSelectedInvoice] = useState<BillingInvoice | null>(invoices[0] || null);

  // New Invoice Modal State
  const [isNewInvoiceOpen, setIsNewInvoiceOpen] = useState(false);
  const [newPatientId, setNewPatientId] = useState(patients[0]?.id || '');
  const [newItems, setNewItems] = useState<{ description: string; cptCode: string; quantity: number; unitPrice: number; category: BillingItem['category'] }[]>([
    { description: 'Comprehensive Physician Clinical Evaluation (E/M)', cptCode: '99214', quantity: 1, unitPrice: 250, category: 'Consultation' },
    { description: 'Automated 12-Lead Electrocardiogram (ECG)', cptCode: '93000', quantity: 1, unitPrice: 180, category: 'Diagnostic' as any }
  ]);

  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = 
      inv.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.patientMrn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'ALL' || inv.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleAddItemRow = () => {
    setNewItems([...newItems, { description: '', cptCode: '', quantity: 1, unitPrice: 100, category: 'Consultation' }]);
  };

  const handleRemoveItemRow = (index: number) => {
    if (newItems.length > 1) {
      setNewItems(newItems.filter((_, i) => i !== index));
    }
  };

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    const patient = patients.find(p => p.id === newPatientId);
    if (!patient) return;

    const formattedItems: BillingItem[] = newItems.map((item, idx) => ({
      id: `item-${Date.now()}-${idx}`,
      code: item.cptCode || '99213',
      description: item.description || 'Clinical Procedure',
      category: 'Consultation',
      quantity: Number(item.quantity) || 1,
      unitPrice: Number(item.unitPrice) || 50,
      totalPrice: (Number(item.quantity) || 1) * (Number(item.unitPrice) || 50)
    }));

    const totalSub = formattedItems.reduce((acc, i) => acc + i.totalPrice, 0);
    const coverageRate = (patient.insurance.coveragePercentage || 80) / 100;
    const insurancePortion = totalSub * coverageRate;
    const copay = patient.insurance.copayAmount || 25;
    const patientDue = Math.max(0, totalSub - insurancePortion + copay);

    const created = addInvoice({
      patientId: patient.id,
      patientName: patient.name,
      patientMrn: patient.mrn,
      issueDate: new Date().toISOString().slice(0, 10),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
      status: 'Pending_Insurance',
      items: formattedItems,
      subtotal: totalSub,
      insuranceCoverageRate: coverageRate,
      insurancePortion,
      patientCopay: copay,
      patientAmountPaid: 0,
      totalDue: patientDue,
      paymentMethod: 'Insurance Direct',
      claimId: `CLM-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`,
      claimStatus: 'Submitted',
      notes: 'Automated claim generated. Electronic EDI 837 standard submission queued.'
    });

    setIsNewInvoiceOpen(false);
    setSelectedInvoice(created);
  };

  const handlePrintInvoice = () => {
    if (!selectedInvoice) return;
    logAuditAction('REPORT_EXPORTED', `Printed Billing Statement for Invoice ${selectedInvoice.invoiceNumber}`, selectedInvoice.patientId, selectedInvoice.patientName);
    printBillingInvoiceDocument(selectedInvoice, currentUser);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase">
            <span>Outstanding Patient Balance</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-3xl font-extrabold text-slate-900 font-mono">
            ${pendingClaimsTotalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
          <span className="text-[11px] text-slate-500">
            Across {invoices.filter(i => i.status !== 'Paid').length} active patient invoices.
          </span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase">
            <span>EDI Insurance Claims</span>
            <ShieldCheck className="w-4 h-4 text-teal-600" />
          </div>
          <p className="text-3xl font-extrabold text-teal-800 font-mono">
            {invoices.filter(i => i.claimId).length} Claims
          </p>
          <span className="text-[11px] text-emerald-700 font-semibold">
            100% Automated CPT/ICD Split
          </span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold uppercase">
            <span>Fast Billing Actions</span>
            <Receipt className="w-4 h-4 text-indigo-600" />
          </div>
          <button
            onClick={() => setIsNewInvoiceOpen(true)}
            className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-2xl text-xs shadow-xs transition flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Generate New Invoice / Claim
          </button>
        </div>
      </div>

      {/* Invoice Directory & Invoice Detail Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Invoice List */}
        <div className="lg:col-span-5 bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <Receipt className="w-5 h-5 text-emerald-700" />
              {t.navBilling} & Insurance
            </h3>
            <span className="text-xs text-slate-500 font-mono font-bold">
              {filteredInvoices.length} Records
            </span>
          </div>

          {/* Search & Filter */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search Invoice #, Patient, Claim..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="flex gap-2">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full text-xs p-2 rounded-xl border border-slate-200 bg-slate-50 font-semibold text-slate-700"
              >
                <option value="ALL">All Statuses</option>
                <option value="Issued">Issued</option>
                <option value="Pending_Insurance">Pending Insurance</option>
                <option value="Paid">Paid (Settled)</option>
                <option value="Draft">Draft</option>
                <option value="Disputed">Disputed</option>
              </select>
            </div>
          </div>

          {/* Invoices List */}
          <div className="space-y-2 max-h-[550px] overflow-y-auto pr-1">
            {filteredInvoices.map((inv) => {
              const isSelected = selectedInvoice?.id === inv.id;
              return (
                <div
                  key={inv.id}
                  onClick={() => setSelectedInvoice(inv)}
                  className={`p-3.5 rounded-2xl border text-xs cursor-pointer transition space-y-2 ${
                    isSelected
                      ? 'bg-emerald-50/80 border-emerald-600 shadow-xs'
                      : 'bg-slate-50/70 border-slate-200 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-slate-900 text-xs">
                      {inv.invoiceNumber}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' :
                      inv.status === 'Pending_Insurance' ? 'bg-indigo-100 text-indigo-800' :
                      inv.status === 'Disputed' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {inv.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-slate-700">
                    <span className="font-bold text-slate-900 text-xs">{inv.patientName}</span>
                    <span className="font-mono font-bold text-sm text-slate-900">
                      ${(inv.totalDue ?? 0).toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200/60">
                    <span className="truncate max-w-[150px]">Payer: {inv.paymentMethod || 'Insurance'}</span>
                    <span>Due: {inv.dueDate}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Invoice Detail & Printable View */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-6">
          {selectedInvoice ? (
            <div className="space-y-6">
              {/* Header Action Bar */}
              <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-lg text-slate-900">
                      {selectedInvoice.invoiceNumber}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                      selectedInvoice.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {selectedInvoice.status.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Issued: {selectedInvoice.issueDate} • Due: <strong className="text-slate-800">{selectedInvoice.dueDate}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrintInvoice}
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                  >
                    <Printer className="w-4 h-4" />
                    Print Statement
                  </button>

                  {selectedInvoice.status !== 'Paid' && (
                    <button
                      onClick={() => updateInvoiceStatus(selectedInvoice.id, 'Paid')}
                      className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                    >
                      <CreditCard className="w-4 h-4" />
                      Mark Settled / Paid
                    </button>
                  )}
                </div>
              </div>

              {/* Printable Medical Invoice Document Body */}
              <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 space-y-6 text-xs text-slate-800" id="printable-invoice">
                {/* Hospital Header */}
                <div className="flex items-start justify-between border-b border-slate-300 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-800 flex items-center justify-center text-white font-bold">
                      <Building2 className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-base font-black text-slate-900">MEDICORE HEALTH SYSTEM</h4>
                      <p className="text-[11px] text-slate-500">Patient Financial & Clinical Billing Services</p>
                    </div>
                  </div>
                  <div className="text-right text-[11px] text-slate-500">
                    <p>Claim ID: <strong className="font-mono text-teal-800">{selectedInvoice.claimId || 'N/A'}</strong></p>
                    <p>EDI Status: <span className="font-semibold text-emerald-700">837 Transmission Verified</span></p>
                  </div>
                </div>

                {/* Patient & Insurance Details Grid */}
                <div className="grid grid-cols-2 gap-4 p-3.5 bg-white rounded-2xl border border-slate-200">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Billed Patient:</span>
                    <p className="font-bold text-slate-900 text-sm">{selectedInvoice.patientName}</p>
                    <p className="font-mono text-slate-600">MRN: {selectedInvoice.patientMrn}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Primary Payer / Method:</span>
                    <p className="font-bold text-teal-900">{selectedInvoice.paymentMethod || 'Insurance Direct'}</p>
                    <p className="text-slate-600">Coverage: <strong>{Math.round((selectedInvoice.insuranceCoverageRate ?? 0.8) * 100)}% Rate</strong></p>
                  </div>
                </div>

                {/* Line Items Table with CPT codes */}
                <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase font-bold">
                      <tr>
                        <th className="p-2.5">CPT Code</th>
                        <th className="p-2.5">Procedure / Clinical Service</th>
                        <th className="p-2.5 text-center">Qty</th>
                        <th className="p-2.5 text-right">Unit Price</th>
                        <th className="p-2.5 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-sans">
                      {selectedInvoice.items?.map((item, idx) => (
                        <tr key={item.id || `item-${idx}`}>
                          <td className="p-2.5 font-mono font-bold text-slate-700">{item.code}</td>
                          <td className="p-2.5 font-medium text-slate-900">{item.description}</td>
                          <td className="p-2.5 text-center font-mono">{item.quantity}</td>
                          <td className="p-2.5 text-right font-mono">${(item.unitPrice ?? 0).toFixed(2)}</td>
                          <td className="p-2.5 text-right font-mono font-bold text-slate-900">${(item.totalPrice ?? (item.quantity * item.unitPrice) ?? 0).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Calculation Breakdown Box */}
                <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal (Gross Clinical Charges):</span>
                    <span className="font-mono font-semibold">${(selectedInvoice.subtotal ?? 0).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Insurance Benefit Portion ({Math.round((selectedInvoice.insuranceCoverageRate ?? 0.8) * 100)}%):</span>
                    <span className="font-mono">-${(selectedInvoice.insurancePortion ?? 0).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Patient Copay:</span>
                    <span className="font-mono font-semibold">+${(selectedInvoice.patientCopay ?? 0).toFixed(2)}</span>
                  </div>
                  <div className="pt-2 border-t-2 border-slate-900 flex justify-between items-baseline text-sm font-black text-slate-900">
                    <span>Net Total Patient Responsibility Due:</span>
                    <span className="font-mono text-lg text-emerald-800 font-black">
                      ${(selectedInvoice.totalDue ?? 0).toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Notes */}
                {selectedInvoice.notes && (
                  <p className="text-[11px] text-slate-500 italic">
                    Note: {selectedInvoice.notes}
                  </p>
                )}
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-slate-400">
              Select an invoice from the list to view itemized breakdown and insurance claims.
            </div>
          )}
        </div>
      </div>

      {/* Generate New Invoice Modal */}
      {isNewInvoiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4 my-8 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-700" />
                Generate Automated Patient Invoice
              </h3>
              <button onClick={() => setIsNewInvoiceOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateInvoice} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Patient:</label>
                <select
                  value={newPatientId}
                  onChange={(e) => setNewPatientId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-semibold"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.mrn}) — {p.insurance.provider}
                    </option>
                  ))}
                </select>
              </div>

              {/* Line Items */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-700">Itemized Clinical Services (CPT Codes):</span>
                  <button
                    type="button"
                    onClick={handleAddItemRow}
                    className="text-xs text-emerald-700 font-bold hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" /> Add Service Line
                  </button>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {newItems.map((item, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-slate-50 p-2 rounded-xl border border-slate-200">
                      <div className="col-span-5">
                        <input
                          type="text"
                          required
                          placeholder="Service Description"
                          value={item.description}
                          onChange={(e) => {
                            const updated = [...newItems];
                            updated[idx].description = e.target.value;
                            setNewItems(updated);
                          }}
                          className="w-full p-1.5 rounded-lg border border-slate-300 text-xs"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="text"
                          required
                          placeholder="CPT"
                          value={item.cptCode}
                          onChange={(e) => {
                            const updated = [...newItems];
                            updated[idx].cptCode = e.target.value;
                            setNewItems(updated);
                          }}
                          className="w-full p-1.5 rounded-lg border border-slate-300 font-mono text-xs"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          min="1"
                          placeholder="Qty"
                          value={item.quantity}
                          onChange={(e) => {
                            const updated = [...newItems];
                            updated[idx].quantity = Number(e.target.value);
                            setNewItems(updated);
                          }}
                          className="w-full p-1.5 rounded-lg border border-slate-300 text-center text-xs"
                        />
                      </div>
                      <div className="col-span-2">
                        <input
                          type="number"
                          placeholder="Rate $"
                          value={item.unitPrice}
                          onChange={(e) => {
                            const updated = [...newItems];
                            updated[idx].unitPrice = Number(e.target.value);
                            setNewItems(updated);
                          }}
                          className="w-full p-1.5 rounded-lg border border-slate-300 text-right font-mono text-xs"
                        />
                      </div>
                      <div className="col-span-1 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveItemRow(idx)}
                          className="text-slate-400 hover:text-red-600"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewInvoiceOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-xs"
                >
                  Create & Submit Claim
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
