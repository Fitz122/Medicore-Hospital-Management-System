import React, { useState } from 'react';
import { 
  FlaskConical, 
  Send, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Plus, 
  Search, 
  Filter, 
  FileText, 
  User, 
  Microscope,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Download,
  Printer,
  QrCode
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { LabOrder, LabTestItem, LabTestResult } from '../../types';
import { LabDiagnosticReportModal } from './LabDiagnosticReportModal';

export const LaboratoryView: React.FC = () => {
  const { 
    labOrders, 
    availableLabTests, 
    patients, 
    createLabOrder, 
    updateLabOrderResults, 
    sendLabResultsToSpecialist,
    selectedPatient
  } = useHospital();
  const { currentUser } = useAuth();

  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedOrder, setSelectedOrder] = useState<LabOrder | null>(labOrders[0] || null);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [reportOrderToView, setReportOrderToView] = useState<LabOrder | null>(null);

  // New Order Modal state
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState<boolean>(false);
  const [selectedPatientId, setSelectedPatientId] = useState<string>(selectedPatient?.id || patients[0]?.id || '');
  const [selectedDoctorName, setSelectedDoctorName] = useState<string>('Dr. Marcus Vance (Cardiologist)');
  const [selectedUrgency, setSelectedUrgency] = useState<'ROUTINE' | 'URGENT' | 'STAT'>('ROUTINE');
  const [clinicalNotes, setClinicalNotes] = useState<string>('');
  const [selectedTestCodes, setSelectedTestCodes] = useState<string[]>(['CBC', 'CMP']);

  // Entering results modal/panel state
  const [editingResultsOrderId, setEditingResultsOrderId] = useState<string | null>(null);
  const [resultEntries, setResultEntries] = useState<Record<string, { value: string; flag: 'NORMAL' | 'ABNORMAL' | 'CRITICAL'; referenceRange: string; unit: string }>>({});
  const [technicianNotes, setTechnicianNotes] = useState<string>('');

  const filteredOrders = labOrders.filter(order => {
    const matchesStatus = filterStatus === 'ALL' || order.status === filterStatus;
    const matchesSearch = 
      order.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.patientMrn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleOpenEnterResults = (order: LabOrder) => {
    setEditingResultsOrderId(order.id);
    setTechnicianNotes(order.resultsSummary || '');
    
    // Initialise results form
    const initial: Record<string, any> = {};
    order.tests.forEach(test => {
      const codeKey = test.testCode || test.code || 'TEST';
      const existing = order.results?.find(r => r.testName === (test.testName || (test as any).name));
      initial[codeKey] = {
        value: existing?.value || test.resultValue || '',
        flag: existing?.flag || test.flag || 'NORMAL',
        referenceRange: existing?.referenceRange || test.referenceRange || test.normalRange || 'Normal',
        unit: existing?.unit || test.unit || ''
      };
    });
    setResultEntries(initial);
  };

  const handleSaveResults = (orderId: string) => {
    const order = labOrders.find(o => o.id === orderId);
    if (!order) return;

    const formattedResults: LabTestResult[] = order.tests.map(test => {
      const codeKey = test.testCode || test.code || 'TEST';
      const entry = resultEntries[codeKey] || {
        value: 'Standard',
        flag: 'NORMAL',
        referenceRange: test.referenceRange || test.normalRange || 'Normal',
        unit: test.unit
      };
      return {
        testId: test.id || test.testCode || test.code,
        testName: test.testName || (test as any).name || 'Diagnostic Test',
        value: entry.value || 'Normal',
        unit: entry.unit || test.unit || '',
        referenceRange: entry.referenceRange || test.referenceRange || test.normalRange || 'Normal',
        flag: entry.flag || 'NORMAL',
        performedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        notes: `Technician verified on automated analyzer.`
      };
    });

    updateLabOrderResults(orderId, formattedResults, technicianNotes);
    setEditingResultsOrderId(null);

    // Refresh selected
    const updated = labOrders.find(o => o.id === orderId);
    if (updated) setSelectedOrder(updated);
  };

  const handleSendToSpecialist = (orderId: string) => {
    sendLabResultsToSpecialist(orderId);
    const updated = labOrders.find(o => o.id === orderId);
    if (updated) setSelectedOrder(updated);
  };

  const handleCreateNewOrder = () => {
    const pat = patients.find(p => p.id === selectedPatientId);
    if (!pat) return;

    const selectedTests = availableLabTests.filter(t => selectedTestCodes.includes(t.code));
    if (selectedTests.length === 0) return;

    const newOrder = createLabOrder({
      patientId: pat.id,
      patientName: pat.name,
      patientMrn: pat.mrn,
      doctorName: selectedDoctorName,
      specialty: 'Internal Medicine',
      tests: selectedTests,
      urgency: selectedUrgency,
      clinicalNotes: clinicalNotes || 'Clinical diagnostic evaluation ordered by specialist.'
    });

    setIsNewOrderModalOpen(false);
    setSelectedOrder(newOrder);
    setClinicalNotes('');
  };

  return (
    <div id="laboratory-view-container" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl border border-indigo-200">
            <FlaskConical className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              Diagnostic Pathology & Laboratory
              <span className="text-xs bg-indigo-100 text-indigo-800 font-semibold px-2.5 py-0.5 rounded-full border border-indigo-200">
                CLIA / CAP Accredited
              </span>
            </h1>
            <p className="text-xs text-slate-500">
              Process test orders from specialists, record clinical findings, and transmit reports back to physicians.
            </p>
          </div>
        </div>

        <button
          id="btn-create-lab-order"
          onClick={() => setIsNewOrderModalOpen(true)}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Create Specialist Lab Order
        </button>
      </div>

      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Total Lab Orders</p>
            <p className="text-2xl font-black text-slate-900 mt-1">{labOrders.length}</p>
          </div>
          <div className="p-2.5 bg-slate-100 text-slate-700 rounded-xl">
            <Microscope className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Pending Collection / Analysis</p>
            <p className="text-2xl font-black text-amber-600 mt-1">
              {labOrders.filter(o => o.status === 'PENDING' || o.status === 'IN_PROGRESS').length}
            </p>
          </div>
          <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Findings Ready to Transmit</p>
            <p className="text-2xl font-black text-indigo-600 mt-1">
              {labOrders.filter(o => o.status === 'FINDINGS_READY').length}
            </p>
          </div>
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <FileText className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Transmitted to Specialist</p>
            <p className="text-2xl font-black text-emerald-600 mt-1">
              {labOrders.filter(o => o.status === 'SENT_TO_SPECIALIST').length}
            </p>
          </div>
          <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Lab Orders Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Orders Queue (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-3">
            
            {/* Search and Filters */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search orders, patient MRN, doctor..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Filter pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              {['ALL', 'PENDING', 'IN_PROGRESS', 'FINDINGS_READY', 'SENT_TO_SPECIALIST'].map(st => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
                    filterStatus === st
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st.replace(/_/g, ' ')}
                </button>
              ))}
            </div>

            {/* Orders List */}
            <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto space-y-1">
              {filteredOrders.map(order => {
                const isSelected = selectedOrder?.id === order.id;
                return (
                  <div
                    key={order.id}
                    id={`lab-order-card-${order.id}`}
                    onClick={() => setSelectedOrder(order)}
                    className={`p-3.5 rounded-xl cursor-pointer transition-all ${
                      isSelected 
                        ? 'bg-indigo-50/90 border-2 border-indigo-400 shadow-sm' 
                        : 'bg-white hover:bg-slate-50 border border-slate-100'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{order.patientName}</span>
                          <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                            {order.patientMrn}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Ordered by: <span className="font-medium text-slate-700">{order.doctorName}</span>
                        </p>
                      </div>

                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        order.status === 'SENT_TO_SPECIALIST'
                          ? 'bg-emerald-100 text-emerald-800'
                          : order.status === 'FINDINGS_READY'
                          ? 'bg-indigo-100 text-indigo-800'
                          : order.status === 'IN_PROGRESS'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {order.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <FlaskConical className="w-3.5 h-3.5 text-indigo-500" />
                        <span>{order.tests.length} tests ordered</span>
                      </div>
                      <span className={`font-semibold ${
                        order.urgency === 'STAT' ? 'text-rose-600 font-bold' : order.urgency === 'URGENT' ? 'text-amber-600' : 'text-slate-500'
                      }`}>
                        {order.urgency}
                      </span>
                    </div>
                  </div>
                );
              })}

              {filteredOrders.length === 0 && (
                <div className="py-8 text-center text-xs text-slate-400">
                  No laboratory orders match this filter.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Selected Order Detail & Action Panel (7 cols) */}
        <div className="lg:col-span-7">
          {selectedOrder ? (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
              
              {/* Order Header & Status Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-900">
                      Lab Order #{selectedOrder.id}
                    </h2>
                    <span className="text-[10px] font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      {selectedOrder.patientMrn}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      selectedOrder.urgency === 'STAT' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {selectedOrder.urgency} PRIORITY
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Patient: <span className="font-bold text-slate-800">{selectedOrder.patientName}</span> • Prescribing Specialist: <span className="font-semibold text-slate-800">{selectedOrder.doctorName} ({selectedOrder.specialty})</span>
                  </p>
                </div>

                {/* Workflow & Diagnostic Report Action Buttons */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    id="btn-generate-lab-diagnostic-report"
                    onClick={() => {
                      setReportOrderToView(selectedOrder);
                      setIsReportModalOpen(true);
                    }}
                    className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-1.5 border border-slate-700"
                  >
                    <Printer className="w-3.5 h-3.5 text-teal-400" />
                    <span>Print Diagnostic Report (QR)</span>
                  </button>

                  {selectedOrder.status === 'SENT_TO_SPECIALIST' ? (
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-xl">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Findings Delivered to Doctor
                    </div>
                  ) : selectedOrder.status === 'FINDINGS_READY' ? (
                    <button
                      id="btn-send-findings-specialist"
                      onClick={() => handleSendToSpecialist(selectedOrder.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      Send Findings to Specialist
                    </button>
                  ) : (
                    <button
                      id="btn-enter-lab-results"
                      onClick={() => handleOpenEnterResults(selectedOrder)}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-1.5"
                    >
                      <Microscope className="w-3.5 h-3.5" />
                      Enter / Edit Results
                    </button>
                  )}
                </div>
              </div>

              {/* Specialist Clinical Request Notes */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <p className="font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                  Specialist Clinical Indication & Instructions:
                </p>
                <p className="text-slate-600 italic">"{selectedOrder.clinicalNotes}"</p>
                <p className="text-[10px] text-slate-400 mt-1">
                  Ordered on {selectedOrder.orderDate} at {selectedOrder.orderTime}
                </p>
              </div>

              {/* Ordered Tests & Live Results Table */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Diagnostic Tests & Analyzed Parameters ({selectedOrder.tests.length})
                </h3>

                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">Test Name & Code</th>
                        <th className="py-2.5 px-3">Result Value</th>
                        <th className="py-2.5 px-3">Normal Reference</th>
                        <th className="py-2.5 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedOrder.tests.map((test, index) => {
                        const testIdKey = test.id || test.testCode || test.code;
                        const testNameKey = test.testName || (test as any).name;
                        const result = selectedOrder.results?.find(r => 
                          (r.testId && r.testId === testIdKey) || 
                          (r.testName && r.testName === testNameKey) ||
                          (test.testCode && r.testName === test.testCode)
                        );
                        return (
                          <tr key={test.id || test.testCode || test.code || index} className="hover:bg-slate-50/70">
                            <td className="py-2.5 px-3">
                              <div className="font-bold text-slate-900">{test.testName || (test as any).name || test.testCode}</div>
                              <div className="text-[10px] text-slate-500">{test.category} • {test.sampleRequired || (test as any).specimenType || 'Venous Blood / Serum'}</div>
                            </td>
                            <td className="py-2.5 px-3 font-mono font-bold">
                              {result ? (
                                <span className={
                                  result.flag === 'CRITICAL' ? 'text-rose-600' :
                                  result.flag === 'ABNORMAL' ? 'text-amber-600' :
                                  'text-emerald-700'
                                }>
                                  {result.value} {result.unit}
                                </span>
                              ) : test.resultValue ? (
                                <span className={
                                  test.flag === 'CRITICAL' ? 'text-rose-600' :
                                  test.flag === 'ABNORMAL' ? 'text-amber-600' :
                                  'text-emerald-700'
                                }>
                                  {test.resultValue} {test.unit}
                                </span>
                              ) : (
                                <span className="text-slate-400 font-normal">Pending Analysis</span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600 text-[11px]">
                              {test.referenceRange || test.normalRange || 'Normal'}
                            </td>
                            <td className="py-2.5 px-3">
                              {result ? (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  result.flag === 'CRITICAL' ? 'bg-rose-100 text-rose-800' :
                                  result.flag === 'ABNORMAL' ? 'bg-amber-100 text-amber-800' :
                                  'bg-emerald-100 text-emerald-800'
                                }`}>
                                  {result.flag}
                                </span>
                              ) : test.status ? (
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  test.status === 'CRITICAL' ? 'bg-rose-100 text-rose-800' :
                                  test.status === 'ABNORMAL' ? 'bg-amber-100 text-amber-800' :
                                  test.status === 'NORMAL' || test.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800' :
                                  'bg-slate-100 text-slate-600'
                                }`}>
                                  {test.flag || test.status}
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                                  Pending
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Results Summary / Clinical Interpretation */}
              {selectedOrder.resultsSummary && (
                <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-indigo-950 flex items-center gap-1.5">
                      <Microscope className="w-4 h-4 text-indigo-700" />
                      Laboratory Pathologist Summary & Medical Findings:
                    </h4>
                    {selectedOrder.technicianName && (
                      <span className="text-[11px] text-indigo-700 font-medium">
                        Verified by {selectedOrder.technicianName}
                      </span>
                    )}
                  </div>
                  <p className="text-indigo-900 leading-relaxed">
                    {selectedOrder.resultsSummary}
                  </p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-2 border-t border-slate-200 text-xs text-slate-500 gap-2">
                <span>Sample Tube: EDTA Lavender / Serum Separator</span>
                <div className="flex items-center gap-2">
                  <button
                    id="btn-print-report-bottom"
                    onClick={() => {
                      setReportOrderToView(selectedOrder);
                      setIsReportModalOpen(true);
                    }}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-teal-300 rounded-lg font-bold flex items-center gap-1 border border-slate-700"
                  >
                    <Printer className="w-3.5 h-3.5 text-teal-400" />
                    <span>Print Diagnostic Report (QR)</span>
                  </button>

                  <button
                    onClick={() => handleOpenEnterResults(selectedOrder)}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold"
                  >
                    Edit Findings Data
                  </button>
                  {selectedOrder.status !== 'SENT_TO_SPECIALIST' && (
                    <button
                      onClick={() => handleSendToSpecialist(selectedOrder.id)}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-1"
                    >
                      <Send className="w-3 h-3" />
                      Transmit Findings to Specialist
                    </button>
                  )}
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center text-slate-400">
              <FlaskConical className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-sm font-medium text-slate-600">Select a lab order from the queue to view diagnostic details</p>
            </div>
          )}
        </div>

      </div>

      {/* Enter Lab Results Modal */}
      {editingResultsOrderId && (
        <div id="modal-enter-lab-results" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-5 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Microscope className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">
                  Record Diagnostic Findings & Analyzer Output
                </h3>
              </div>
              <button
                onClick={() => setEditingResultsOrderId(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
              {labOrders.find(o => o.id === editingResultsOrderId)?.tests.map((test, idx) => {
                const testCodeKey = test.testCode || test.code || `TEST-${idx}`;
                const testDisplayName = test.testName || (test as any).name || testCodeKey;
                const testNormalRef = test.referenceRange || test.normalRange || 'Normal';
                return (
                  <div key={test.id || testCodeKey || idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-slate-900">{testDisplayName}</span>
                        <span className="text-[10px] text-slate-500 ml-2 font-mono">Ref: {testNormalRef}</span>
                      </div>
                      <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-mono font-semibold">
                        {testCodeKey}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Value & Unit</label>
                        <input
                          type="text"
                          placeholder="e.g. 13.8"
                          value={resultEntries[testCodeKey]?.value || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setResultEntries(prev => ({
                              ...prev,
                              [testCodeKey]: { ...prev[testCodeKey], value: val }
                            }));
                          }}
                          className="w-full text-xs font-mono px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Reference Range</label>
                        <input
                          type="text"
                          value={resultEntries[testCodeKey]?.referenceRange || testNormalRef}
                          onChange={(e) => {
                            const val = e.target.value;
                            setResultEntries(prev => ({
                              ...prev,
                              [testCodeKey]: { ...prev[testCodeKey], referenceRange: val }
                            }));
                          }}
                          className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Clinical Flag</label>
                        <select
                          value={resultEntries[testCodeKey]?.flag || 'NORMAL'}
                          onChange={(e) => {
                            const flag = e.target.value as any;
                            setResultEntries(prev => ({
                              ...prev,
                              [testCodeKey]: { ...prev[testCodeKey], flag }
                            }));
                          }}
                          className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white font-semibold"
                        >
                          <option value="NORMAL">NORMAL (Within Range)</option>
                          <option value="ABNORMAL">ABNORMAL (Elevated / Low)</option>
                          <option value="CRITICAL">CRITICAL (STAT Alert)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                );
              })}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Pathologist Findings Summary & Diagnostic Notes
                </label>
                <textarea
                  rows={3}
                  value={technicianNotes}
                  onChange={(e) => setTechnicianNotes(e.target.value)}
                  placeholder="Summarize key findings to accompany reports delivered to the consulting specialist..."
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <button
                onClick={() => setEditingResultsOrderId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                id="btn-save-lab-results"
                onClick={() => handleSaveResults(editingResultsOrderId)}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow"
              >
                Save Findings (Mark Ready for Specialist)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create New Lab Order Modal */}
      {isNewOrderModalOpen && (
        <div id="modal-create-lab-order" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-5 border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <FlaskConical className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">
                  New Specialist Diagnostic Lab Order
                </h3>
              </div>
              <button
                onClick={() => setIsNewOrderModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Select Patient</label>
                <select
                  value={selectedPatientId}
                  onChange={(e) => setSelectedPatientId(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.mrn}) - Age: {p.age}, {p.gender}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Prescribing Specialist</label>
                  <input
                    type="text"
                    value={selectedDoctorName}
                    onChange={(e) => setSelectedDoctorName(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Priority / Urgency</label>
                  <select
                    value={selectedUrgency}
                    onChange={(e) => setSelectedUrgency(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white font-semibold"
                  >
                    <option value="ROUTINE">ROUTINE (Standard TAT)</option>
                    <option value="URGENT">URGENT (&lt; 2 Hours)</option>
                    <option value="STAT">STAT (Immediate &lt; 30 Mins)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Select Diagnostic Tests ({selectedTestCodes.length} selected)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 border border-slate-200 rounded-xl">
                  {availableLabTests.map(test => {
                    const isChecked = selectedTestCodes.includes(test.code);
                    const testPrice = test.price ?? test.standardPrice ?? 0;
                    return (
                      <label
                        key={test.id || test.code}
                        className={`flex items-center gap-2 p-2 rounded-lg border text-xs cursor-pointer transition-all ${
                          isChecked ? 'bg-indigo-50 border-indigo-300 font-bold text-indigo-950' : 'bg-white border-slate-200 text-slate-700'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              setSelectedTestCodes(prev => prev.filter(c => c !== test.code));
                            } else {
                              setSelectedTestCodes(prev => [...prev, test.code]);
                            }
                          }}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                        <div className="flex-1">
                          <div>{test.name}</div>
                          <div className="text-[10px] text-slate-500 font-normal">{test.category} • ${testPrice.toFixed(2)}</div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Clinical Indication / Symptoms</label>
                <textarea
                  rows={2}
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  placeholder="Describe patient's symptoms, suspected pathology, or test rationale..."
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <button
                onClick={() => setIsNewOrderModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                id="btn-submit-new-lab-order"
                onClick={handleCreateNewOrder}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow"
              >
                Transmit Order to Lab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Lab Diagnostic Report Modal with Encrypted QR Code */}
      {(reportOrderToView || selectedOrder) && (
        <LabDiagnosticReportModal
          isOpen={isReportModalOpen}
          onClose={() => {
            setIsReportModalOpen(false);
            setReportOrderToView(null);
          }}
          order={reportOrderToView || selectedOrder!}
        />
      )}

    </div>
  );
};
