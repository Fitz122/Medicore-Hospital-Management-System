import React, { useState } from 'react';
import { 
  MessageSquare, 
  Send, 
  Lock, 
  ShieldCheck, 
  User, 
  CheckCheck, 
  Search, 
  Clock, 
  Paperclip, 
  PhoneCall, 
  Video,
  Building2,
  Sparkles
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { ChatMessage } from '../../types';

export const SecureProviderChat: React.FC = () => {
  const { chatMessages, sendChatMessage, patients } = useHospital();
  const { currentUser } = useAuth();
  
  const [selectedChannelId, setSelectedChannelId] = useState<string>('cardiology-team');
  const [inputMessage, setInputMessage] = useState('');
  const [searchFilter, setSearchFilter] = useState('');

  const channels = [
    { id: 'cardiology-team', name: 'Cardiology Clinical Team', type: 'DEPARTMENT', members: 'Dr. Vance, Nurse Jackson, Dr. Zhao', unread: 0 },
    { id: 'icu-huddle', name: 'ICU Shift Huddle & Handover', type: 'WARD', members: 'ICU Attending, Charge Nurse, RT', unread: 2 },
    { id: 'patient-pat-1', name: 'Eleanor Vance (Patient Portal)', type: 'PATIENT', members: 'Patient Proxy, Dr. Vance', unread: 0 },
    { id: 'patient-pat-2', name: 'Marcus Brody (Post-Op Care)', type: 'PATIENT', members: 'Patient, Dr. Kevin Zhao', unread: 1 },
    { id: 'surgical-triage', name: 'OR & Surgical Triage Desk', type: 'TEAM', members: 'Anesthesia, OR Charge Nurse', unread: 0 },
  ];

  const currentChannel = channels.find(c => c.id === selectedChannelId) || channels[0];

  const channelMessages = chatMessages.filter(m => {
    if (selectedChannelId.startsWith('patient-')) {
      const pId = selectedChannelId.replace('patient-', '');
      return m.conversationId === selectedChannelId || m.senderId === pId || m.recipientId === pId;
    }
    return m.conversationId === selectedChannelId || m.recipientId === selectedChannelId;
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    sendChatMessage(inputMessage.trim(), selectedChannelId, currentChannel.name, 'ROUTINE');
    setInputMessage('');
  };

  return (
    <div className="space-y-4">
      {/* Top Security Banner */}
      <div className="bg-slate-900 text-white p-4 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-teal-600/30 text-teal-400 rounded-2xl">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-white">HIPAA 256-Bit Encrypted Telehealth & Clinical Portal</h3>
              <span className="px-2 py-0.5 bg-teal-500/20 text-teal-300 border border-teal-500/40 rounded-full text-[10px] font-bold">
                E2EE Active
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Protected Health Information (PHI) compliant transmission channel.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Audit Key: SEC-2026-MEDICORE</span>
        </div>
      </div>

      {/* Chat Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[600px] bg-white rounded-3xl border border-slate-200 shadow-2xs overflow-hidden">
        {/* Left: Channels Sidebar */}
        <div className="lg:col-span-4 border-r border-slate-200 flex flex-col justify-between bg-slate-50/50">
          <div className="p-4 space-y-3">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-500">
              Secure Communications
            </h4>

            {/* Channels List */}
            <div className="space-y-1.5 overflow-y-auto max-h-[480px]">
              {channels.map((chan) => {
                const isSelected = selectedChannelId === chan.id;
                return (
                  <button
                    key={chan.id}
                    onClick={() => setSelectedChannelId(chan.id)}
                    className={`w-full text-left p-3 rounded-2xl transition space-y-1 ${
                      isSelected
                        ? 'bg-teal-800 text-white shadow-md shadow-teal-800/20'
                        : 'bg-white hover:bg-slate-100 border border-slate-200/80 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs truncate max-w-[160px]">
                        {chan.name}
                      </span>
                      <span className={`text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded-md ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {chan.type}
                      </span>
                    </div>
                    <p className={`text-[11px] truncate ${
                      isSelected ? 'text-teal-200' : 'text-slate-500'
                    }`}>
                      {chan.members}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="p-3 bg-white border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
            <span>Signed in as <strong>{currentUser.name}</strong></span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
        </div>

        {/* Right: Active Chat Conversation */}
        <div className="lg:col-span-8 flex flex-col justify-between h-full bg-white">
          {/* Channel Header */}
          <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-white">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-slate-900">{currentChannel.name}</h3>
                <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-md text-[10px] font-bold">
                  Verified Session
                </span>
              </div>
              <p className="text-xs text-slate-500">{currentChannel.members}</p>
            </div>

            <div className="flex items-center gap-2 text-slate-400">
              <button className="p-2 hover:bg-slate-100 rounded-xl transition text-slate-600" title="Secure Voice Consultation">
                <PhoneCall className="w-4 h-4" />
              </button>
              <button className="p-2 hover:bg-slate-100 rounded-xl transition text-slate-600" title="Secure Telehealth Video Call">
                <Video className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/40">
            {channelMessages.map((msg) => {
              const isMine = msg.senderId === currentUser.id;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-center gap-1.5 mb-1 text-[11px] text-slate-500">
                    <span className="font-bold text-slate-800">{msg.senderName}</span>
                    <span>({msg.senderRole})</span>
                    <span>•</span>
                    <span>{msg.timestamp.split(' ')[1] || msg.timestamp}</span>
                  </div>

                  <div
                    className={`max-w-md p-3.5 rounded-2xl text-xs space-y-1 ${
                      isMine
                        ? 'bg-teal-700 text-white rounded-br-xs shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-900 rounded-bl-xs shadow-2xs'
                    }`}
                  >
                    <p className="leading-relaxed">{msg.content}</p>

                    <div className="flex items-center justify-end gap-1 text-[9px] opacity-75 pt-1">
                      <Lock className="w-2.5 h-2.5" />
                      <span>AES-256</span>
                      <CheckCheck className="w-3 h-3 ml-1" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Chat Input Bar */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
            <input
              type="text"
              placeholder={`Send encrypted message to ${currentChannel.name}...`}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              className="flex-1 text-xs px-4 py-3 rounded-2xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-700"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim()}
              className="p-3 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white rounded-2xl font-bold transition shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
