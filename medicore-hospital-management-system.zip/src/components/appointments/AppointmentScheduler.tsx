import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Plus, 
  Search, 
  CheckCircle2, 
  AlertCircle, 
  Send, 
  User, 
  Building2, 
  Check, 
  X, 
  CalendarDays,
  Filter,
  ShieldCheck,
  Stethoscope,
  Printer
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Appointment, AppointmentStatus, AppointmentType } from '../../types';
import { NavTab } from '../layout/Sidebar';
import { printAppointmentSlip } from '../../utils/printEngine';

interface AppointmentSchedulerProps {
  onNavigate?: (tab: NavTab) => void;
}

export const AppointmentScheduler: React.FC<AppointmentSchedulerProps> = ({ onNavigate }) => {
  const { 
    appointments, 
    patients, 
    addAppointment, 
    updateAppointmentStatus, 
    sendStaffAppointmentAlert,
    setSelectedPatientId,
    t 
  } = useHospital();

  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState('2026-08-31');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [isBookModalOpen, setIsBookModalOpen] = useState(false);

  // New Appointment Form State
  const [formPatientId, setFormPatientId] = useState(patients[0]?.id || '');
  const [formDoctorName, setFormDoctorName] = useState('Dr. Elena Vance, MD');
  const [formDepartment, setFormDepartment] = useState('Cardiology');
  const [formDate, setFormDate] = useState('2026-08-31');
  const [formTime, setFormTime] = useState('10:00 AM');
  const [formDuration, setFormDuration] = useState(30);
  const [formType, setFormType] = useState<AppointmentType>('General Consultation');
  const [formRoom, setFormRoom] = useState('Suite 302-A');
  const [formReason, setFormReason] = useState('');
  const [formAutoAlertStaff, setFormAutoAlertStaff] = useState(true);

  const filteredAppointments = appointments.filter(a => {
    const matchesSearch = 
      a.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.patientMrn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.roomNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = filterStatus === 'ALL' || a.status === filterStatus;
    const matchesDate = !selectedDate || a.date === selectedDate;

    return matchesSearch && matchesStatus && matchesDate;
  });

  const handleBookAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const patient = patients.find(p => p.id === formPatientId);
    if (!patient) return;

    addAppointment({
      patientId: patient.id,
      patientName: patient.name,
      patientMrn: patient.mrn,
      doctorId: 'usr-doc-1',
      doctorName: formDoctorName,
      department: formDepartment,
      date: formDate,
      time: formTime,
      durationMinutes: Number(formDuration),
      type: formType,
      status: 'Scheduled',
      roomNumber: formRoom,
      reasonForVisit: formReason || `${formType} with ${formDoctorName}`,
      staffAlertSent: formAutoAlertStaff,
      vitalsPreChecked: false
    });

    setIsBookModalOpen(false);
    setFormReason('');
  };

  return (
    <div className="space-y-6">
      {/* Top Controls & Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-bold text-lg text-slate-900 flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-indigo-700" />
              {t.navAppointments} & Clinical Scheduling
            </h2>
            <p className="text-xs text-slate-500">
              Coordinate physician consultations, diagnostic suites, and automated staff alerts.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsBookModalOpen(true)}
              className="px-4 py-2.5 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              {t.scheduleAppointment}
            </button>
          </div>
        </div>

        {/* Filters Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3 pt-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search Doctor, Patient, Room..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          {/* Date Picker */}
          <div className="relative">
            <CalendarDays className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-600 font-bold text-slate-700"
            />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full text-xs py-2.5 px-3 rounded-xl border border-slate-200 bg-slate-50 font-semibold text-slate-700"
            >
              <option value="ALL">All Statuses ({appointments.length})</option>
              <option value="Scheduled">Scheduled</option>
              <option value="Confirmed">Confirmed</option>
              <option value="In-Progress">In-Progress (In Suite)</option>
              <option value="Completed">Completed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          {/* Quick Date Reset */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedDate('2026-08-31')}
              className="flex-1 py-2.5 px-3 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-center"
            >
              Today (Aug 31)
            </button>
            <button
              onClick={() => setSelectedDate('')}
              className="py-2.5 px-3 text-xs font-semibold rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-600"
            >
              View All
            </button>
          </div>
        </div>
      </div>

      {/* Appointment Cards Stream */}
      <div className="space-y-3">
        {filteredAppointments.length > 0 ? (
          filteredAppointments.map((apt) => {
            return (
              <div
                key={apt.id}
                className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs hover:border-indigo-400/60 transition space-y-4"
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                  {/* Left: Time and Patient info */}
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-100 flex flex-col items-center justify-center text-center shrink-0">
                      <Clock className="w-4 h-4 text-indigo-700 mb-0.5" />
                      <span className="font-mono font-black text-xs text-indigo-950 leading-none">
                        {apt.time.split(' ')[0]}
                      </span>
                      <span className="text-[9px] font-bold text-indigo-700 uppercase">
                        {apt.time.split(' ')[1] || 'AM'}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-bold text-sm sm:text-base text-slate-900">
                          {apt.patientName}
                        </h3>
                        <span className="font-mono text-[10px] font-bold px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md">
                          {apt.patientMrn}
                        </span>
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          apt.status === 'In-Progress' ? 'bg-amber-100 text-amber-900 animate-pulse' :
                          apt.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' :
                          apt.status === 'Confirmed' ? 'bg-teal-100 text-teal-800' : 'bg-indigo-100 text-indigo-800'
                        }`}>
                          {apt.status}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600">
                        <strong>{apt.type}</strong> • Attending: <span className="font-semibold text-slate-800">{apt.doctorName}</span> ({apt.department})
                      </p>

                      <p className="text-[11px] text-slate-500">
                        Suite / Examination Room: <strong className="text-slate-700 font-mono">{apt.roomNumber}</strong> • Duration: {apt.durationMinutes} mins
                      </p>
                    </div>
                  </div>

                  {/* Right: Workflow Status Buttons & Staff Alert Notification Trigger */}
                  <div className="flex flex-wrap items-center gap-2 self-start lg:self-center">
                    {/* Send Staff Alert Action */}
                    <button
                      onClick={() => sendStaffAppointmentAlert(apt.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                        apt.staffAlertSent
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                      }`}
                      title="Send instant push notification to medical staff"
                    >
                      <Send className="w-3.5 h-3.5" />
                      {apt.staffAlertSent ? 'Staff Alert Dispatched' : 'Alert Attending Staff'}
                    </button>

                    {/* Status Dropdown / Cycle */}
                    <select
                      value={apt.status}
                      onChange={(e) => updateAppointmentStatus(apt.id, e.target.value as AppointmentStatus)}
                      className="text-xs font-semibold p-1.5 rounded-xl border border-slate-300 bg-slate-50"
                    >
                      <option value="Scheduled">Scheduled</option>
                      <option value="Confirmed">Confirmed</option>
                      <option value="In-Progress">In-Progress</option>
                      <option value="Completed">Completed</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>

                    {/* Jump to Patient EHR */}
                    <button
                      onClick={() => {
                        setSelectedPatientId(apt.patientId);
                        if (onNavigate) onNavigate('patients');
                      }}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                    >
                      Open EHR
                    </button>

                    {/* Print Appointment Slip */}
                    <button
                      onClick={() => printAppointmentSlip(apt, currentUser)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-xs"
                      title="Print Official Appointment Slip & Check-in Pass"
                    >
                      <Printer className="w-3.5 h-3.5 text-teal-300" />
                      <span>Print Slip</span>
                    </button>
                  </div>
                </div>

                {/* Reason for visit */}
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-xs text-slate-700 flex items-start gap-2">
                  <Stethoscope className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                  <p>
                    <span className="font-semibold text-slate-900">Clinical Focus / Reason: </span>
                    {apt.reasonForVisit}
                  </p>
                </div>
              </div>
            );
          })
        ) : (
          <div className="bg-white p-12 text-center rounded-3xl border border-slate-200 text-slate-500 text-xs space-y-2">
            <p className="font-semibold text-slate-700 text-sm">No consultations found matching this criteria.</p>
            <p>Try clearing filters or click "Book New Appointment" to schedule a patient slot.</p>
          </div>
        )}
      </div>

      {/* Book New Appointment Modal */}
      {isBookModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="bg-indigo-700 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-xl">
                  <CalendarIcon className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-base">{t.scheduleAppointment}</h3>
                  <p className="text-xs text-indigo-100">Coordinate Attending Doctor & Clinical Room</p>
                </div>
              </div>
              <button 
                onClick={() => setIsBookModalOpen(false)}
                className="p-1 text-indigo-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBookAppointment} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Registered Patient:</label>
                <select
                  value={formPatientId}
                  onChange={(e) => setFormPatientId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-semibold"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.mrn} • {p.bloodType})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.doctor}:</label>
                  <select
                    value={formDoctorName}
                    onChange={(e) => setFormDoctorName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  >
                    <option value="Dr. Elena Vance, MD">Dr. Elena Vance, MD (Cardiology)</option>
                    <option value="Dr. Kevin Zhao, MD">Dr. Kevin Zhao, MD (Orthopedics)</option>
                    <option value="Dr. Clara Thorne, MD">Dr. Clara Thorne, MD (Pediatrics)</option>
                    <option value="Dr. Marcus Webb, MD">Dr. Marcus Webb, MD (Internal Med)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Department:</label>
                  <select
                    value={formDepartment}
                    onChange={(e) => setFormDepartment(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  >
                    <option value="Cardiology">Cardiology</option>
                    <option value="Orthopedics">Orthopedics & Surgery</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="General Internal Medicine">General Internal Medicine</option>
                    <option value="Obstetrics">Obstetrics & Gynecology</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Date:</label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Time Slot:</label>
                  <input
                    type="text"
                    required
                    value={formTime}
                    onChange={(e) => setFormTime(e.target.value)}
                    placeholder="e.g. 02:30 PM"
                    className="w-full p-2 rounded-xl border border-slate-300 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Duration:</label>
                  <select
                    value={formDuration}
                    onChange={(e) => setFormDuration(Number(e.target.value))}
                    className="w-full p-2 rounded-xl border border-slate-300"
                  >
                    <option value={15}>15 mins</option>
                    <option value={30}>30 mins</option>
                    <option value={45}>45 mins</option>
                    <option value={60}>60 mins</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Consultation Type:</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as AppointmentType)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-medium"
                  >
                    <option value="General Consultation">General Consultation</option>
                    <option value="Cardiology Follow-up">Cardiology Follow-up</option>
                    <option value="Surgical Post-Op">Surgical Post-Op</option>
                    <option value="Pediatric Checkup">Pediatric Checkup</option>
                    <option value="Telehealth Review">Telehealth Review</option>
                    <option value="Emergency Triage">Emergency Triage</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{t.room}:</label>
                  <input
                    type="text"
                    required
                    value={formRoom}
                    onChange={(e) => setFormRoom(e.target.value)}
                    placeholder="e.g. Suite 302-A"
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Reason for Visit / Clinical Notes:</label>
                <textarea
                  rows={2}
                  value={formReason}
                  onChange={(e) => setFormReason(e.target.value)}
                  placeholder="e.g. 6-month blood pressure review, titration of Lisinopril, and ECG evaluation."
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer pt-1 font-semibold text-slate-700">
                <input
                  type="checkbox"
                  checked={formAutoAlertStaff}
                  onChange={(e) => setFormAutoAlertStaff(e.target.checked)}
                  className="rounded-sm border-slate-300 text-indigo-600"
                />
                <span>Automatically trigger Staff Push Notification on creation</span>
              </label>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsBookModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-700 hover:bg-indigo-800 text-white font-bold rounded-xl shadow-xs transition"
                >
                  Confirm & Book Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
