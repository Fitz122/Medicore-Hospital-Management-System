import React, { useState } from 'react';
import { 
  BellRing, 
  Radio, 
  Pill, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Send, 
  ShieldAlert, 
  Plus, 
  Sparkles, 
  Volume2,
  Calendar,
  X
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { StaffAlert, AlertSeverity, AlertType } from '../../types';

export const StaffAlertsFeed: React.FC = () => {
  const { 
    staffAlerts, 
    medicationReminders, 
    broadcastStaffAlert, 
    acknowledgeStaffAlert, 
    resolveStaffAlert,
    addMedicationReminder, 
    logMedicationAdherence, 
    patients,
    t 
  } = useHospital();

  const { currentUser } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState<'staff' | 'medication'>('staff');

  // Emergency Broadcast Form State
  const [isBroadcastModalOpen, setIsBroadcastModalOpen] = useState(false);
  const [alertType, setAlertType] = useState<AlertType>('CODE_BLUE');
  const [alertSeverity, setAlertSeverity] = useState<AlertSeverity>('EMERGENCY');
  const [alertTitle, setAlertTitle] = useState('CODE BLUE - Resuscitation Protocol');
  const [alertLocation, setAlertLocation] = useState('ICU Bay 1');
  const [alertMessage, setAlertMessage] = useState('Cardiac arrest team dispatched immediately. Bring crash cart #3.');

  // Med Reminder Form State
  const [isMedModalOpen, setIsMedModalOpen] = useState(false);
  const [medPatientId, setMedPatientId] = useState(patients[0]?.id || '');
  const [medName, setMedName] = useState('Metoprolol Tartrate 50mg');
  const [medDosage, setMedDosage] = useState('50 mg');
  const [medScheduledTime, setMedScheduledTime] = useState('09:00 AM');
  const [medFrequency, setMedFrequency] = useState('Daily Morning');
  const [medInstructions, setMedInstructions] = useState('Take with breakfast and full glass of water.');

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!alertTitle.trim()) return;

    broadcastStaffAlert({
      type: alertType,
      title: alertTitle,
      message: alertMessage,
      location: alertLocation,
      severity: alertSeverity,
    });

    setIsBroadcastModalOpen(false);
  };

  const handleScheduleMed = (e: React.FormEvent) => {
    e.preventDefault();
    const patient = patients.find(p => p.id === medPatientId);
    if (!patient) return;

    addMedicationReminder({
      patientId: patient.id,
      patientName: patient.name,
      medicationName: medName,
      dosage: medDosage,
      scheduledTime: medScheduledTime,
      frequency: medFrequency,
      instructions: medInstructions
    });

    setIsMedModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-bold text-lg text-slate-900 flex items-center gap-2">
              <BellRing className="w-5 h-5 text-red-600" />
              Real-Time Push Notifications & Medication Reminders
            </h2>
            <p className="text-xs text-slate-500">
              Dispatches STAT emergency alerts to clinical teams and SMS/Push adherence alerts to patients.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsBroadcastModalOpen(true)}
              className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
            >
              <Radio className="w-4 h-4" />
              Dispatch Emergency Code (STAT)
            </button>
            <button
              onClick={() => setIsMedModalOpen(true)}
              className="px-3.5 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Schedule Med Reminder
            </button>
          </div>
        </div>

        {/* Sub-tabs */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={() => setActiveSubTab('staff')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'staff'
                ? 'bg-red-50 text-red-800 border border-red-200 shadow-xs'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Radio className="w-4 h-4" />
            Clinical Staff STAT Broadcasts ({staffAlerts.filter(a => !a.resolved).length} Active)
          </button>
          <button
            onClick={() => setActiveSubTab('medication')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'medication'
                ? 'bg-teal-50 text-teal-800 border border-teal-200 shadow-xs'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Pill className="w-4 h-4" />
            Patient Medication Adherence Reminders ({medicationReminders.length})
          </button>
        </div>
      </div>

      {/* Staff Alerts Sub-Tab */}
      {activeSubTab === 'staff' && (
        <div className="space-y-3">
          {staffAlerts.map((alert) => {
            return (
              <div
                key={alert.id}
                className={`p-5 rounded-3xl border-2 transition space-y-3 ${
                  alert.resolved
                    ? 'bg-slate-50 border-slate-200 opacity-75'
                    : alert.severity === 'EMERGENCY'
                    ? 'bg-red-50/80 border-red-500 shadow-sm'
                    : alert.severity === 'CRITICAL'
                    ? 'bg-rose-50/70 border-rose-400'
                    : 'bg-amber-50/70 border-amber-400'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className={`p-2.5 rounded-2xl text-white shrink-0 ${
                      alert.resolved ? 'bg-slate-400' :
                      alert.severity === 'EMERGENCY' ? 'bg-red-600 animate-pulse' :
                      alert.severity === 'CRITICAL' ? 'bg-rose-600' : 'bg-amber-600'
                    }`}>
                      <Radio className="w-5 h-5" />
                    </div>

                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-md font-extrabold text-[10px] tracking-wider uppercase ${
                          alert.severity === 'EMERGENCY' ? 'bg-red-600 text-white' :
                          alert.severity === 'CRITICAL' ? 'bg-rose-600 text-white' : 'bg-amber-600 text-white'
                        }`}>
                          {alert.type.replace('_', ' ')} • {alert.severity}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono font-semibold">
                          {alert.timestamp}
                        </span>
                      </div>

                      <h3 className="font-bold text-sm sm:text-base text-slate-900">
                        {alert.title}
                      </h3>

                      <p className="text-xs text-slate-700">
                        Floor / Unit: <strong className="text-slate-900">{alert.location}</strong> — {alert.message}
                      </p>
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex items-center gap-2 self-start sm:self-center">
                    {alert.resolved ? (
                      <span className="px-3 py-1.5 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Acknowledged & Resolved
                      </span>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => acknowledgeStaffAlert(alert.id)}
                          className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold shadow-xs transition"
                        >
                          Acknowledge
                        </button>
                        <button
                          onClick={() => resolveStaffAlert(alert.id)}
                          className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
                        >
                          Mark Resolved
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Patient Medication Reminders Sub-Tab */}
      {activeSubTab === 'medication' && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {medicationReminders.map((reminder) => {
              const isTaken = reminder.status === 'TAKEN';
              return (
                <div
                  key={reminder.id}
                  className={`p-5 rounded-3xl border transition space-y-3 ${
                    isTaken
                      ? 'bg-emerald-50/50 border-emerald-300'
                      : 'bg-white border-slate-200 shadow-2xs hover:border-teal-400'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className={`p-2.5 rounded-2xl ${
                        isTaken ? 'bg-emerald-600 text-white' : 'bg-teal-50 text-teal-800'
                      }`}>
                        <Pill className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900">
                          {reminder.patientName}
                        </h4>
                        <p className="text-xs font-bold text-teal-800">
                          {reminder.medicationName} ({reminder.dosage})
                        </p>
                      </div>
                    </div>

                    <div className="text-right text-xs">
                      <span className="font-mono font-bold text-slate-800 block">
                        ⏰ {reminder.scheduledTime}
                      </span>
                      <span className="text-[10px] text-slate-500">{reminder.frequency}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    💡 {reminder.instructions}
                  </p>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-slate-500">
                      Adherence Tracking:
                    </span>

                    {isTaken ? (
                      <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Taken at {reminder.lastLoggedAt || '08:00 AM'}
                      </span>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => logMedicationAdherence(reminder.id, 'SNOOZED')}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition"
                        >
                          Snooze (15m)
                        </button>
                        <button
                          onClick={() => logMedicationAdherence(reminder.id, 'TAKEN')}
                          className="px-3.5 py-1.5 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-xl transition shadow-xs"
                        >
                          Confirm Dose Taken
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Emergency Broadcast Modal */}
      {isBroadcastModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-red-600 flex items-center gap-2">
                <Radio className="w-5 h-5" />
                Dispatch Hospital STAT Alert
              </h3>
              <button onClick={() => setIsBroadcastModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleBroadcast} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Code Type:</label>
                <select
                  value={alertType}
                  onChange={(e) => setAlertType(e.target.value as AlertType)}
                  className="w-full p-2 rounded-xl border border-slate-300 font-bold"
                >
                  <option value="CODE_BLUE">CODE BLUE (Cardiac Arrest)</option>
                  <option value="TRAUMA_STAT">TRAUMA STAT (Severe Trauma Inbound)</option>
                  <option value="STAT_LAB">STAT CRITICAL LAB</option>
                  <option value="BED_SHORTAGE">BED CAPACITY SURGE</option>
                  <option value="APPOINTMENT_REMINDER">APPOINTMENT REMINDER</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Title / Headline:</label>
                <input
                  type="text"
                  required
                  value={alertTitle}
                  onChange={(e) => setAlertTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Location / Unit:</label>
                <input
                  type="text"
                  required
                  value={alertLocation}
                  onChange={(e) => setAlertLocation(e.target.value)}
                  placeholder="e.g. ICU Bay 2 / Trauma Suite A"
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Clinical Instructions:</label>
                <textarea
                  rows={3}
                  value={alertMessage}
                  onChange={(e) => setAlertMessage(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsBroadcastModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-xs"
                >
                  Broadcast Push Alert
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Schedule Medication Reminder Modal */}
      {isMedModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-teal-800 flex items-center gap-2">
                <Pill className="w-5 h-5" />
                Schedule Patient Medication Reminder
              </h3>
              <button onClick={() => setIsMedModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleScheduleMed} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Patient:</label>
                <select
                  value={medPatientId}
                  onChange={(e) => setMedPatientId(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-300 font-semibold"
                >
                  {patients.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.mrn})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Medication Name:</label>
                <input
                  type="text"
                  required
                  value={medName}
                  onChange={(e) => setMedName(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Dosage:</label>
                  <input
                    type="text"
                    required
                    value={medDosage}
                    onChange={(e) => setMedDosage(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Reminder Time:</label>
                  <input
                    type="text"
                    required
                    value={medScheduledTime}
                    onChange={(e) => setMedScheduledTime(e.target.value)}
                    placeholder="e.g. 08:00 AM"
                    className="w-full p-2 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Frequency:</label>
                <input
                  type="text"
                  value={medFrequency}
                  onChange={(e) => setMedFrequency(e.target.value)}
                  placeholder="e.g. Daily with breakfast"
                  className="w-full p-2 rounded-xl border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Instructions / Note:</label>
                <input
                  type="text"
                  value={medInstructions}
                  onChange={(e) => setMedInstructions(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsMedModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl shadow-xs"
                >
                  Queue Reminder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
