import React, { useState } from 'react';
import { 
  BedDouble, 
  Users, 
  Calendar, 
  Receipt, 
  AlertTriangle, 
  ArrowUpRight, 
  Plus, 
  Activity, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  Radio, 
  HeartPulse, 
  ChevronRight, 
  ShieldCheck,
  Send,
  X,
  BrainCircuit,
  Sparkles,
  Building2,
  Flame
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { NavTab } from '../layout/Sidebar';
import { AlertType, AlertSeverity } from '../../types';

interface DashboardProps {
  onNavigate: (tab: NavTab) => void;
}

export const DashboardOverview: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { 
    wards, 
    patients, 
    appointments, 
    invoices, 
    staffAlerts, 
    totalBedsCount, 
    occupiedBedsCount, 
    availableBedsCount, 
    cleaningBedsCount, 
    overallOccupancyPercent, 
    activeCriticalAlertsCount,
    todayAppointmentsCount,
    pendingClaimsTotalValue,
    broadcastStaffAlert,
    acknowledgeStaffAlert,
    setSelectedPatientId,
    sendStaffAppointmentAlert,
    updateAppointmentStatus,
    triageAssessments,
    t
  } = useHospital();

  const { currentUser } = useAuth();
  const [isBroadcastModalOpen, setIsBroadcastModalOpen] = useState(false);
  const [newAlertTitle, setNewAlertTitle] = useState('');
  const [newAlertLocation, setNewAlertLocation] = useState('');
  const [newAlertType, setNewAlertType] = useState<AlertType>('CODE_BLUE');
  const [newAlertSeverity, setNewAlertSeverity] = useState<AlertSeverity>('EMERGENCY');
  const [newAlertMessage, setNewAlertMessage] = useState('');

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAlertTitle.trim()) return;

    broadcastStaffAlert({
      type: newAlertType,
      title: newAlertTitle,
      message: newAlertMessage || `${newAlertType} reported in ${newAlertLocation}`,
      location: newAlertLocation || 'Hospital General',
      severity: newAlertSeverity,
    });

    setIsBroadcastModalOpen(false);
    setNewAlertTitle('');
    setNewAlertLocation('');
    setNewAlertMessage('');
  };

  const todayAppointments = appointments.filter(a => a.date === '2026-08-31');
  const activeEmergencies = staffAlerts.filter(a => !a.resolved);

  return (
    <div className="space-y-6">
      {/* Top STAT Emergency Banner if active */}
      {activeCriticalAlertsCount > 0 && (
        <div className="bg-red-50 border-2 border-red-500 rounded-3xl p-4 sm:p-5 shadow-sm animate-in fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="p-3 bg-red-600 text-white rounded-2xl animate-bounce">
                <Radio className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 bg-red-600 text-white text-[10px] font-extrabold uppercase rounded-full tracking-wider">
                    STAT Critical Alert
                  </span>
                  <span className="text-xs text-red-700 font-semibold font-mono">
                    {activeEmergencies[0]?.timestamp}
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-bold text-red-950 mt-0.5">
                  {activeEmergencies[0]?.title}
                </h2>
                <p className="text-xs text-red-800">
                  Location: <span className="font-bold">{activeEmergencies[0]?.location}</span> — {activeEmergencies[0]?.message}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => acknowledgeStaffAlert(activeEmergencies[0].id)}
                className="flex-1 sm:flex-initial px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-xs transition"
              >
                Acknowledge Alert
              </button>
              <button
                onClick={() => onNavigate('alerts')}
                className="flex-1 sm:flex-initial px-4 py-2 bg-white text-red-700 border border-red-300 hover:bg-red-50 font-bold rounded-xl text-xs transition"
              >
                All Alerts ({activeEmergencies.length})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main KPI Stat Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Ward Bed Utilization */}
        <div 
          onClick={() => onNavigate('wards')}
          className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {t.realTimeOccupancy}
            </span>
            <div className="p-2.5 bg-teal-50 text-teal-700 rounded-2xl group-hover:scale-110 transition">
              <BedDouble className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{overallOccupancyPercent}%</span>
            <span className="text-xs text-slate-500 font-medium">
              ({occupiedBedsCount} of {totalBedsCount} Beds)
            </span>
          </div>
          <div className="mt-3 w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                overallOccupancyPercent > 85 ? 'bg-red-500' : overallOccupancyPercent > 70 ? 'bg-amber-500' : 'bg-teal-600'
              }`}
              style={{ width: `${overallOccupancyPercent}%` }}
            />
          </div>
          <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500">
            <span>Available: <strong className="text-emerald-700 font-semibold">{availableBedsCount}</strong></span>
            <span>Cleaning: <strong className="text-amber-700 font-semibold">{cleaningBedsCount}</strong></span>
          </div>
        </div>

        {/* Inpatient Census */}
        <div 
          onClick={() => onNavigate('patients')}
          className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {t.totalPatients}
            </span>
            <div className="p-2.5 bg-cyan-50 text-cyan-700 rounded-2xl group-hover:scale-110 transition">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{patients.length}</span>
            <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3" /> +2 Today
            </span>
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Active EMR Records registered in hospital system with HIPAA compliance.
          </p>
        </div>

        {/* Today's Appointments */}
        <div 
          onClick={() => onNavigate('appointments')}
          className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {t.activeAppointments}
            </span>
            <div className="p-2.5 bg-indigo-50 text-indigo-700 rounded-2xl group-hover:scale-110 transition">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{todayAppointmentsCount}</span>
            <span className="text-xs text-indigo-700 font-semibold bg-indigo-50 px-2 py-0.5 rounded-full">
              4 Scheduled
            </span>
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Consultations, post-op reviews, and triage sessions queued today.
          </p>
        </div>

        {/* Revenue & Claims */}
        <div 
          onClick={() => onNavigate('billing')}
          className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs hover:border-teal-500/50 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              {t.pendingBilling}
            </span>
            <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-2xl group-hover:scale-110 transition">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-mono">
              ${(pendingClaimsTotalValue).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
            </span>
            <span className="text-xs text-slate-500 font-medium">Patient Due</span>
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Automated insurance splits applied (CPT & ICD-10 itemized).
          </p>
        </div>
      </div>

      {/* AI Clinical Triage & ICD-10 Specialist Guidance Feature Card */}
      <div className="bg-gradient-to-r from-teal-900 via-teal-950 to-slate-900 text-white p-5 sm:p-6 rounded-3xl border border-teal-700/50 shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-teal-500/20 text-teal-300 rounded-2xl border border-teal-400/30 shrink-0">
            <BrainCircuit className="w-7 h-7 animate-pulse" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 bg-teal-500/30 text-teal-200 border border-teal-400/30 text-[10px] font-extrabold uppercase rounded-full tracking-wider">
                Clinical Intelligence Engine
              </span>
              <span className="text-xs text-teal-300 font-semibold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                WHO ICD-10 & ESI v4 Compliant
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-extrabold">
              AI Symptom Triage & Specialist Department Routing
            </h3>
            <p className="text-xs text-teal-100/90 max-w-xl leading-relaxed">
              Analyze initial patient symptoms during registration to predict diagnostic ICD-10 codes, assess clinical acuity, and allocate specialist departments instantly.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <button
            id="btn-dash-open-triage"
            onClick={() => onNavigate('triage')}
            className="w-full md:w-auto px-5 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-extrabold text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
          >
            <BrainCircuit className="w-4 h-4" />
            Launch AI Triage Assistant ({triageAssessments.length} Active)
          </button>
        </div>
      </div>

      {/* Mid Section: Ward Breakdown & Urgent Broadcast Control */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-Time Ward Bed Heatmap */}
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <BedDouble className="w-5 h-5 text-teal-700" />
                {t.realTimeOccupancy} Matrix
              </h2>
              <p className="text-xs text-slate-500">
                Live monitoring across ICU, Cardiology, Surgery, Pediatrics, and Maternity floors.
              </p>
            </div>
            <button
              onClick={() => onNavigate('wards')}
              className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1 bg-teal-50 hover:bg-teal-100 px-3 py-1.5 rounded-xl transition"
            >
              Manage Beds <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4">
            {wards.map((ward) => {
              const occupied = ward.beds.filter(b => b.status === 'Occupied').length;
              const percent = Math.round((occupied / ward.beds.length) * 100);
              return (
                <div key={ward.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span 
                        className="w-2.5 h-2.5 rounded-full" 
                        style={{ backgroundColor: ward.color }} 
                      />
                      <span className="font-bold text-slate-900">{ward.name}</span>
                      <span className="text-[10px] text-slate-500">({ward.code} • Floor {ward.floor})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-800">{occupied}/{ward.beds.length} Beds</span>
                      <span className="font-mono font-bold text-teal-800 bg-teal-100 px-2 py-0.5 rounded-md text-[11px]">
                        {percent}%
                      </span>
                    </div>
                  </div>

                  {/* Bed visual nodes */}
                  <div className="grid grid-cols-6 sm:grid-cols-8 gap-1.5 pt-1">
                    {ward.beds.map((bed) => (
                      <div
                        key={bed.id}
                        title={`${bed.bedNumber} (${bed.roomNumber}): ${bed.status}${bed.patientName ? ` - ${bed.patientName}` : ''}`}
                        className={`p-1.5 rounded-lg text-center text-[10px] font-bold border transition ${
                          bed.status === 'Occupied'
                            ? 'bg-rose-50 border-rose-300 text-rose-800'
                            : bed.status === 'Available'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                            : bed.status === 'Cleaning'
                            ? 'bg-amber-50 border-amber-300 text-amber-800'
                            : 'bg-slate-200 border-slate-300 text-slate-700'
                        }`}
                      >
                        <p className="truncate text-[9px]">{bed.bedNumber.replace('Bed ', '')}</p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Action & Clinical Broadcast Hub */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs flex flex-col justify-between space-y-6">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <HeartPulse className="w-5 h-5 text-teal-700" />
                Staff Broadcast Hub
              </h2>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Dispatch hospital-wide emergency codes or department clinical notifications immediately.
            </p>

            <button
              onClick={() => setIsBroadcastModalOpen(true)}
              className="w-full py-3 px-4 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-700 hover:to-rose-800 text-white font-bold rounded-2xl text-xs shadow-md shadow-red-600/20 flex items-center justify-center gap-2 transition"
            >
              <Radio className="w-4 h-4" />
              Dispatch Emergency Code (STAT)
            </button>

            {/* Quick Actions List */}
            <div className="mt-5 space-y-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Frequent Workflows
              </span>
              <button
                onClick={() => onNavigate('adminBottlenecks')}
                className="w-full text-left p-2.5 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 text-xs font-bold text-rose-950 flex items-center justify-between transition"
              >
                <span className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-rose-600" />
                  Department Bottlenecks & Capacity
                </span>
                <span className="flex items-center gap-1 text-[10px] bg-rose-600 text-white px-2 py-0.5 rounded-full font-extrabold">
                  <Flame className="w-3 h-3 text-amber-300" /> Live
                </span>
              </button>
              <button
                onClick={() => onNavigate('workflow')}
                className="w-full text-left p-2.5 rounded-xl border border-blue-200 bg-blue-50 hover:bg-blue-100 text-xs font-bold text-blue-950 flex items-center justify-between transition"
              >
                <span className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-700" />
                  Outpatient Closed-Loop Care Journey
                </span>
                <ChevronRight className="w-4 h-4 text-blue-700" />
              </button>
              <button
                onClick={() => onNavigate('scanner')}
                className="w-full text-left p-2.5 rounded-xl border border-purple-200 bg-purple-50 hover:bg-purple-100 text-xs font-bold text-purple-950 flex items-center justify-between transition"
              >
                <span className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-purple-700" />
                  Optical Camera BCMA Scanner
                </span>
                <ChevronRight className="w-4 h-4 text-purple-700" />
              </button>
              <button
                onClick={() => onNavigate('labs')}
                className="w-full text-left p-2.5 rounded-xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-xs font-semibold text-slate-800 flex items-center justify-between transition"
              >
                <span>Diagnostic Pathology Labs</span>
                <ChevronRight className="w-4 h-4 text-indigo-700" />
              </button>
              <button
                onClick={() => onNavigate('pharmacy')}
                className="w-full text-left p-2.5 rounded-xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-xs font-semibold text-slate-800 flex items-center justify-between transition"
              >
                <span>Central Pharmacy Dispensing</span>
                <ChevronRight className="w-4 h-4 text-emerald-700" />
              </button>
              <button
                onClick={() => onNavigate('patients')}
                className="w-full text-left p-2.5 rounded-xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-xs font-semibold text-slate-800 flex items-center justify-between transition"
              >
                <span>Register New Inpatient EHR</span>
                <Plus className="w-4 h-4 text-teal-700" />
              </button>
              <button
                onClick={() => onNavigate('appointments')}
                className="w-full text-left p-2.5 rounded-xl border border-slate-200 hover:border-teal-500 hover:bg-teal-50/50 text-xs font-semibold text-slate-800 flex items-center justify-between transition"
              >
                <span>Schedule Consultation</span>
                <Calendar className="w-4 h-4 text-indigo-700" />
              </button>
            </div>
          </div>

          <div className="p-3 bg-teal-50/60 rounded-2xl border border-teal-100 text-xs text-teal-900 flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-teal-700 shrink-0" />
            <p className="text-[11px] leading-relaxed">
              All clinical staff actions are logged to the tamper-evident HIPAA Audit trail.
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Section: Today's Appointments & Inpatient Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Appointments Agenda */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-600" />
              <h2 className="font-bold text-base text-slate-900">Today's Appointment Schedule</h2>
            </div>
            <button
              onClick={() => onNavigate('appointments')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              Full Calendar <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {todayAppointments.map((apt) => (
              <div
                key={apt.id}
                className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-slate-900 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                      {apt.time}
                    </span>
                    <span className="font-bold text-xs text-slate-900">{apt.patientName}</span>
                    <span className="text-[10px] text-slate-400">({apt.patientMrn})</span>
                  </div>
                  <p className="text-xs text-slate-600">
                    {apt.type} • {apt.doctorName} • <span className="font-medium text-slate-800">{apt.roomNumber}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => sendStaffAppointmentAlert(apt.id)}
                    className="px-2.5 py-1 text-xs bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl font-semibold transition flex items-center gap-1"
                    title="Alert medical staff of patient arrival"
                  >
                    <Send className="w-3 h-3" />
                    Alert Staff
                  </button>
                  <button
                    onClick={() => {
                      setSelectedPatientId(apt.patientId);
                      onNavigate('patients');
                    }}
                    className="px-2.5 py-1 text-xs bg-teal-50 text-teal-800 hover:bg-teal-100 rounded-xl font-semibold transition"
                  >
                    View EHR
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Inpatients Overview with Vitals */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-teal-700" />
              <h2 className="font-bold text-base text-slate-900">Current Inpatients & Vitals</h2>
            </div>
            <button
              onClick={() => onNavigate('patients')}
              className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1"
            >
              All Records <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {patients.slice(0, 4).map((p) => {
              const latestVital = p.vitals[0];
              return (
                <div
                  key={p.id}
                  onClick={() => {
                    setSelectedPatientId(p.id);
                    onNavigate('patients');
                  }}
                  className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-teal-400 hover:bg-teal-50/30 transition cursor-pointer flex items-center justify-between"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900">{p.name}</span>
                      <span className="text-[10px] text-slate-400">{p.age}y / {p.gender[0]}</span>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 bg-rose-100 text-rose-800 rounded-md">
                        {p.bloodType}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {p.assignedWard || 'Outpatient'} {p.assignedBed && `• ${p.assignedBed}`}
                    </p>
                  </div>

                  {latestVital ? (
                    <div className="text-right text-xs">
                      <div className="font-mono font-bold text-slate-800">
                        BP: {latestVital.bloodPressure}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        HR: <span className="font-bold text-slate-700">{latestVital.heartRate} bpm</span> • SpO2: <span className="font-bold text-emerald-700">{latestVital.spo2}%</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-400 italic">No vitals logged</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Emergency Broadcast Modal */}
      {isBroadcastModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
            <div className="bg-red-600 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-white/20 rounded-2xl">
                  <Radio className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Hospital Emergency Broadcast</h3>
                  <p className="text-xs text-red-100">Send STAT Alert to All Clinical Staff Devices</p>
                </div>
              </div>
              <button 
                onClick={() => setIsBroadcastModalOpen(false)}
                className="p-1.5 text-red-100 hover:text-white hover:bg-white/10 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBroadcast} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Alert Code Type:
                </label>
                <select
                  value={newAlertType}
                  onChange={(e) => {
                    const val = e.target.value as AlertType;
                    setNewAlertType(val);
                    if (val === 'CODE_BLUE') {
                      setNewAlertTitle('CODE BLUE - Cardiac Arrest Resuscitation Team');
                      setNewAlertSeverity('EMERGENCY');
                    } else if (val === 'TRAUMA_STAT') {
                      setNewAlertTitle('TRAUMA LEVEL 1 - Severe Inbound Patient');
                      setNewAlertSeverity('EMERGENCY');
                    } else if (val === 'STAT_LAB') {
                      setNewAlertTitle('STAT Critical Lab Value Trigger');
                      setNewAlertSeverity('CRITICAL');
                    } else if (val === 'BED_SHORTAGE') {
                      setNewAlertTitle('Bed Capacity Surge Protocol');
                      setNewAlertSeverity('WARNING');
                    }
                  }}
                  className="w-full text-xs font-semibold p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-red-500"
                >
                  <option value="CODE_BLUE">🚨 CODE BLUE (Cardiac Arrest / Resuscitation)</option>
                  <option value="TRAUMA_STAT">⚠️ TRAUMA STAT (Level 1 Trauma Inbound)</option>
                  <option value="STAT_LAB">🧪 STAT CRITICAL LAB ALERT</option>
                  <option value="BED_SHORTAGE">🛏️ BED CAPACITY SURGE WARNING</option>
                  <option value="CLINICAL_UPDATE">📋 CLINICAL STAFF ADVISORY</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Alert Headline:
                </label>
                <input
                  type="text"
                  required
                  value={newAlertTitle}
                  onChange={(e) => setNewAlertTitle(e.target.value)}
                  placeholder="e.g. CODE BLUE in Trauma Bay 1"
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Location / Floor / Bay:
                  </label>
                  <input
                    type="text"
                    required
                    value={newAlertLocation}
                    onChange={(e) => setNewAlertLocation(e.target.value)}
                    placeholder="e.g. ICU Bed 201 / ER Bay 2"
                    className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Severity Level:
                  </label>
                  <select
                    value={newAlertSeverity}
                    onChange={(e) => setNewAlertSeverity(e.target.value as AlertSeverity)}
                    className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-red-500 font-semibold"
                  >
                    <option value="EMERGENCY">EMERGENCY (Immediate STAT)</option>
                    <option value="CRITICAL">CRITICAL</option>
                    <option value="WARNING">WARNING</option>
                    <option value="INFO">INFO</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Clinical Instructions / Message:
                </label>
                <textarea
                  rows={3}
                  value={newAlertMessage}
                  onChange={(e) => setNewAlertMessage(e.target.value)}
                  placeholder="Provide immediate clinical directions, equipment needs (e.g. Defibrillator, Intubation tray)."
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsBroadcastModalOpen(false)}
                  className="flex-1 py-3 rounded-xl border border-slate-200 text-slate-700 font-semibold text-xs hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-md shadow-red-600/20 flex items-center justify-center gap-2"
                >
                  <Radio className="w-4 h-4" />
                  Transmit Broadcast Now
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
