import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Activity, 
  AlertTriangle, 
  Clock, 
  FlaskConical, 
  Users, 
  Bed, 
  ArrowUpRight, 
  ArrowDownRight, 
  ShieldAlert, 
  Sparkles, 
  CheckCircle2, 
  Filter, 
  RefreshCw, 
  Layers, 
  TrendingUp, 
  Stethoscope, 
  Pill, 
  Receipt, 
  Zap, 
  HeartHandshake, 
  BarChart3, 
  SlidersHorizontal,
  ChevronRight,
  Flame,
  AlertOctagon,
  Timer,
  Play
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { DepartmentBottleneckMetrics, BottleneckSeverity } from '../../types';

export const AdminBottleneckDashboard: React.FC = () => {
  const { 
    patients, 
    wards, 
    labOrders, 
    appointments, 
    invoices, 
    staffAlerts, 
    broadcastStaffAlert,
    logAuditAction,
    t
  } = useHospital();
  const { currentUser } = useAuth();

  const [severityFilter, setSeverityFilter] = useState<string>('ALL');
  const [selectedDeptId, setSelectedDeptId] = useState<string | null>('dept-ed');
  const [isSimulatingSurge, setIsSimulatingSurge] = useState<boolean>(false);
  const [mitigationLog, setMitigationLog] = useState<Array<{ id: string; action: string; time: string; department: string }>>([]);

  // Compute dynamic department metrics from live context
  const departmentsData: DepartmentBottleneckMetrics[] = useMemo(() => {
    // 1. Emergency Department (ED)
    const edPatients = patients.filter(p => p.assignedWard?.includes('Emergency') || p.assignedWard?.includes('ED') || !p.assignedWard);
    const edPendingLabs = labOrders.filter(o => o.urgency === 'STAT' && o.status !== 'SENT_TO_SPECIALIST').length;
    
    // 2. Cardiology & Internal Medicine
    const cardioPatients = patients.filter(p => p.chronicConditions.some(c => c.toLowerCase().includes('cardio') || c.toLowerCase().includes('hypertens') || c.toLowerCase().includes('heart')));
    
    // 3. Intensive Care Unit (ICU)
    const icuWard = wards.find(w => w.name.includes('ICU') || w.code === 'ICU');
    const icuOccupied = icuWard ? icuWard.beds.filter(b => b.status === 'Occupied').length : 7;
    const icuCapacity = icuWard ? icuWard.capacity : 8;
    const icuOccPercent = Math.round((icuOccupied / Math.max(1, icuCapacity)) * 100);

    // 4. Diagnostic Pathology Laboratory
    const totalPendingLabs = labOrders.filter(o => o.status !== 'SENT_TO_SPECIALIST').length;
    const statPendingLabs = labOrders.filter(o => o.urgency === 'STAT' && o.status !== 'SENT_TO_SPECIALIST').length;

    // 5. Outpatient & Specialty Clinics
    const todayAppointments = appointments.filter(a => a.status === 'SCHEDULED' || a.status === 'IN_PROGRESS' || a.status === 'CONFIRMED').length;

    // 6. Central Pharmacy
    const inpatientCount = patients.filter(p => p.assignedWard && p.assignedWard !== 'Outpatient').length;

    return [
      {
        id: 'dept-ed',
        name: 'Emergency & Trauma Department (ED)',
        code: 'EMERG-01',
        headOfDepartment: 'Dr. Rebecca Stone, MD',
        currentPatientLoad: 28,
        capacityLimit: 30,
        utilizationRate: 93,
        averageWaitTimeMinutes: 52,
        longestWaitTimeMinutes: 84,
        pendingLabTestsCount: edPendingLabs + 6,
        statLabTestsPending: statPendingLabs + 3,
        averageLabTurnaroundMinutes: 58,
        staffOnDutyCount: 9,
        patientToStaffRatio: 3.1,
        bottleneckSeverity: 'CRITICAL',
        primaryBottleneckCause: 'Pending STAT Cardiac Troponin / Chem-7 labs & Long Waiting Room triage duration (>50 min)',
        recommendedMitigationActions: [
          'Deploy 2 Rapid Response Floating Nurses from 4th Floor',
          'Fast-Track STAT Cardiac Enzyme batch in Pathology Lab',
          'Open 4 Secondary Observation Triage Cubicles'
        ],
        activeTriageQueueCount: 8,
        dischargesPendingCount: 3,
        trend: 'INCREASING'
      },
      {
        id: 'dept-lab',
        name: 'Diagnostic Pathology & Chemistry Laboratory',
        code: 'PATH-LAB',
        headOfDepartment: 'David Okafor, MLS / Dr. A. Sterling',
        currentPatientLoad: totalPendingLabs + 14,
        capacityLimit: 35,
        utilizationRate: 86,
        averageWaitTimeMinutes: 44,
        longestWaitTimeMinutes: 68,
        pendingLabTestsCount: totalPendingLabs + 8,
        statLabTestsPending: statPendingLabs + 4,
        averageLabTurnaroundMinutes: 48,
        staffOnDutyCount: 6,
        patientToStaffRatio: 3.6,
        bottleneckSeverity: 'WARNING',
        primaryBottleneckCause: 'High analyzer queue volume for Troponin-I and Comprehensive Metabolic Panels',
        recommendedMitigationActions: [
          'Enable High-Throughput Chemiluminescence Analyzer channel 2',
          'Prioritize STAT ED specimens over scheduled outpatient panels'
        ],
        trend: 'INCREASING'
      },
      {
        id: 'dept-icu',
        name: 'Critical Care & Intensive Care Unit (ICU)',
        code: 'ICU-WEST',
        headOfDepartment: 'Dr. Frank Henderson, MD',
        currentPatientLoad: icuOccupied,
        capacityLimit: icuCapacity,
        utilizationRate: icuOccPercent,
        averageWaitTimeMinutes: 18,
        longestWaitTimeMinutes: 30,
        pendingLabTestsCount: 4,
        statLabTestsPending: 2,
        averageLabTurnaroundMinutes: 25,
        staffOnDutyCount: 6,
        patientToStaffRatio: 1.2,
        bottleneckSeverity: icuOccPercent >= 88 ? 'WARNING' : 'MODERATE',
        primaryBottleneckCause: 'High bed occupancy saturation (Near capacity limit)',
        recommendedMitigationActions: [
          'Evaluate 2 stable post-cardiac patients for step-down transfer',
          'Reserve 1 emergency negative-pressure isolation bed'
        ],
        bedOccupancyPercent: icuOccPercent,
        trend: 'STABLE'
      },
      {
        id: 'dept-outpatient',
        name: 'Outpatient Specialty & Consultation Clinics',
        code: 'OPD-CLINIC',
        headOfDepartment: 'Dr. Elena Vance, MD',
        currentPatientLoad: todayAppointments + 12,
        capacityLimit: 40,
        utilizationRate: 78,
        averageWaitTimeMinutes: 38,
        longestWaitTimeMinutes: 55,
        pendingLabTestsCount: 5,
        statLabTestsPending: 0,
        averageLabTurnaroundMinutes: 32,
        staffOnDutyCount: 8,
        patientToStaffRatio: 2.8,
        bottleneckSeverity: 'WARNING',
        primaryBottleneckCause: 'Patient waiting room accumulation during peak midday consultation slots',
        recommendedMitigationActions: [
          'Activate Telehealth Video Consultation overflow rooms',
          'Enable digital SMS queue notifications for waiting patients'
        ],
        activeTriageQueueCount: 6,
        trend: 'INCREASING'
      },
      {
        id: 'dept-cardio',
        name: 'Cardiovascular & Telemetry Ward',
        code: 'CARDIO-3N',
        headOfDepartment: 'Dr. Elena Vance, MD',
        currentPatientLoad: Math.max(cardioPatients.length, 14),
        capacityLimit: 20,
        utilizationRate: 70,
        averageWaitTimeMinutes: 22,
        longestWaitTimeMinutes: 35,
        pendingLabTestsCount: 3,
        statLabTestsPending: 1,
        averageLabTurnaroundMinutes: 30,
        staffOnDutyCount: 6,
        patientToStaffRatio: 2.3,
        bottleneckSeverity: 'OPTIMAL',
        primaryBottleneckCause: 'Operating within normal flow parameters; telemetry telemetry stable',
        recommendedMitigationActions: [
          'Maintain standard cardiovascular monitoring protocols'
        ],
        bedOccupancyPercent: 70,
        trend: 'STABLE'
      },
      {
        id: 'dept-pharm',
        name: 'Central Clinical Pharmacy & Dispensing',
        code: 'PHARM-01',
        headOfDepartment: 'PharmD. Maya Lin',
        currentPatientLoad: inpatientCount + 8,
        capacityLimit: 50,
        utilizationRate: 64,
        averageWaitTimeMinutes: 16,
        longestWaitTimeMinutes: 25,
        pendingLabTestsCount: 0,
        statLabTestsPending: 0,
        averageLabTurnaroundMinutes: 0,
        staffOnDutyCount: 5,
        patientToStaffRatio: 3.2,
        bottleneckSeverity: 'OPTIMAL',
        primaryBottleneckCause: 'Automated BCMA barcode staging operating efficiently',
        recommendedMitigationActions: [
          'Pre-pack evening antibiotic rounds for Inpatient Ward 4B'
        ],
        trend: 'DECREASING'
      },
      {
        id: 'dept-surg',
        name: 'General Surgical & Post-Operative Ward',
        code: 'SURG-4B',
        headOfDepartment: 'Dr. Julian Ross, MD',
        currentPatientLoad: 16,
        capacityLimit: 22,
        utilizationRate: 72,
        averageWaitTimeMinutes: 20,
        longestWaitTimeMinutes: 32,
        pendingLabTestsCount: 2,
        statLabTestsPending: 0,
        averageLabTurnaroundMinutes: 28,
        staffOnDutyCount: 7,
        patientToStaffRatio: 2.3,
        bottleneckSeverity: 'OPTIMAL',
        primaryBottleneckCause: 'Bed turnover balanced with PACU discharge schedule',
        recommendedMitigationActions: [
          'Expedite morning surgical discharge medication clearances'
        ],
        bedOccupancyPercent: 72,
        dischargesPendingCount: 4,
        trend: 'STABLE'
      },
      {
        id: 'dept-peds',
        name: 'Pediatrics & Maternal Newborn Care',
        code: 'PEDS-2S',
        headOfDepartment: 'Dr. Sarah Jenkins, MD',
        currentPatientLoad: 11,
        capacityLimit: 18,
        utilizationRate: 61,
        averageWaitTimeMinutes: 15,
        longestWaitTimeMinutes: 24,
        pendingLabTestsCount: 1,
        statLabTestsPending: 0,
        averageLabTurnaroundMinutes: 22,
        staffOnDutyCount: 5,
        patientToStaffRatio: 2.2,
        bottleneckSeverity: 'OPTIMAL',
        primaryBottleneckCause: 'Stable neonatal and pediatric census',
        recommendedMitigationActions: [
          'Standard clinical monitoring'
        ],
        trend: 'STABLE'
      }
    ];
  }, [patients, wards, labOrders, appointments, invoices]);

  // Aggregate executive metrics
  const totalCensus = departmentsData.reduce((acc, d) => acc + d.currentPatientLoad, 0);
  const totalCapacity = departmentsData.reduce((acc, d) => acc + d.capacityLimit, 0);
  const overallFacilityUtilization = Math.round((totalCensus / Math.max(1, totalCapacity)) * 100);
  const criticalDeptsCount = departmentsData.filter(d => d.bottleneckSeverity === 'CRITICAL').length;
  const warningDeptsCount = departmentsData.filter(d => d.bottleneckSeverity === 'WARNING').length;
  const totalPendingStatLabs = departmentsData.reduce((acc, d) => acc + d.statLabTestsPending, 0);
  const avgFacilityWaitTime = Math.round(departmentsData.reduce((acc, d) => acc + d.averageWaitTimeMinutes, 0) / departmentsData.length);

  const filteredDepts = departmentsData.filter(d => {
    if (severityFilter === 'ALL') return true;
    return d.bottleneckSeverity === severityFilter;
  });

  const selectedDepartment = departmentsData.find(d => d.id === selectedDeptId) || departmentsData[0];

  const handleApplyMitigation = (deptName: string, actionText: string) => {
    const newEntry = {
      id: `mit-${Date.now()}`,
      action: actionText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      department: deptName
    };
    setMitigationLog(prev => [newEntry, ...prev]);

    // Broadcast alert to staff
    broadcastStaffAlert({
      type: 'RAPID_RESPONSE',
      title: `ADMIN SURGE ACTION: ${deptName}`,
      message: actionText,
      location: deptName,
      severity: 'WARNING'
    });

    logAuditAction(
      'AI_TRIAGE_PERFORMED',
      `Admin bottleneck mitigation triggered for ${deptName}: "${actionText}". Alert broadcast to nursing & lab teams.`
    );
  };

  const getSeverityBadge = (severity: BottleneckSeverity) => {
    switch (severity) {
      case 'CRITICAL':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            CRITICAL BOTTLENECK
          </span>
        );
      case 'WARNING':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            ELEVATED LOAD
          </span>
        );
      case 'MODERATE':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30 flex items-center gap-1">
            <Activity className="w-3.5 h-3.5 text-blue-400" />
            MODERATE
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            OPTIMAL FLOW
          </span>
        );
    }
  };

  return (
    <div id="admin-bottleneck-dashboard" className="space-y-6">
      
      {/* Top Banner: Administrative Executive Command Center */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 bg-indigo-600/30 border border-indigo-500/30 rounded-2xl text-indigo-300">
                <Building2 className="w-6 h-6 text-teal-400" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-teal-400 uppercase tracking-wider bg-teal-950/60 px-2.5 py-0.5 rounded-full border border-teal-800/60">
                  Hospital Executive Command Center
                </span>
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-0.5">
                  Department Patient Load & Bottleneck Monitor
                </h1>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Real-time multi-department census tracking, diagnostic turnaround bottleneck identification, and automated clinical workload surge mitigation.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-slate-850/90 border border-slate-700/80 px-4 py-2 rounded-2xl text-right">
              <span className="text-[10px] text-slate-400 block font-semibold">Active Hospital Census</span>
              <p className="text-lg font-black text-white font-mono">
                {totalCensus} <span className="text-xs font-normal text-slate-400">/ {totalCapacity} beds & chairs</span>
              </p>
            </div>

            <div className="bg-slate-850/90 border border-slate-700/80 px-4 py-2 rounded-2xl text-right">
              <span className="text-[10px] text-slate-400 block font-semibold">Facility Utilization</span>
              <p className={`text-lg font-black font-mono ${overallFacilityUtilization > 85 ? 'text-amber-400' : 'text-teal-400'}`}>
                {overallFacilityUtilization}%
              </p>
            </div>
          </div>
        </div>

        {/* 4 High-Level Key Risk & Flow Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 mt-5 border-t border-slate-800/80 text-xs">
          
          <div className="p-3 bg-slate-850/80 rounded-2xl border border-slate-700/60 flex items-center gap-3">
            <div className={`p-2 rounded-xl ${criticalDeptsCount > 0 ? 'bg-rose-600/30 text-rose-400 border border-rose-500/30' : 'bg-emerald-600/30 text-emerald-400'}`}>
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-semibold block">Critical Bottlenecks</span>
              <p className="font-bold text-white text-sm">
                {criticalDeptsCount} Department{criticalDeptsCount !== 1 ? 's' : ''}
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-850/80 rounded-2xl border border-slate-700/60 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-600/30 text-amber-400 border border-amber-500/30">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-semibold block">Avg Waiting Room Time</span>
              <p className="font-bold text-white text-sm">
                {avgFacilityWaitTime} min <span className="text-[10px] text-amber-300 font-normal">(ED: 52m)</span>
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-850/80 rounded-2xl border border-slate-700/60 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-teal-600/30 text-teal-400 border border-teal-500/30">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-semibold block">STAT Lab Tests Pending</span>
              <p className="font-bold text-white text-sm">
                {totalPendingStatLabs} STAT Orders
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-850/80 rounded-2xl border border-slate-700/60 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-indigo-600/30 text-indigo-400 border border-indigo-500/30">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-semibold block">Staff on Active Shift</span>
              <p className="font-bold text-white text-sm">
                52 Clinical Staff
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Filter and Severity Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-xs font-bold text-slate-500 mr-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Filter:
          </span>
          {[
            { id: 'ALL', label: 'All Departments (8)' },
            { id: 'CRITICAL', label: 'Critical Bottlenecks', count: criticalDeptsCount },
            { id: 'WARNING', label: 'Elevated Load', count: warningDeptsCount },
            { id: 'OPTIMAL', label: 'Optimal Flow' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSeverityFilter(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                severityFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span className="px-1.5 py-0.2 bg-rose-500 text-white rounded-full text-[10px]">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="text-xs text-slate-500 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Real-Time Sensor Telemetry Active</span>
        </div>
      </div>

      {/* Main Grid: Department Cards (Left 7-8 cols) + Detail & Mitigation Command (Right 4-5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Department Patient Load Cards (7 cols) */}
        <div className="lg:col-span-7 space-y-3.5">
          {filteredDepts.map((dept) => {
            const isSelected = selectedDepartment.id === dept.id;
            return (
              <div
                key={dept.id}
                id={`dept-card-${dept.id}`}
                onClick={() => setSelectedDeptId(dept.id)}
                className={`p-5 rounded-3xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-white border-2 border-indigo-600 shadow-md ring-2 ring-indigo-100'
                    : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
                }`}
              >
                {/* Department Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                        {dept.name}
                      </h3>
                      <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded font-bold">
                        {dept.code}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Head: <span className="font-medium text-slate-700">{dept.headOfDepartment}</span>
                    </p>
                  </div>

                  <div>
                    {getSeverityBadge(dept.bottleneckSeverity)}
                  </div>
                </div>

                {/* Utilization Progress Bar */}
                <div className="mt-3.5 space-y-1">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-600">Patient Load & Census</span>
                    <span className="font-mono text-slate-900">
                      {dept.currentPatientLoad} / {dept.capacityLimit} ({dept.utilizationRate}%)
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        dept.utilizationRate >= 90
                          ? 'bg-rose-500'
                          : dept.utilizationRate >= 80
                          ? 'bg-amber-500'
                          : 'bg-teal-500'
                      }`}
                      style={{ width: `${Math.min(100, dept.utilizationRate)}%` }}
                    />
                  </div>
                </div>

                {/* Bottleneck Telemetry Grid (Wait times, Lab delays, Staff ratio) */}
                <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-100 text-xs">
                  
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 flex items-center gap-1 font-semibold">
                      <Clock className="w-3 h-3 text-slate-400" /> Wait Duration
                    </span>
                    <p className={`font-bold mt-0.5 ${dept.averageWaitTimeMinutes > 40 ? 'text-rose-600' : 'text-slate-800'}`}>
                      {dept.averageWaitTimeMinutes} mins
                    </p>
                    <span className="text-[10px] text-slate-400">Peak: {dept.longestWaitTimeMinutes}m</span>
                  </div>

                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 flex items-center gap-1 font-semibold">
                      <FlaskConical className="w-3 h-3 text-slate-400" /> Pending Labs
                    </span>
                    <p className={`font-bold mt-0.5 ${dept.statLabTestsPending > 2 ? 'text-rose-600' : 'text-slate-800'}`}>
                      {dept.pendingLabTestsCount} Tests
                    </p>
                    <span className="text-[10px] text-slate-400 font-semibold">{dept.statLabTestsPending} STAT</span>
                  </div>

                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                    <span className="text-[10px] text-slate-500 flex items-center gap-1 font-semibold">
                      <Users className="w-3 h-3 text-slate-400" /> Staff Ratio
                    </span>
                    <p className="font-bold text-slate-800 mt-0.5">
                      1:{dept.patientToStaffRatio}
                    </p>
                    <span className="text-[10px] text-slate-400">{dept.staffOnDutyCount} on duty</span>
                  </div>

                </div>

                {/* Primary Bottleneck Diagnostic Notice */}
                {dept.bottleneckSeverity !== 'OPTIMAL' && (
                  <div className="mt-3 p-2.5 bg-amber-50/80 border border-amber-200/80 rounded-xl text-xs flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-amber-950">Bottleneck Factor:</span>
                      <p className="text-amber-900 mt-0.5">{dept.primaryBottleneckCause}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Right: Department Deep-Dive & Actionable Mitigation Hub (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5">
            
            <div className="border-b border-slate-200 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                Department Mitigation Hub
              </span>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                {selectedDepartment.name}
              </h2>
              <p className="text-xs text-slate-500">
                Active Bottleneck Diagnosis & One-Click Protocol Triggers
              </p>
            </div>

            {/* Department Real-Time Bottleneck Metrics List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Live Capacity & Latency Analysis
              </h4>

              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="font-medium text-slate-700">Waiting Room & Triage Queue</span>
                  <span className="font-bold font-mono text-slate-900">
                    {selectedDepartment.activeTriageQueueCount || 4} Patients Waiting
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="font-medium text-slate-700">Average Lab Turnaround Time</span>
                  <span className={`font-bold font-mono ${selectedDepartment.averageLabTurnaroundMinutes > 45 ? 'text-rose-600' : 'text-slate-900'}`}>
                    {selectedDepartment.averageLabTurnaroundMinutes} minutes
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="font-medium text-slate-700">Pending STAT Priority Lab Orders</span>
                  <span className={`font-bold font-mono ${selectedDepartment.statLabTestsPending > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                    {selectedDepartment.statLabTestsPending} STAT
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="font-medium text-slate-700">Clinical Flow Trend</span>
                  <span className="font-bold text-teal-700 flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    {selectedDepartment.trend}
                  </span>
                </div>
              </div>
            </div>

            {/* Recommended Bottleneck Mitigation Actions */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
                <span>Immediate Mitigation Actions</span>
                <span className="text-[10px] text-indigo-600 font-bold">1-Click Surge Trigger</span>
              </h4>

              <div className="space-y-2">
                {selectedDepartment.recommendedMitigationActions.map((action, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-indigo-50/60 border border-indigo-200/80 rounded-2xl text-xs space-y-2"
                  >
                    <p className="font-semibold text-indigo-950 leading-relaxed">
                      {action}
                    </p>
                    <button
                      type="button"
                      onClick={() => handleApplyMitigation(selectedDepartment.name, action)}
                      className="w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-300" />
                      <span>Execute Mitigation Protocol</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Mitigation Audit Log */}
            {mitigationLog.length > 0 && (
              <div className="space-y-2 pt-3 border-t border-slate-200">
                <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Executed Surge Interventions ({mitigationLog.length})
                </h4>
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {mitigationLog.map(m => (
                    <div key={m.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-700 flex items-start justify-between gap-2">
                      <div>
                        <span className="font-bold text-slate-900 block">{m.department}</span>
                        <span>{m.action}</span>
                      </div>
                      <span className="font-mono text-[10px] text-slate-400 shrink-0">{m.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
};
