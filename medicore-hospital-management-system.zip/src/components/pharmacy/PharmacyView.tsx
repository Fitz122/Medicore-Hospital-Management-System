import React, { useState } from 'react';
import { 
  Pill, 
  Scan, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ShieldCheck, 
  Search, 
  Filter, 
  User, 
  FileText, 
  DollarSign,
  ArrowRight,
  Sparkles,
  Camera,
  Check,
  PackageCheck,
  Building2,
  Calendar,
  Printer
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { PharmacyPrescription, PrescriptionMedItem } from '../../types';
import { BarcodeScannerModal } from '../scanner/BarcodeScannerModal';
import { printPharmacyPrescription } from '../../utils/printEngine';

export const PharmacyView: React.FC = () => {
  const { 
    pharmacyPrescriptions, 
    verifyPrescriptionItemBarcode, 
    dispensePrescription,
    selectedPatient
  } = useHospital();
  const { currentUser } = useAuth();

  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedRx, setSelectedRx] = useState<PharmacyPrescription | null>(pharmacyPrescriptions[0] || null);

  // Barcode scanning state for individual medication item
  const [isScannerModalOpen, setIsScannerModalOpen] = useState<boolean>(false);
  const [activeScanningItem, setActiveScanningItem] = useState<{ rxId: string; medIndex: number; patientMrn: string; expectedBarcode: string } | null>(null);

  const filteredPrescriptions = pharmacyPrescriptions.filter(rx => {
    const matchesStatus = filterStatus === 'ALL' || rx.status === filterStatus;
    const matchesSearch = 
      rx.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rx.patientMrn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rx.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rx.id.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleStartBarcodeScan = (rx: PharmacyPrescription, medIndex: number, item: PrescriptionMedItem) => {
    setActiveScanningItem({
      rxId: rx.id,
      medIndex,
      patientMrn: rx.patientMrn,
      expectedBarcode: item.barcode || ''
    });
    setIsScannerModalOpen(true);
  };

  const handleQuickVerifyBarcode = (rxId: string, medIndex: number, scannedBarcode: string) => {
    verifyPrescriptionItemBarcode(rxId, medIndex, scannedBarcode);
    const updated = pharmacyPrescriptions.find(p => p.id === rxId);
    if (updated) setSelectedRx(updated);
  };

  const handleDispenseRx = (rxId: string) => {
    dispensePrescription(rxId);
    const updated = pharmacyPrescriptions.find(p => p.id === rxId);
    if (updated) setSelectedRx(updated);
  };

  const pendingCount = pharmacyPrescriptions.filter(p => p.status === 'PENDING_VERIFICATION' || p.status === 'PREPARED').length;
  const dispensedCount = pharmacyPrescriptions.filter(p => p.status === 'DISPENSED').length;

  return (
    <div id="pharmacy-view-container" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-xl border border-emerald-200">
            <Pill className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              Central Hospital Pharmacy & Dispensing
              <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full border border-emerald-200">
                Specialist E-Prescription Queue
              </span>
            </h1>
            <p className="text-xs text-slate-500">
              Receive verified specialist electronic prescriptions, perform optical barcode checks, dispense medications, and route charges to the cashier.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setActiveScanningItem(null);
              setIsScannerModalOpen(true);
            }}
            className="px-4 py-2.5 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold shadow transition-all flex items-center gap-2"
          >
            <Camera className="w-4 h-4 text-emerald-400" />
            Camera Barcode Scanner
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Total Prescriptions</p>
            <p className="text-2xl font-black text-slate-900 mt-1">{pharmacyPrescriptions.length}</p>
          </div>
          <div className="p-2.5 bg-slate-100 text-slate-700 rounded-xl">
            <FileText className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Awaiting Barcode Verification</p>
            <p className="text-2xl font-black text-amber-600 mt-1">{pendingCount}</p>
          </div>
          <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Dispensed & Routed to Cashier</p>
            <p className="text-2xl font-black text-emerald-600 mt-1">{dispensedCount}</p>
          </div>
          <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Pharmacy Formulary Value</p>
            <p className="text-2xl font-black text-blue-600 mt-1">
              ${pharmacyPrescriptions.reduce((acc, rx) => acc + (rx.totalPrice || 0), 0).toFixed(2)}
            </p>
          </div>
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Prescription Queue List (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-3">
            
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search prescriptions, patient MRN, doctor..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              {['ALL', 'PENDING_VERIFICATION', 'PREPARED', 'DISPENSED'].map(st => (
                <button
                  key={st}
                  onClick={() => setFilterStatus(st)}
                  className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
                    filterStatus === st
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st.replace(/_/g, ' ')}
                </button>
              ))}
            </div>

            {/* Prescription List */}
            <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto space-y-1">
              {filteredPrescriptions.map(rx => {
                const isSelected = selectedRx?.id === rx.id;
                const allVerified = rx.items.every(item => item.barcodeVerified);
                return (
                  <div
                    key={rx.id}
                    id={`rx-card-${rx.id}`}
                    onClick={() => setSelectedRx(rx)}
                    className={`p-3.5 rounded-xl cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-emerald-50/90 border-2 border-emerald-500 shadow-sm'
                        : 'bg-white hover:bg-slate-50 border border-slate-100'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{rx.patientName}</span>
                          <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                            {rx.patientMrn}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Prescribed by: <span className="font-medium text-slate-700">{rx.doctorName}</span>
                        </p>
                      </div>

                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        rx.status === 'DISPENSED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : rx.status === 'PREPARED'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {rx.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <Pill className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{rx.items.length} items (${rx.totalPrice?.toFixed(2) || '0.00'})</span>
                      </div>

                      <div className="flex items-center gap-1">
                        {allVerified ? (
                          <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-0.5 bg-emerald-100 px-1.5 py-0.5 rounded">
                            <Check className="w-3 h-3" /> Barcodes Verified
                          </span>
                        ) : (
                          <span className="text-[10px] text-amber-700 font-semibold flex items-center gap-0.5 bg-amber-100 px-1.5 py-0.5 rounded">
                            <Scan className="w-3 h-3" /> Needs Scan
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              {filteredPrescriptions.length === 0 && (
                <div className="py-8 text-center text-xs text-slate-400">
                  No prescriptions match the filter.
                </div>
              )}
            </div>

          </div>
        </div>

        {/* Selected Prescription Verification & Dispensing Panel (7 cols) */}
        <div className="lg:col-span-7">
          {selectedRx ? (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-6">
              
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-900">
                      Prescription #{selectedRx.id}
                    </h2>
                    <span className="text-[10px] font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      {selectedRx.patientMrn}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Patient: <span className="font-bold text-slate-800">{selectedRx.patientName}</span> • Prescribed: {selectedRx.dateIssued} at {selectedRx.timeIssued}
                  </p>
                </div>

                {/* Status or Dispense Trigger */}
                <div className="flex items-center gap-2">
                  <button
                    id="btn-print-rx-label"
                    onClick={() => printPharmacyPrescription(selectedRx, undefined, currentUser)}
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold shadow-xs transition-all flex items-center gap-1.5"
                    title="Print E-Prescription and BCMA Barcode Administration Sheet"
                  >
                    <Printer className="w-4 h-4 text-emerald-400" />
                    <span>Print Rx & BCMA</span>
                  </button>

                  {selectedRx.status === 'DISPENSED' ? (
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl">
                      <PackageCheck className="w-4 h-4 text-emerald-600" />
                      Dispensed (Dispatched to Cashier)
                    </div>
                  ) : (
                    <button
                      id="btn-dispense-rx-now"
                      onClick={() => handleDispenseRx(selectedRx.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2"
                    >
                      <PackageCheck className="w-4 h-4" />
                      Complete Dispensing & Forward to Cashier
                    </button>
                  )}
                </div>
              </div>

              {/* Specialist Clinical Consultation Context */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
                <p className="font-bold text-slate-700 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-emerald-600" />
                  Prescribed by Specialist: {selectedRx.doctorName}
                </p>
                {selectedRx.notes && (
                  <p className="text-slate-600 italic">"{selectedRx.notes}"</p>
                )}
                {selectedRx.diagnosisReportSummary && (
                  <div className="mt-2 pt-2 border-t border-slate-200 text-[11px] text-slate-600">
                    <span className="font-semibold text-slate-800">Linked Specialist Diagnosis:</span> {selectedRx.diagnosisReportSummary}
                  </div>
                )}
              </div>

              {/* Prescription Items Table with Optical Barcode Verification */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Prescribed Medications ({selectedRx.items.length}) & Barcode Verification
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">
                    Scan packaging before release
                  </span>
                </div>

                <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100">
                  {selectedRx.items.map((item, idx) => (
                    <div key={item.id || item.medicationId || `${item.barcode}-${idx}`} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white hover:bg-slate-50/70 transition-colors">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-900">{item.name}</h4>
                          <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded font-mono font-medium">
                            {item.dosage} • {item.route}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {item.frequency} • Duration: {item.duration} • Qty: {item.quantity} units
                        </p>
                        <div className="flex items-center gap-2 text-[10px] font-mono text-slate-600">
                          <span>NDC Barcode: <span className="text-emerald-700 font-bold">{item.barcode}</span></span>
                          {item.lotNumber && <span>• Lot #{item.lotNumber}</span>}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-start sm:self-auto">
                        {item.barcodeVerified ? (
                          <span className="text-xs font-bold text-emerald-700 bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-xl flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            Verified
                          </span>
                        ) : (
                          <div className="flex items-center gap-1.5">
                            <button
                              id={`btn-verify-camera-item-${idx}`}
                              onClick={() => handleStartBarcodeScan(selectedRx, idx, item)}
                              className="px-3 py-1.5 bg-slate-900 hover:bg-black text-white text-xs font-semibold rounded-lg flex items-center gap-1 shadow-sm"
                            >
                              <Camera className="w-3.5 h-3.5 text-emerald-400" />
                              Scan Camera
                            </button>
                            <button
                              id={`btn-quick-verify-item-${idx}`}
                              onClick={() => handleQuickVerifyBarcode(selectedRx.id, idx, item.barcode || '')}
                              className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-semibold rounded-lg"
                              title="Simulate barcode optical match"
                            >
                              Match
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dispensing Pharmacist Signature & Total */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <p className="font-bold text-slate-800">
                    Pharmacist on Duty: {selectedRx.pharmacistName || currentUser.name}
                  </p>
                  <p className="text-slate-500 text-[11px]">
                    Automatic billing dispatch on dispense: Itemized pharmacy bill added to patient ledger.
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 text-[11px]">Prescription Total:</span>
                  <p className="text-base font-black text-slate-900">
                    ${selectedRx.totalPrice?.toFixed(2) || '0.00'}
                  </p>
                </div>
              </div>

              {/* Action Banner */}
              {selectedRx.status !== 'DISPENSED' && (
                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <span className="text-xs text-slate-500">
                    Next step in care journey: Patient proceeds to Cashier for final same-day outpatient settlement.
                  </span>
                  <button
                    onClick={() => handleDispenseRx(selectedRx.id)}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md flex items-center gap-2"
                  >
                    <PackageCheck className="w-4 h-4" />
                    Dispense & Hand Over
                  </button>
                </div>
              )}

            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center text-slate-400">
              <Pill className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-sm font-medium text-slate-600">Select a prescription from the queue to review and dispense</p>
            </div>
          )}
        </div>

      </div>

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerModalOpen}
        onClose={() => setIsScannerModalOpen(false)}
        targetPatientId={selectedRx?.patientId}
        onScanComplete={(result) => {
          if (activeScanningItem && result.success) {
            handleQuickVerifyBarcode(activeScanningItem.rxId, activeScanningItem.medIndex, activeScanningItem.expectedBarcode);
          }
        }}
      />
    </div>
  );
};
