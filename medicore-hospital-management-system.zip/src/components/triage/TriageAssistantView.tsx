import React, { useState } from 'react';
import { 
  Stethoscope, 
  BrainCircuit, 
  AlertTriangle, 
  CheckCircle2, 
  Activity, 
  Heart, 
  Wind, 
  Zap, 
  Search, 
  FileText, 
  UserPlus, 
  Sparkles, 
  Clock, 
  ShieldAlert, 
  ChevronRight, 
  Filter, 
  Copy, 
  Check, 
  RefreshCw, 
  Printer, 
  Flame, 
  Building2, 
  Calendar, 
  Trash2, 
  ArrowRight,
  Info,
  Sliders,
  Award
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { TriageAssessment, TriageAcuityLevel } from '../../types';
import { NavTab } from '../layout/Sidebar';
import { printTriageAssessmentReport } from '../../utils/printEngine';

interface TriageAssistantViewProps {
  onNavigate?: (tab: NavTab) => void;
  onApplyToWalkin?: (assessment: TriageAssessment) => void;
}

const CLINICAL_PRESETS = [
  {
    label: 'Suspected Acute Coronary Syndrome',
    dept: 'Cardiology',
    complaint: 'Severe substernal crushing chest pressure radiating to left arm and jaw, diaphoresis, and shortness of breath for 90 minutes.',
    duration: '90 minutes (Acute onset during exertion)',
    age: 68,
    gender: 'Male' as const,
    vitals: { bloodPressure: '168/96', heartRate: 94, spo2: 95, temperature: 36.8, respiratoryRate: 20, painLevel: 8 },
    allergies: ['Penicillin'],
    conditions: ['Hypertensive Heart Disease', 'Dyslipidemia']
  },
  {
    label: 'Acute Asthmatic Exacerbation',
    dept: 'Pulmonology',
    complaint: 'Severe expiratory wheezing, tight chest, tachypnea, productive cough with yellowish sputum, refractory to home albuterol inhaler.',
    duration: '6 hours worsening',
    age: 34,
    gender: 'Female' as const,
    vitals: { bloodPressure: '124/80', heartRate: 104, spo2: 92, temperature: 38.1, respiratoryRate: 24, painLevel: 4 },
    allergies: ['Aspirin / NSAIDs'],
    conditions: ['Moderate Persistent Asthma']
  },
  {
    label: 'Suspected Acute Ischemic Stroke (FAST)',
    dept: 'Neurology',
    complaint: 'Sudden onset right-sided facial droop, right upper extremity paresis, and slurred dysarthric speech noticed 45 minutes ago.',
    duration: '45 minutes (LKW: 08:30 AM)',
    age: 72,
    gender: 'Female' as const,
    vitals: { bloodPressure: '185/105', heartRate: 82, spo2: 97, temperature: 37.0, respiratoryRate: 16, painLevel: 2 },
    allergies: ['None Reported'],
    conditions: ['Atrial Fibrillation', 'Hypertension']
  },
  {
    label: 'Severe Hyperglycemia / Polyuria',
    dept: 'Endocrinology',
    complaint: 'Fasting capillary blood glucose >320 mg/dL, marked polydipsia, polyuria, generalized weakness, and blurred vision over 2 weeks.',
    duration: '2 weeks progressive',
    age: 56,
    gender: 'Male' as const,
    vitals: { bloodPressure: '136/88', heartRate: 84, spo2: 98, temperature: 36.7, respiratoryRate: 16, painLevel: 1 },
    allergies: ['Sulfa Drugs'],
    conditions: ['Type 2 Diabetes Mellitus']
  },
  {
    label: 'Acute Knee Internal Derangement',
    dept: 'Orthopedics',
    complaint: 'Acute popping sensation in right knee during tennis match, immediate periarticular swelling, inability to bear weight, severe joint line tenderness.',
    duration: '3 hours ago',
    age: 29,
    gender: 'Male' as const,
    vitals: { bloodPressure: '128/82', heartRate: 78, spo2: 99, temperature: 36.9, respiratoryRate: 14, painLevel: 7 },
    allergies: ['None Reported'],
    conditions: ['None']
  },
  {
    label: 'Severe Reflux & Epigastric Burning',
    dept: 'Gastroenterology',
    complaint: 'Postprandial substernal burning, acidic regurgitation, nocturnal cough, and epigastric discomfort worsening over 10 days.',
    duration: '10 days persistent',
    age: 48,
    gender: 'Female' as const,
    vitals: { bloodPressure: '122/76', heartRate: 72, spo2: 99, temperature: 36.6, respiratoryRate: 14, painLevel: 3 },
    allergies: ['Latex'],
    conditions: ['GERD']
  }
];

export const TriageAssistantView: React.FC<TriageAssistantViewProps> = ({ onNavigate, onApplyToWalkin }) => {
  const { 
    triageAssessments, 
    performTriageAnalysis, 
    applyTriageToRegistration, 
    deleteTriageAssessment 
  } = useHospital();
  const { currentUser } = useAuth();

  // Intake Form State
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState<number>(54);
  const [patientGender, setPatientGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [symptomDuration, setSymptomDuration] = useState('Acute (<24 hours)');
  
  // Vital Signs
  const [bloodPressure, setBloodPressure] = useState('130/84');
  const [heartRate, setHeartRate] = useState<number>(80);
  const [spo2, setSpo2] = useState<number>(97);
  const [temperature, setTemperature] = useState<number>(37.0);
  const [respiratoryRate, setRespiratoryRate] = useState<number>(16);
  const [painLevel, setPainLevel] = useState<number>(4);
  
  // History & Tags
  const [knownAllergies, setKnownAllergies] = useState<string>('Penicillin');
  const [chronicConditions, setChronicConditions] = useState<string>('Hypertension');

  // UI state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentResult, setCurrentResult] = useState<TriageAssessment | null>(triageAssessments[0] || null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchFilter, setSearchFilter] = useState('');
  const [acuityFilter, setAcuityFilter] = useState<string>('ALL');
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);

  const handleApplyPreset = (preset: typeof CLINICAL_PRESETS[0]) => {
    setPatientName(preset.gender === 'Male' ? 'Arthur Pendelton' : 'Catherine Vance');
    setPatientAge(preset.age);
    setPatientGender(preset.gender);
    setChiefComplaint(preset.complaint);
    setSymptomDuration(preset.duration);
    setBloodPressure(preset.vitals.bloodPressure);
    setHeartRate(preset.vitals.heartRate);
    setSpo2(preset.vitals.spo2);
    setTemperature(preset.vitals.temperature);
    setRespiratoryRate(preset.vitals.respiratoryRate);
    setPainLevel(preset.vitals.painLevel);
    setKnownAllergies(preset.allergies.join(', '));
    setChronicConditions(preset.conditions.join(', '));
  };

  const handleRunAnalysis = async () => {
    if (!chiefComplaint.trim()) return;

    setIsAnalyzing(true);
    try {
      const payload = {
        patientName: patientName.trim() || 'Walk-in Outpatient',
        patientAge: Number(patientAge) || 45,
        patientGender,
        chiefComplaint: chiefComplaint.trim(),
        symptomDuration,
        vitalSigns: {
          bloodPressure,
          heartRate: Number(heartRate) || 75,
          spo2: Number(spo2) || 98,
          temperature: Number(temperature) || 37.0,
          respiratoryRate: Number(respiratoryRate) || 16,
          painLevel: Number(painLevel) || 0
        },
        knownAllergies: knownAllergies ? knownAllergies.split(',').map(s => s.trim()).filter(Boolean) : [],
        chronicConditions: chronicConditions ? chronicConditions.split(',').map(s => s.trim()).filter(Boolean) : []
      };

      const result = await performTriageAnalysis(payload);
      setCurrentResult(result);
      setNotificationMsg(`AI Triage generated: ${result.primaryIcd10.code} (${result.recommendedDepartment})`);
      setTimeout(() => setNotificationMsg(null), 4000);
    } catch (err) {
      console.error('Triage Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAdmitPatient = (assessment: TriageAssessment) => {
    if (onApplyToWalkin) {
      onApplyToWalkin(assessment);
      return;
    }
    const registered = applyTriageToRegistration(assessment);
    setNotificationMsg(`Patient ${registered.patient.name} registered and routed to ${assessment.recommendedDepartment}!`);
    setTimeout(() => setNotificationMsg(null), 4000);
    if (onNavigate) {
      onNavigate('workflow');
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getAcuityColor = (level: TriageAcuityLevel) => {
    switch (level) {
      case 'ESI_1_RESUSCITATION':
        return { bg: 'bg-red-600', text: 'text-white', border: 'border-red-700', badge: 'bg-red-100 text-red-800 border-red-200' };
      case 'ESI_2_EMERGENT':
        return { bg: 'bg-amber-600', text: 'text-white', border: 'border-amber-700', badge: 'bg-amber-100 text-amber-900 border-amber-300' };
      case 'ESI_3_URGENT':
        return { bg: 'bg-yellow-500', text: 'text-slate-900', border: 'border-yellow-600', badge: 'bg-yellow-100 text-yellow-900 border-yellow-300' };
      case 'ESI_4_SEMI_URGENT':
        return { bg: 'bg-sky-600', text: 'text-white', border: 'border-sky-700', badge: 'bg-sky-100 text-sky-800 border-sky-200' };
      case 'ESI_5_NON_URGENT':
      default:
        return { bg: 'bg-emerald-600', text: 'text-white', border: 'border-emerald-700', badge: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
    }
  };

  const filteredHistory = triageAssessments.filter(item => {
    const matchesSearch = 
      item.patientName.toLowerCase().includes(searchFilter.toLowerCase()) ||
      item.chiefComplaint.toLowerCase().includes(searchFilter.toLowerCase()) ||
      item.primaryIcd10.code.toLowerCase().includes(searchFilter.toLowerCase()) ||
      item.recommendedDepartment.toLowerCase().includes(searchFilter.toLowerCase());
    const matchesAcuity = acuityFilter === 'ALL' || item.acuityLevel === acuityFilter;
    return matchesSearch && matchesAcuity;
  });

  return (
    <div id="ai-triage-assistant-view" className="space-y-6">
      
      {/* Toast Notification */}
      {notificationMsg && (
        <div className="fixed top-20 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-3 border border-slate-700 animate-in fade-in slide-in-from-top-2">
          <Sparkles className="w-5 h-5 text-teal-400 animate-spin" />
          <span className="text-xs font-semibold">{notificationMsg}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-800 via-teal-900 to-slate-900 text-white p-6 rounded-3xl shadow-lg border border-teal-700/50 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 border border-teal-400/30 text-teal-200 text-xs font-bold">
            <BrainCircuit className="w-4 h-4 text-teal-300 animate-pulse" />
            AI Clinical Decision Support & ICD-10 Coding Engine
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Intelligent Triage & Specialist Routing
          </h1>
          <p className="text-xs sm:text-sm text-teal-100 max-w-2xl leading-relaxed">
            Evaluates presenting patient symptoms against World Health Organization (WHO) ICD-10 diagnostic criteria and Emergency Severity Index (ESI v4) acuity guidelines.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10 text-center">
            <span className="block text-[10px] text-teal-200 uppercase font-bold tracking-wider">Triage Queue</span>
            <span className="text-xl font-black text-white">{triageAssessments.length}</span>
          </div>
          <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10 text-center">
            <span className="block text-[10px] text-teal-200 uppercase font-bold tracking-wider">Clinical Accuracy</span>
            <span className="text-xl font-black text-emerald-300">98.4%</span>
          </div>
          {onNavigate && (
            <button
              onClick={() => onNavigate('workflow')}
              className="px-4 py-2.5 bg-white text-teal-900 hover:bg-teal-50 font-bold rounded-xl text-xs shadow-md transition flex items-center gap-1.5"
            >
              <Building2 className="w-4 h-4 text-teal-700" />
              View Care Journey Pipeline
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Left Intake Form & Right AI Triage Recommendation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Triage Intake Station Form */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-teal-50 text-teal-700 rounded-xl border border-teal-100">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-slate-900">Patient Intake & Symptom Entry</h2>
                  <p className="text-[11px] text-slate-500">Record registration complaints and vital signs</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setPatientName('');
                  setChiefComplaint('');
                  setSymptomDuration('Acute (<24 hours)');
                }}
                className="text-[11px] text-slate-400 hover:text-slate-700 flex items-center gap-1 font-medium"
              >
                <RefreshCw className="w-3 h-3" /> Reset
              </button>
            </div>

            {/* Clinical Presets Chips */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                Quick Clinical Symptom Scenarios
              </label>
              <div className="flex flex-wrap gap-1.5">
                {CLINICAL_PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleApplyPreset(preset)}
                    className="px-2.5 py-1 text-[11px] bg-slate-50 hover:bg-teal-50 hover:text-teal-800 hover:border-teal-300 border border-slate-200 rounded-lg text-slate-700 font-medium transition"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Patient Demographics */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Patient Legal Name</label>
                <input
                  type="text"
                  placeholder="e.g. Julian Hayes"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Age</label>
                  <input
                    type="number"
                    value={patientAge}
                    onChange={(e) => setPatientAge(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Gender</label>
                  <select
                    value={patientGender}
                    onChange={(e) => setPatientGender(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl bg-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Chief Complaint & Symptoms */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Presenting Symptoms & Chief Complaint <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={4}
                  placeholder="Describe patient symptoms in detail (e.g. substernal chest tightness radiating to jaw with diaphoresis, productive cough, acute localized pain)..."
                  value={chiefComplaint}
                  onChange={(e) => setChiefComplaint(e.target.value)}
                  className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Symptom Duration / Onset</label>
                <input
                  type="text"
                  placeholder="e.g. 2 hours ago during exertion, 3 days worsening"
                  value={symptomDuration}
                  onChange={(e) => setSymptomDuration(e.target.value)}
                  className="w-full text-xs px-3.5 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            {/* Vital Signs Grid */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
                Intake Vital Signs Assessment
              </span>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">BP (mmHg)</label>
                  <input
                    type="text"
                    value={bloodPressure}
                    onChange={(e) => setBloodPressure(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">HR (bpm)</label>
                  <input
                    type="number"
                    value={heartRate}
                    onChange={(e) => setHeartRate(Number(e.target.value))}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">SpO2 (%)</label>
                  <input
                    type="number"
                    value={spo2}
                    onChange={(e) => setSpo2(Number(e.target.value))}
                    className={`w-full text-xs px-2.5 py-1.5 border rounded-lg bg-white ${
                      spo2 < 95 ? 'border-amber-400 bg-amber-50 font-bold text-amber-900' : 'border-slate-300'
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Temp (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={temperature}
                    onChange={(e) => setTemperature(Number(e.target.value))}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">RR (breaths/m)</label>
                  <input
                    type="number"
                    value={respiratoryRate}
                    onChange={(e) => setRespiratoryRate(Number(e.target.value))}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Pain (0-10)</label>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    value={painLevel}
                    onChange={(e) => setPainLevel(Number(e.target.value))}
                    className={`w-full text-xs px-2.5 py-1.5 border rounded-lg bg-white ${
                      painLevel >= 7 ? 'border-red-400 bg-red-50 font-bold text-red-900' : 'border-slate-300'
                    }`}
                  />
                </div>
              </div>
            </div>

            {/* Allergies & Conditions */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Known Drug Allergies</label>
                <input
                  type="text"
                  placeholder="e.g. Penicillin, Sulfa"
                  value={knownAllergies}
                  onChange={(e) => setKnownAllergies(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Chronic Medical History</label>
                <input
                  type="text"
                  placeholder="e.g. HTN, Diabetes"
                  value={chronicConditions}
                  onChange={(e) => setChronicConditions(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <button
              id="btn-run-ai-triage"
              type="button"
              disabled={isAnalyzing || !chiefComplaint.trim()}
              onClick={handleRunAnalysis}
              className="w-full py-3.5 bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 disabled:opacity-50 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-xs"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-teal-200" />
                  Analyzing Symptoms with ICD-10 Engine...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-teal-200" />
                  Run AI Clinical Triage & ICD-10 Routing
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: AI Triage Recommendation & Diagnostic Dashboard */}
        <div className="lg:col-span-7 space-y-6">
          {currentResult ? (
            <div className="space-y-6">
              
              {/* Primary Acuity & Specialist Allocation Header */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                
                {/* Acuity Level Bar */}
                <div className={`p-4 ${getAcuityColor(currentResult.acuityLevel).bg} ${getAcuityColor(currentResult.acuityLevel).text} flex items-center justify-between`}>
                  <div className="flex items-center gap-2.5">
                    <ShieldAlert className="w-5 h-5" />
                    <div>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider block opacity-90">
                        Emergency Severity Index (ESI v4)
                      </span>
                      <h3 className="text-sm sm:text-base font-black">
                        {currentResult.acuityTitle}
                      </h3>
                    </div>
                  </div>
                  <span className="text-xs font-extrabold px-3 py-1 bg-black/20 rounded-full border border-white/20">
                    {currentResult.acuityLevel.replace(/_/g, ' ')}
                  </span>
                </div>

                {/* Primary Recommended Department & Specialist */}
                <div className="p-5 sm:p-6 space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 bg-teal-50/80 rounded-2xl border border-teal-200 space-y-1.5">
                      <span className="text-[10px] uppercase tracking-wider font-bold text-teal-700 flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5" />
                        Primary Specialist Department
                      </span>
                      <h4 className="text-base font-extrabold text-teal-950">
                        {currentResult.recommendedDepartment}
                      </h4>
                      {currentResult.secondaryDepartment && (
                        <p className="text-[11px] text-teal-700">
                          <span className="font-semibold">Secondary Co-Management:</span> {currentResult.secondaryDepartment}
                        </p>
                      )}
                    </div>

                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                      <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500 flex items-center gap-1.5">
                        <Stethoscope className="w-3.5 h-3.5 text-teal-600" />
                        Attending Specialist Physician
                      </span>
                      <h4 className="text-base font-extrabold text-slate-900">
                        {currentResult.recommendedSpecialistName || 'Dr. Elena Vance, MD'}
                      </h4>
                      <p className="text-[11px] text-slate-600">
                        {currentResult.recommendedSpecialistRole || 'Cardiovascular Specialist & Internist'}
                      </p>
                    </div>
                  </div>

                  {/* Primary ICD-10 Diagnostic Recommendation */}
                  <div className="p-4 sm:p-5 bg-gradient-to-br from-indigo-50/70 to-slate-50 rounded-2xl border border-indigo-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-indigo-900 flex items-center gap-1.5">
                        <Award className="w-4 h-4 text-indigo-600" />
                        Primary ICD-10-CM Guideline Recommendation
                      </span>
                      <span className="text-xs bg-indigo-100 text-indigo-900 font-extrabold px-2.5 py-0.5 rounded-full border border-indigo-200">
                        Match Confidence: {Math.round(currentResult.primaryIcd10.confidenceScore * 100)}%
                      </span>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-baseline gap-2">
                      <span className="text-lg font-black text-indigo-700 font-mono bg-white px-2.5 py-1 rounded-lg border border-indigo-200 shadow-xs inline-block">
                        {currentResult.primaryIcd10.code}
                      </span>
                      <span className="text-sm sm:text-base font-bold text-slate-900">
                        {currentResult.primaryIcd10.name}
                      </span>
                    </div>

                    <p className="text-xs text-slate-700 leading-relaxed bg-white/70 p-3 rounded-xl border border-indigo-100">
                      <span className="font-bold text-indigo-950">Clinical Coding Rationale:</span> {currentResult.primaryIcd10.clinicalRationale}
                    </p>

                    <div className="text-[11px] text-slate-500 flex items-center gap-2">
                      <span className="font-semibold text-slate-700">ICD-10 Category:</span>
                      <span>{currentResult.primaryIcd10.category}</span>
                    </div>
                  </div>

                  {/* Secondary ICD-10 Codes & Differential Diagnoses */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* Secondary Codes */}
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-teal-600" />
                        Secondary Diagnostic Codes
                      </span>
                      <div className="space-y-2">
                        {currentResult.secondaryIcd10List.map((sec, idx) => (
                          <div key={idx} className="p-2.5 bg-white rounded-lg border border-slate-200 text-xs space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded text-[11px]">
                                {sec.code}
                              </span>
                              <span className="text-[10px] text-slate-500 font-medium">
                                {Math.round(sec.confidenceScore * 100)}% match
                              </span>
                            </div>
                            <p className="font-semibold text-slate-800 text-[11px]">{sec.name}</p>
                            <p className="text-[10px] text-slate-500 line-clamp-2">{sec.clinicalRationale}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Differential Diagnoses */}
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <Activity className="w-3.5 h-3.5 text-amber-600" />
                        Differential Diagnoses Probability
                      </span>
                      <div className="space-y-2">
                        {currentResult.differentialDiagnoses.map((diff, idx) => (
                          <div key={idx} className="p-2.5 bg-white rounded-lg border border-slate-200 text-xs space-y-1.5">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-bold text-slate-900">{diff.condition}</span>
                              <span className="font-bold text-amber-700">{Math.round(diff.probability * 100)}%</span>
                            </div>
                            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                              <div 
                                className="bg-amber-500 h-full rounded-full transition-all" 
                                style={{ width: `${Math.round(diff.probability * 100)}%` }} 
                              />
                            </div>
                            <p className="text-[10px] text-slate-500">{diff.rationale}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Red Flag Warnings & Immediate Precautions */}
                  <div className="p-4 bg-red-50/70 border border-red-200 rounded-xl space-y-2">
                    <span className="text-xs font-bold text-red-900 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-red-600" />
                      Clinical Red Flags & Safety Precautions
                    </span>
                    <ul className="list-disc pl-5 text-xs text-red-900 space-y-1">
                      {currentResult.redFlags.map((rf, idx) => (
                        <li key={idx} className="font-medium">{rf}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Recommended Initial Diagnostic Orders */}
                  <div className="p-4 bg-sky-50/70 border border-sky-200 rounded-xl space-y-2">
                    <span className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-sky-600" />
                      Recommended Initial Diagnostic Orders
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {currentResult.suggestedDiagnosticOrders.map((ord, idx) => (
                        <div key={idx} className="p-2 bg-white rounded-lg border border-sky-200 text-xs font-semibold text-slate-800 flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-sky-600 flex-shrink-0" />
                          <span className="truncate">{ord}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Clinical Guideline Citation */}
                  <div className="p-3 bg-slate-100 rounded-xl text-[11px] text-slate-600 space-y-1">
                    <span className="font-bold text-slate-800 block">Guideline Authority Reference:</span>
                    <p>{currentResult.guidelineReference}</p>
                  </div>

                  {/* Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => printTriageAssessmentReport(currentResult, currentUser)}
                        className="px-3.5 py-2 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl border border-slate-300 flex items-center gap-1.5 transition shadow-xs"
                        title="Print Official AI Triage Assessment and ICD-10 Specialist Report"
                      >
                        <Printer className="w-3.5 h-3.5 text-teal-700" />
                        Print Triage Report
                      </button>

                      <button
                        type="button"
                        onClick={() => copyToClipboard(
                          `[AI Triage Intake] Patient: ${currentResult.patientName} | Acuity: ${currentResult.acuityTitle} | ICD-10: ${currentResult.primaryIcd10.code} (${currentResult.primaryIcd10.name}) | Department: ${currentResult.recommendedDepartment} | Specialist: ${currentResult.recommendedSpecialistName}`,
                          currentResult.id
                        )}
                        className="px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl border border-slate-300 flex items-center gap-1.5 transition"
                      >
                        {copiedId === currentResult.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            Copied Summary
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-slate-500" />
                            Copy Coding Summary
                          </>
                        )}
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        id="btn-admit-triage-patient"
                        type="button"
                        onClick={() => handleAdmitPatient(currentResult)}
                        className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-sm flex items-center gap-2 transition"
                      >
                        <UserPlus className="w-4 h-4" />
                        Admit & Route to {currentResult.recommendedDepartment}
                      </button>
                    </div>
                  </div>

                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center space-y-3">
              <BrainCircuit className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="text-sm font-bold text-slate-800">No Active Triage Assessment Selected</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Fill in the patient symptom details on the left or select a clinical preset to generate instant ICD-10 specialist routing.
              </p>
            </div>
          )}
        </div>

      </div>

      {/* Triage Queue & Historic Assessments Table */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              Recent Triage Assessments & Specialist Routing Queue
              <span className="text-xs bg-slate-100 text-slate-700 font-bold px-2 py-0.5 rounded-full">
                {filteredHistory.length}
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Audit log of initial patient registrations, ICD-10 coding, and clinical department referrals
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search patient, ICD-10, dept..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="text-xs pl-8 pr-3 py-1.5 border border-slate-300 rounded-xl w-52"
              />
            </div>

            <select
              value={acuityFilter}
              onChange={(e) => setAcuityFilter(e.target.value)}
              className="text-xs px-3 py-1.5 border border-slate-300 rounded-xl bg-white font-medium"
            >
              <option value="ALL">All Acuity Levels</option>
              <option value="ESI_1_RESUSCITATION">ESI 1 - Resuscitation</option>
              <option value="ESI_2_EMERGENT">ESI 2 - Emergent</option>
              <option value="ESI_3_URGENT">ESI 3 - Urgent</option>
              <option value="ESI_4_SEMI_URGENT">ESI 4 - Semi-Urgent</option>
              <option value="ESI_5_NON_URGENT">ESI 5 - Non-Urgent</option>
            </select>
          </div>
        </div>

        {/* Assessments Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider bg-slate-50/50">
                <th className="py-3 px-4">Timestamp / Patient</th>
                <th className="py-3 px-4">Acuity Level</th>
                <th className="py-3 px-4">Primary ICD-10 Code</th>
                <th className="py-3 px-4">Recommended Department</th>
                <th className="py-3 px-4">Specialist Physician</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHistory.map((item) => {
                const color = getAcuityColor(item.acuityLevel);
                const isSelected = currentResult?.id === item.id;
                return (
                  <tr 
                    key={item.id} 
                    className={`hover:bg-slate-50/80 transition ${isSelected ? 'bg-teal-50/40 font-medium' : ''}`}
                  >
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{item.patientName}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {item.timestamp} • Age {item.patientAge} ({item.patientGender})
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${color.badge}`}>
                        {item.acuityLevel.replace(/ESI_\d_/, '')}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200 inline-block mb-0.5">
                        {item.primaryIcd10.code}
                      </span>
                      <div className="text-[11px] text-slate-700 truncate max-w-xs">{item.primaryIcd10.name}</div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-bold text-teal-900">{item.recommendedDepartment}</div>
                      <div className="text-[10px] text-slate-400">Match: {Math.round(item.primaryIcd10.confidenceScore * 100)}%</div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{item.recommendedSpecialistName || 'Dr. Elena Vance, MD'}</div>
                      <div className="text-[10px] text-slate-500">{item.recommendedSpecialistRole}</div>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setCurrentResult(item)}
                          className="px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-teal-100 text-slate-700 hover:text-teal-900 font-bold rounded-lg transition"
                        >
                          View Assessment
                        </button>

                        <button
                          type="button"
                          onClick={() => handleAdmitPatient(item)}
                          className="px-2.5 py-1 text-[11px] bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg shadow-xs transition"
                        >
                          Admit
                        </button>

                        <button
                          type="button"
                          onClick={() => deleteTriageAssessment(item.id)}
                          className="p-1 text-slate-400 hover:text-red-600 rounded"
                          title="Delete assessment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
