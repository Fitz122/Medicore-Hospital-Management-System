import React, { useState } from 'react';
import { 
  UserCheck, 
  Stethoscope, 
  FlaskConical, 
  Printer, 
  Pill, 
  CreditCard, 
  CheckCircle2, 
  ArrowRight, 
  Clock, 
  Sparkles, 
  Play, 
  FileText, 
  Building2, 
  ShieldCheck, 
  Calendar, 
  Plus,
  RefreshCw,
  Search,
  Scan,
  AlertCircle,
  BrainCircuit,
  ShieldAlert,
  Award,
  Zap
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { PatientCareJourney, CareJourneyStage, Patient, TriageAssessment } from '../../types';
import { DiagnosisPhysicalReportModal } from '../reports/DiagnosisPhysicalReportModal';
import { BarcodeScannerModal } from '../scanner/BarcodeScannerModal';

export const OutpatientWorkflowView: React.FC = () => {
  const { 
    patients, 
    careJourneys, 
    labOrders,
    pharmacyPrescriptions,
    invoices,
    registerPatientAndBookSpecialist,
    orderSpecialistLabTests,
    sendLabResultsToSpecialist,
    completeDiagnosisAndPrintReport,
    dispensePrescription,
    clearOutpatientAtCashier,
    availableLabTests,
    performTriageAnalysis
  } = useHospital();
  const { currentUser } = useAuth();

  const [selectedJourneyId, setSelectedJourneyId] = useState<string>(careJourneys[0]?.id || careJourneys[0]?.patientId || '');
  const [activeTab, setActiveTab] = useState<'pipeline' | 'interactive_stepper' | 'new_walkin'>('pipeline');

  // New Walk-in Registration form state
  const [newPatientName, setNewPatientName] = useState('');
  const [newPatientAge, setNewPatientAge] = useState('42');
  const [newPatientGender, setNewPatientGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [newPatientSpecialist, setNewPatientSpecialist] = useState('Dr. Marcus Vance (Cardiologist)');
  const [newPatientSpecialty, setNewPatientSpecialty] = useState('Cardiology');
  const [newPatientReason, setNewPatientReason] = useState('Acute chest tightness and hypertensive episodes');
  const [isTriageAnalyzing, setIsTriageAnalyzing] = useState(false);
  const [triageSuggestion, setTriageSuggestion] = useState<TriageAssessment | null>(null);

  // Interactive step runner form state for current journey
  const [selectedLabTestCodes, setSelectedLabTestCodes] = useState<string[]>(['CBC', 'CMP', 'LIPID']);
  const [diagnosisText, setDiagnosisText] = useState('Stage 2 Essential Hypertension with Hyperlipidemia');
  const [prescribedMedsList, setPrescribedMedsList] = useState<string[]>([
    'Lisinopril 10mg PO Daily (#30)',
    'Atorvastatin 20mg PO QHS (#30)'
  ]);
  const [medInput, setMedInput] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Insurance + Co-pay' | 'Credit Card' | 'Cash'>('Insurance + Co-pay');

  // Modals state
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [activeReportData, setActiveReportData] = useState<any>(null);
  const [isBcmaScannerOpen, setIsBcmaScannerOpen] = useState(false);

  const selectedJourney = careJourneys.find(j => j.id === selectedJourneyId || j.patientId === selectedJourneyId) || careJourneys[0];
  const linkedPatient = patients.find(p => p.id === selectedJourney?.patientId);
  const linkedLabOrder = labOrders.find(l => l.id === selectedJourney?.labOrderId);
  const linkedRx = pharmacyPrescriptions.find(r => r.id === selectedJourney?.pharmacyPrescriptionId);
  const linkedInvoice = invoices.find(i => i.id === selectedJourney?.billingInvoiceId);

  const stages: { stage: CareJourneyStage; label: string; icon: any; role: string; desc: string }[] = [
    { 
      stage: 'RECEPTION_REGISTRATION', 
      label: '1. Reception Desk', 
      icon: UserCheck, 
      role: 'Receptionist',
      desc: 'Patient registered & booked with Specialist'
    },
    { 
      stage: 'SPECIALIST_CONSULTATION', 
      label: '2. Specialist Consult', 
      icon: Stethoscope, 
      role: 'Consulting Doctor',
      desc: 'Initial exam & referral to Lab with clinical notes'
    },
    { 
      stage: 'LAB_TESTS_ORDERED', 
      label: '3. Diagnostic Lab', 
      icon: FlaskConical, 
      role: 'Lab Technician',
      desc: 'Specimen tested & findings sent to Specialist'
    },
    { 
      stage: 'LAB_FINDINGS_RECEIVED', 
      label: '4. Findings Received', 
      icon: CheckCircle2, 
      role: 'Consulting Doctor',
      desc: 'Specialist reviews verified medical findings'
    },
    { 
      stage: 'DIAGNOSIS_AND_REPORT_PRINTED', 
      label: '5. Dual-Report Print', 
      icon: Printer, 
      role: 'Specialist / Archive',
      desc: 'Physical copy stored in archive, 1 copy handed to patient'
    },
    { 
      stage: 'PHARMACY_PRESCRIBED', 
      label: '6. Central Pharmacy', 
      icon: Pill, 
      role: 'Clinical Pharmacist',
      desc: 'Camera BCMA check & medication dispensing'
    },
    { 
      stage: 'CASHIER_BILLING_PENDING', 
      label: '7. Cashier Desk', 
      icon: CreditCard, 
      role: 'Billing Cashier',
      desc: 'Itemized consultation + lab + drug settlement'
    },
    { 
      stage: 'CLEARED_OUTPATIENT', 
      label: '8. Same-Day Cleared', 
      icon: ShieldCheck, 
      role: 'Cleared Outpatient',
      desc: 'Official same-day outpatient discharge clearance'
    }
  ];

  const getStageIndex = (st: CareJourneyStage) => stages.findIndex(s => s.stage === st);
  const currentStageIndex = selectedJourney ? getStageIndex(selectedJourney.currentStage) : 0;

  // Handlers for sequential stage transitions
  const handleRegisterNewPatient = () => {
    if (!newPatientName) return;
    const { journey } = registerPatientAndBookSpecialist({
      name: newPatientName,
      age: parseInt(newPatientAge) || 40,
      gender: newPatientGender,
      specialistName: newPatientSpecialist,
      specialty: newPatientSpecialty,
      reasonForVisit: newPatientReason,
      appointmentTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
    setSelectedJourneyId(journey.id);
    setActiveTab('interactive_stepper');
    setNewPatientName('');
  };

  const handleStepOrderLabTests = () => {
    if (!selectedJourney) return;
    const tests = availableLabTests.filter(t => selectedLabTestCodes.includes(t.code));
    orderSpecialistLabTests(
      selectedJourney.patientId,
      tests,
      `Specialist evaluation for ${selectedJourney.specialistDoctorName} consultation. Clinical check for suspected pathology.`
    );
  };

  const handleStepSendFindings = () => {
    if (!linkedLabOrder) return;
    sendLabResultsToSpecialist(linkedLabOrder.id);
  };

  const handleStepDiagnosisAndPrint = () => {
    if (!selectedJourney) return;
    const report = completeDiagnosisAndPrintReport(
      selectedJourney.patientId,
      diagnosisText,
      prescribedMedsList,
      'Maintain low-sodium diet, record BP log twice daily, follow-up in clinic in 14 days.'
    );
    setActiveReportData(report);
    setIsPrintModalOpen(true);
  };

  const handleStepDispensePharmacy = () => {
    if (!linkedRx) return;
    dispensePrescription(linkedRx.id);
  };

  const handleStepClearAtCashier = () => {
    if (!selectedJourney) return;
    clearOutpatientAtCashier(selectedJourney.patientId, paymentMethod);
  };

  return (
    <div id="outpatient-workflow-view" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-100 text-blue-700 rounded-xl border border-blue-200">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              Outpatient Clinical Care Journey
              <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full border border-emerald-200">
                Closed-Loop Hospital Workflow
              </span>
            </h1>
            <p className="text-xs text-slate-500">
              Reception → Specialist → Lab Tests → Specialist Diagnosis (Dual Print & Physical Archive) → Pharmacy BCMA → Cashier Same-Day Clearance.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('new_walkin')}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Register Walk-in Outpatient
          </button>
        </div>
      </div>

      {/* Workflow Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('pipeline')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'pipeline'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          Active Patient Pipeline ({careJourneys.length})
        </button>

        <button
          onClick={() => setActiveTab('interactive_stepper')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'interactive_stepper'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Play className="w-4 h-4 text-emerald-400" />
          Live Workflow Simulation & Execution
        </button>

        <button
          onClick={() => setActiveTab('new_walkin')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'new_walkin'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          Reception Desk Registration
        </button>
      </div>

      {/* ================= VIEW 1: ACTIVE PATIENT PIPELINE ================= */}
      {activeTab === 'pipeline' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {careJourneys.map((journey, jIdx) => {
              const stIdx = getStageIndex(journey.currentStage);
              const pat = patients.find(p => p.id === journey.patientId);
              const journeyKey = journey.id || journey.patientId || `journey-${jIdx}`;
              return (
                <div
                  key={journeyKey}
                  onClick={() => {
                    setSelectedJourneyId(journey.id || journey.patientId);
                    setActiveTab('interactive_stepper');
                  }}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md hover:border-blue-300 transition-all cursor-pointer space-y-4"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{journey.patientName}</h3>
                      <p className="text-xs font-mono text-slate-500">{journey.patientMrn}</p>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      journey.isClearedOnSameDay ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {journey.isClearedOnSameDay ? 'CLEARED SAME-DAY' : `STEP ${stIdx + 1} OF 8`}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1">
                    <p className="text-slate-600">
                      <span className="font-semibold text-slate-800">Specialist:</span> {journey.specialistDoctorName}
                    </p>
                    <p className="text-slate-500 text-[11px]">
                      {journey.specialistDepartment} • Reason: {journey.reasonForVisit}
                    </p>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-semibold text-slate-700">
                        Current: {journey.currentStage.replace(/_/g, ' ')}
                      </span>
                      <span className="font-mono text-slate-500 font-bold">
                        {Math.round(((stIdx + 1) / 8) * 100)}%
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${
                          journey.isClearedOnSameDay ? 'bg-emerald-500' : 'bg-blue-600'
                        }`}
                        style={{ width: `${((stIdx + 1) / 8) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs text-blue-600 font-semibold">
                    <span>View & Advance Step</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= VIEW 2: INTERACTIVE STEPPER & SIMULATION ================= */}
      {activeTab === 'interactive_stepper' && selectedJourney && (
        <div className="space-y-6">
          
          {/* Patient Selector Dropdown */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white font-bold flex items-center justify-center text-sm">
                {selectedJourney.patientName.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  Active Care Plan: {selectedJourney.patientName}
                  <span className="text-xs font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded border">
                    {selectedJourney.patientMrn}
                  </span>
                </h2>
                <p className="text-xs text-slate-500">
                  Doctor: <span className="font-semibold text-slate-800">{selectedJourney.specialistDoctorName}</span> ({selectedJourney.specialistDepartment})
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedJourney.id || selectedJourney.patientId}
                onChange={(e) => setSelectedJourneyId(e.target.value)}
                className="text-xs font-medium px-3 py-2 border border-slate-300 rounded-lg bg-slate-50"
              >
                {careJourneys.map((j, jIdx) => (
                  <option key={j.id || j.patientId || `opt-${jIdx}`} value={j.id || j.patientId}>
                    {j.patientName} ({j.currentStage.replace(/_/g, ' ')})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 8-Stage Visual Timeline Stepper */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm overflow-x-auto">
            <div className="flex items-center justify-between min-w-[760px] relative">
              
              {/* Connecting line behind steps */}
              <div className="absolute top-5 left-8 right-8 h-1 bg-slate-200 z-0" />
              <div 
                className="absolute top-5 left-8 h-1 bg-emerald-500 z-0 transition-all duration-500"
                style={{ width: `${(currentStageIndex / (stages.length - 1)) * 100}%` }}
              />

              {stages.map((st, idx) => {
                const isPassed = idx < currentStageIndex;
                const isCurrent = idx === currentStageIndex;
                const IconComponent = st.icon;

                return (
                  <div key={st.stage} className="flex flex-col items-center relative z-10 text-center w-24">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                      isPassed
                        ? 'bg-emerald-500 border-emerald-600 text-white shadow-sm'
                        : isCurrent
                        ? 'bg-blue-600 border-blue-700 text-white ring-4 ring-blue-100 shadow-md scale-110'
                        : 'bg-white border-slate-300 text-slate-400'
                    }`}>
                      {isPassed ? <CheckCircle2 className="w-5 h-5" /> : <IconComponent className="w-5 h-5" />}
                    </div>
                    <p className={`text-[11px] font-bold mt-2 leading-tight ${
                      isCurrent ? 'text-blue-600 font-extrabold' : isPassed ? 'text-slate-800' : 'text-slate-400'
                    }`}>
                      {st.label}
                    </p>
                    <p className="text-[9px] text-slate-400 mt-0.5">{st.role}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Step Dynamic Execution Card */}
          <div className="bg-white rounded-2xl border-2 border-blue-200 p-6 shadow-md space-y-6">
            
            {/* Step Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-50 text-blue-700 rounded-xl border border-blue-200">
                  {React.createElement(stages[currentStageIndex]?.icon || Stethoscope, { className: 'w-6 h-6' })}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Stage {currentStageIndex + 1}: {stages[currentStageIndex]?.label}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Responsible Role: <span className="font-bold text-blue-700">{stages[currentStageIndex]?.role}</span> • {stages[currentStageIndex]?.desc}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs font-mono text-slate-500">Stage Status: </span>
                <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                  {selectedJourney.currentStage.replace(/_/g, ' ')}
                </span>
              </div>
            </div>

            {/* Dynamic Stage Content & Controls */}
            {selectedJourney.currentStage === 'RECEPTION_REGISTRATION' && (
              <div className="space-y-4 text-xs">
                <p className="text-slate-600">
                  The receptionist has logged patient demographics and booked a consultation slot with Specialist <span className="font-bold text-slate-900">{selectedJourney.specialistDoctorName}</span>.
                </p>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-slate-500 block text-[11px]">Appointment Slot:</span>
                      <span className="font-bold text-slate-800">Room #304 • Scheduled Today</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[11px]">Chief Complaint:</span>
                      <span className="font-semibold text-slate-800">{selectedJourney.reasonForVisit}</span>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end pt-2">
                  <button
                    id="btn-advance-to-specialist"
                    onClick={() => handleStepOrderLabTests()}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow flex items-center gap-2"
                  >
                    <span>Patient enters Consultation & Specialist orders Lab Tests</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {selectedJourney.currentStage === 'SPECIALIST_CONSULTATION' && (
              <div className="space-y-4 text-xs">
                <p className="text-slate-700">
                  Specialist <span className="font-bold">{selectedJourney.specialistDoctorName}</span> is examining the patient and ordering required diagnostic tests from the Central Pathology Laboratory:
                </p>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Select Laboratory Diagnostics to Order:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {availableLabTests.map(test => {
                      const isSelected = selectedLabTestCodes.includes(test.code);
                      const testPrice = test.price ?? test.standardPrice ?? 0;
                      return (
                        <label
                          key={test.id || test.code}
                          className={`p-2.5 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                            isSelected ? 'bg-indigo-50 border-indigo-400 font-bold text-indigo-950' : 'bg-slate-50 border-slate-200'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {
                              if (isSelected) {
                                setSelectedLabTestCodes(prev => prev.filter(c => c !== test.code));
                              } else {
                                setSelectedLabTestCodes(prev => [...prev, test.code]);
                              }
                            }}
                            className="rounded text-indigo-600"
                          />
                          <div>
                            <div>{test.name}</div>
                            <div className="text-[10px] text-slate-500 font-normal">{test.category} (${testPrice.toFixed(2)})</div>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div className="flex justify-end pt-3 border-t border-slate-200">
                  <button
                    id="btn-send-patient-to-lab"
                    onClick={handleStepOrderLabTests}
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow flex items-center gap-2"
                  >
                    <FlaskConical className="w-4 h-4" />
                    <span>Send Patient & Clinical Request to Lab for Tests</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {selectedJourney.currentStage === 'LAB_TESTS_ORDERED' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-950 flex items-center gap-1.5">
                      <FlaskConical className="w-4 h-4 text-indigo-700" />
                      Laboratory Order #{linkedLabOrder?.id || 'LAB-PENDING'} in Progress
                    </span>
                    <span className="text-[10px] bg-indigo-200 text-indigo-800 font-bold px-2 py-0.5 rounded">
                      SPECIMEN ANALYZED
                    </span>
                  </div>
                  <p className="text-indigo-900">
                    The medical lab technician has collected specimens and completed automated diagnostic testing.
                  </p>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    id="btn-lab-send-findings"
                    onClick={handleStepSendFindings}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Send Medical Findings Back to Specialist</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {selectedJourney.currentStage === 'LAB_FINDINGS_RECEIVED' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                  <h4 className="font-bold text-emerald-950">
                    Specialist Review of Verified Medical Findings
                  </h4>
                  <p className="text-emerald-900">
                    Lab findings have arrived from Pathology. Specialist is convinced with results and finalizing the clinical diagnosis report & pharmacotherapy.
                  </p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Final Confirmed Diagnosis:</label>
                    <input
                      type="text"
                      value={diagnosisText}
                      onChange={(e) => setDiagnosisText(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 border border-slate-300 rounded-xl bg-white"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Prescribed Pharmacotherapy Regimen:</label>
                    <div className="flex items-center gap-2 mb-2">
                      <input
                        type="text"
                        placeholder="Add medication (e.g. Amoxicillin 500mg TID)"
                        value={medInput}
                        onChange={(e) => setMedInput(e.target.value)}
                        className="flex-1 text-xs px-3 py-1.5 border border-slate-300 rounded-lg"
                      />
                      <button
                        onClick={() => {
                          if (medInput) {
                            setPrescribedMedsList(prev => [...prev, medInput]);
                            setMedInput('');
                          }
                        }}
                        className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-semibold"
                      >
                        Add
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {prescribedMedsList.map((m, i) => (
                        <span key={`med-prescribed-${i}-${m}`} className="bg-indigo-50 border border-indigo-200 text-indigo-900 font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5">
                          ✓ {m}
                          <button onClick={() => setPrescribedMedsList(prev => prev.filter((_, idx) => idx !== i))} className="text-slate-400 hover:text-rose-600">✕</button>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-3 border-t border-slate-200">
                  <button
                    id="btn-print-diagnosis-dual"
                    onClick={handleStepDiagnosisAndPrint}
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow flex items-center gap-2"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print Dual Report (Archive 1 Copy + Hand 1 Copy to Patient) & Prescribe</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {selectedJourney.currentStage === 'DIAGNOSIS_AND_REPORT_PRINTED' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-950 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-indigo-700" />
                      Physical Report Stored & Patient Copy Handed Out
                    </span>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded">
                      EHR SYNCHRONIZED
                    </span>
                  </div>
                  <p className="text-indigo-900">
                    1 physical copy securely archived in Hospital Medical Vault, 1 copy handed to patient in-person, and records preserved permanently in EMR.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => {
                      if (linkedPatient) {
                        const rep = completeDiagnosisAndPrintReport(linkedPatient.id, diagnosisText, prescribedMedsList);
                        setActiveReportData(rep);
                        setIsPrintModalOpen(true);
                      }
                    }}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold flex items-center gap-1.5"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Re-open Dual-Copy Print Preview
                  </button>

                  <button
                    id="btn-move-to-pharmacy"
                    onClick={() => {
                      if (linkedRx) {
                        dispensePrescription(linkedRx.id);
                      }
                    }}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow flex items-center gap-2"
                  >
                    <Pill className="w-4 h-4" />
                    <span>Patient Moves to Pharmacy (Optical BCMA Verification & Dispensing)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {selectedJourney.currentStage === 'PHARMACY_PRESCRIBED' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                      <Pill className="w-4 h-4 text-emerald-700" />
                      Prescription Dispensed & Verified via Optical BCMA
                    </span>
                    <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded">
                      5-RIGHTS CHECKED
                    </span>
                  </div>
                  <p className="text-emerald-900">
                    Pharmacist verified medication barcodes against electronic prescription. Medications handed over to patient. Pharmacy bill automatically posted to cashier.
                  </p>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    id="btn-move-to-cashier"
                    onClick={() => handleStepClearAtCashier()}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow flex items-center gap-2"
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>Proceed to Cashier for Final Settlement & Same-Day Clearance</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {selectedJourney.currentStage === 'CASHIER_BILLING_PENDING' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl space-y-2">
                  <h4 className="font-bold text-blue-950">
                    Final Cashier Itemized Settlement Desk
                  </h4>
                  <p className="text-blue-900">
                    Consolidated ledger includes Specialist Consultation Fee + Pathology Lab Diagnostic Tests + Dispensed Pharmacy Drugs.
                  </p>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Select Payment Settlement Method:</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className="w-full text-xs font-semibold px-3 py-2 border border-slate-300 rounded-xl bg-white"
                  >
                    <option value="Insurance + Co-pay">Insurance Direct Bill + Patient Co-Pay</option>
                    <option value="Credit Card">Credit / Debit Card (Immediate Merchant Clearance)</option>
                    <option value="Cash">Cash Currency Tendered</option>
                  </select>
                </div>

                <div className="flex justify-end pt-3 border-t border-slate-200">
                  <button
                    id="btn-settle-and-clear-outpatient"
                    onClick={handleStepClearAtCashier}
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg flex items-center gap-2"
                  >
                    <ShieldCheck className="w-5 h-5" />
                    <span>Settle Bill & Officially Clear Outpatient on Same Day</span>
                  </button>
                </div>
              </div>
            )}

            {selectedJourney.currentStage === 'CLEARED_OUTPATIENT' && (
              <div className="p-6 bg-emerald-50 border-2 border-emerald-400 rounded-xl space-y-4 text-xs text-emerald-950">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-600 text-white rounded-xl shadow">
                    <ShieldCheck className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-emerald-900">
                      Outpatient Successfully & Safely Cleared on Same Day!
                    </h4>
                    <p className="text-emerald-800">
                      Complete closed-loop clinical cycle accomplished: Registration → Specialist → Lab Findings → Physical/EHR Dual Diagnosis Archive → BCMA Pharmacy → Cashier Settlement.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-white rounded-xl border border-emerald-200 space-y-1 text-slate-800">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                    <div>
                      <span className="text-slate-500 block">Cleared Patient:</span>
                      <span className="font-bold">{selectedJourney.patientName}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">MRN:</span>
                      <span className="font-mono font-bold">{selectedJourney.patientMrn}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Invoice Paid:</span>
                      <span className="font-bold text-emerald-700">Settled (Receipt Issued)</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Archived Copies:</span>
                      <span className="font-bold text-indigo-700">Vault Copy + Patient Copy</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={() => setActiveTab('pipeline')}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow"
                  >
                    Back to All Outpatients
                  </button>
                </div>
              </div>
            )}

            {/* Historical Audit Trail of this Journey */}
            <div className="pt-4 border-t border-slate-200">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                Care Journey Event Audit Log ({(selectedJourney.stageHistory || []).length} milestones)
              </h4>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {(selectedJourney.stageHistory || []).map((hist, idx) => (
                  <div key={`hist-${hist.stage}-${idx}-${hist.timestamp || ''}`} className="p-2 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="font-bold text-slate-800">{hist.stage.replace(/_/g, ' ')}</span>
                      <span className="text-slate-500">• {hist.notes}</span>
                    </div>
                    <div className="text-slate-400 font-mono text-[10px] whitespace-nowrap ml-2">
                      {hist.timestamp} by {hist.actorName} ({hist.actorRole})
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ================= VIEW 3: RECEPTION DESK REGISTRATION ================= */}
      {activeTab === 'new_walkin' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-2xl mx-auto space-y-6">
          <div className="border-b border-slate-200 pb-3 flex items-center gap-2.5">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-xl">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Front Reception: New Patient Registration & Specialist Booking
              </h2>
              <p className="text-xs text-slate-500">
                Initiate a new closed-loop outpatient care journey
              </p>
            </div>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Full Patient Legal Name</label>
              <input
                type="text"
                placeholder="e.g. Julian Hayes"
                value={newPatientName}
                onChange={(e) => setNewPatientName(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Age</label>
                <input
                  type="number"
                  value={newPatientAge}
                  onChange={(e) => setNewPatientAge(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Gender</label>
                <select
                  value={newPatientGender}
                  onChange={(e) => setNewPatientGender(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl bg-white font-medium"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Specialty Service</label>
                <select
                  value={newPatientSpecialty}
                  onChange={(e) => {
                    const spec = e.target.value;
                    setNewPatientSpecialty(spec);
                    if (spec === 'Cardiology') setNewPatientSpecialist('Dr. Marcus Vance (Cardiologist)');
                    else if (spec === 'Pulmonology') setNewPatientSpecialist('Dr. Evelyn Reed (Pulmonologist)');
                    else if (spec === 'Neurology') setNewPatientSpecialist('Dr. Aris Sterling (Neurologist)');
                    else setNewPatientSpecialist('Dr. Sarah Lin (Internist)');
                  }}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl bg-white font-medium"
                >
                  <option value="Cardiology">Cardiology</option>
                  <option value="Pulmonology">Pulmonology</option>
                  <option value="Neurology">Neurology</option>
                  <option value="Internal Medicine">Internal Medicine</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Booked Specialist Physician</label>
                <input
                  type="text"
                  value={newPatientSpecialist}
                  onChange={(e) => setNewPatientSpecialist(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-bold text-slate-700">Reason for Visit & Triage Symptoms</label>
                <button
                  type="button"
                  id="btn-auto-triage-reason"
                  disabled={isTriageAnalyzing || !newPatientReason.trim()}
                  onClick={async () => {
                    if (!newPatientReason.trim()) return;
                    setIsTriageAnalyzing(true);
                    try {
                      const assessment = await performTriageAnalysis({
                        patientName: newPatientName.trim() || 'Walk-in Outpatient',
                        patientAge: Number(newPatientAge) || 45,
                        patientGender: newPatientGender,
                        chiefComplaint: newPatientReason.trim(),
                        symptomDuration: 'Presenting on arrival'
                      });
                      setTriageSuggestion(assessment);
                      if (assessment.recommendedDepartment) {
                        if (assessment.recommendedDepartment.toLowerCase().includes('cardio')) {
                          setNewPatientSpecialty('Cardiology');
                          setNewPatientSpecialist(assessment.recommendedSpecialistName || 'Dr. Marcus Vance (Cardiologist)');
                        } else if (assessment.recommendedDepartment.toLowerCase().includes('pulmon') || assessment.recommendedDepartment.toLowerCase().includes('respirat')) {
                          setNewPatientSpecialty('Pulmonology');
                          setNewPatientSpecialist(assessment.recommendedSpecialistName || 'Dr. Evelyn Reed (Pulmonologist)');
                        } else if (assessment.recommendedDepartment.toLowerCase().includes('neuro')) {
                          setNewPatientSpecialty('Neurology');
                          setNewPatientSpecialist(assessment.recommendedSpecialistName || 'Dr. Aris Sterling (Neurologist)');
                        } else {
                          setNewPatientSpecialty('Internal Medicine');
                          setNewPatientSpecialist(assessment.recommendedSpecialistName || 'Dr. Sarah Lin (Internist)');
                        }
                      }
                    } catch (err) {
                      console.error('Auto triage error:', err);
                    } finally {
                      setIsTriageAnalyzing(false);
                    }
                  }}
                  className="text-[11px] text-teal-700 hover:text-teal-900 bg-teal-50 hover:bg-teal-100 px-2.5 py-1 rounded-lg border border-teal-200 font-bold flex items-center gap-1 transition"
                >
                  {isTriageAnalyzing ? (
                    <>
                      <RefreshCw className="w-3 h-3 animate-spin text-teal-600" />
                      Analyzing ICD-10...
                    </>
                  ) : (
                    <>
                      <BrainCircuit className="w-3.5 h-3.5 text-teal-600" />
                      Auto-Triage & Suggest Specialist (ICD-10)
                    </>
                  )}
                </button>
              </div>
              <textarea
                rows={3}
                placeholder="Describe presenting complaint and reasons for specialist consult..."
                value={newPatientReason}
                onChange={(e) => setNewPatientReason(e.target.value)}
                className="w-full text-xs p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* AI Triage Recommendation Alert Card */}
            {triageSuggestion && (
              <div className="p-4 bg-teal-50/80 border border-teal-200 rounded-2xl space-y-3 animate-in fade-in slide-in-from-top-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <BrainCircuit className="w-4 h-4 text-teal-700" />
                    <span className="text-xs font-black text-teal-950 uppercase tracking-wider">
                      AI Triage Recommendation
                    </span>
                  </div>
                  <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-teal-200 text-teal-900">
                    {triageSuggestion.acuityLevel.replace(/ESI_\d_/, '')}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-2.5 bg-white rounded-xl border border-teal-100 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 block">Primary ICD-10 Code</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="font-mono font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded text-[11px]">
                        {triageSuggestion.primaryIcd10.code}
                      </span>
                      <span className="font-bold text-slate-800 text-[11px] truncate">
                        {triageSuggestion.primaryIcd10.name}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 line-clamp-2">
                      {triageSuggestion.primaryIcd10.clinicalRationale}
                    </p>
                  </div>

                  <div className="p-2.5 bg-white rounded-xl border border-teal-100 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 block">Assigned Specialty & Doctor</span>
                    <p className="font-bold text-teal-900 text-xs">
                      {triageSuggestion.recommendedDepartment}
                    </p>
                    <p className="text-[11px] text-slate-600">
                      {triageSuggestion.recommendedSpecialistName} ({triageSuggestion.recommendedSpecialistRole})
                    </p>
                  </div>
                </div>

                {triageSuggestion.redFlags && triageSuggestion.redFlags.length > 0 && (
                  <div className="p-2 bg-red-50 rounded-lg border border-red-100 flex items-start gap-1.5 text-[11px] text-red-900">
                    <ShieldAlert className="w-3.5 h-3.5 text-red-600 shrink-0 mt-0.5" />
                    <span><strong className="font-bold">Red Flags:</strong> {triageSuggestion.redFlags.join(', ')}</span>
                  </div>
                )}
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <button
                onClick={() => setActiveTab('pipeline')}
                className="px-4 py-2 text-slate-600 font-semibold hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                id="btn-submit-walkin-registration"
                disabled={!newPatientName}
                onClick={handleRegisterNewPatient}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold rounded-xl shadow flex items-center gap-2"
              >
                <UserCheck className="w-4 h-4" />
                Register & Book with Specialist
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dual Report Printable Modal */}
      <DiagnosisPhysicalReportModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        report={activeReportData}
        patient={linkedPatient || null}
      />

      {/* BCMA Camera Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isBcmaScannerOpen}
        onClose={() => setIsBcmaScannerOpen(false)}
        targetPatientId={selectedJourney?.patientId}
      />

    </div>
  );
};
