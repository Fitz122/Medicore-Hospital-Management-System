import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  CameraOff, 
  Scan, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  RefreshCw, 
  ShieldCheck, 
  Pill, 
  User, 
  Info,
  Sparkles,
  Barcode as BarcodeIcon,
  Volume2
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { Patient, MedicationItem } from '../../types';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetPatientId?: string;
  targetMedicationId?: string;
  onScanComplete?: (result: { success: boolean; patientMrn: string; medBarcode: string; message: string }) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  targetPatientId,
  targetMedicationId,
  onScanComplete
}) => {
  const { patients, verifyMedicationBarcodeAdministration, selectedPatient } = useHospital();
  const { currentUser } = useAuth();

  const [activeTab, setActiveTab] = useState<'camera' | 'manual' | 'presets'>('camera');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

  const [patientBarcodeInput, setPatientBarcodeInput] = useState<string>('');
  const [medicationBarcodeInput, setMedicationBarcodeInput] = useState<string>('');
  const [verificationResult, setVerificationResult] = useState<{
    success: boolean;
    message: string;
    alerts: string[];
    timestamp?: string;
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Prepopulate if target patient provided
  useEffect(() => {
    if (targetPatientId) {
      const p = patients.find(pat => pat.id === targetPatientId);
      if (p) setPatientBarcodeInput(p.mrn);
    } else if (selectedPatient) {
      setPatientBarcodeInput(selectedPatient.mrn);
    }
  }, [targetPatientId, selectedPatient, patients]);

  // Start / stop camera stream
  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab, facingMode]);

  const startCamera = async () => {
    setCameraError(null);
    setIsScanning(true);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: facingMode,
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        });
        setCameraStream(stream);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(e => console.warn('Video play error:', e));
        }
      } else {
        setCameraError('Camera access not supported on this browser or environment.');
      }
    } catch (err: any) {
      console.warn('Camera stream initialisation failed:', err);
      setCameraError('Camera unavailable or permission denied. You can use manual input or test presets.');
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setIsScanning(false);
  };

  const toggleCameraFacing = () => {
    stopCamera();
    setFacingMode(prev => (prev === 'environment' ? 'user' : 'environment'));
  };

  const handleExecuteVerification = (pBarcode: string, mBarcode: string) => {
    const res = verifyMedicationBarcodeAdministration(
      pBarcode,
      mBarcode,
      targetPatientId,
      targetMedicationId
    );

    setVerificationResult({
      success: res.success,
      message: res.message,
      alerts: res.alerts,
      timestamp: new Date().toLocaleTimeString()
    });

    if (onScanComplete) {
      onScanComplete({
        success: res.success,
        patientMrn: pBarcode,
        medBarcode: mBarcode,
        message: res.message
      });
    }
  };

  const handleSimulatedScan = (samplePatientMrn: string, sampleMedBarcode: string) => {
    setPatientBarcodeInput(samplePatientMrn);
    setMedicationBarcodeInput(sampleMedBarcode);
    handleExecuteVerification(samplePatientMrn, sampleMedBarcode);
  };

  if (!isOpen) return null;

  return (
    <div id="barcode-scanner-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div id="barcode-scanner-modal-card" className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/30">
              <Scan className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                BCMA Camera Barcode Scanner
                <span className="text-[10px] uppercase font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                  5-Rights Safety
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Verify Patient Wristband (MRN) against Medication Packaging (NDC / Barcode)
              </p>
            </div>
          </div>
          <button
            id="btn-close-scanner-modal"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="bg-slate-100 border-b border-slate-200 px-6 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <button
              id="tab-scanner-camera"
              onClick={() => setActiveTab('camera')}
              className={`px-3 py-1.5 font-semibold rounded-lg flex items-center gap-1.5 transition-all ${
                activeTab === 'camera' 
                  ? 'bg-white text-emerald-700 shadow-sm border border-slate-200' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              Live Device Camera
            </button>
            <button
              id="tab-scanner-manual"
              onClick={() => setActiveTab('manual')}
              className={`px-3 py-1.5 font-semibold rounded-lg flex items-center gap-1.5 transition-all ${
                activeTab === 'manual' 
                  ? 'bg-white text-emerald-700 shadow-sm border border-slate-200' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarcodeIcon className="w-3.5 h-3.5" />
              Manual Key-In
            </button>
            <button
              id="tab-scanner-presets"
              onClick={() => setActiveTab('presets')}
              className={`px-3 py-1.5 font-semibold rounded-lg flex items-center gap-1.5 transition-all ${
                activeTab === 'presets' 
                  ? 'bg-white text-emerald-700 shadow-sm border border-slate-200' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              Clinical Test Barcodes
            </button>
          </div>
          {activeTab === 'camera' && cameraStream && (
            <button
              id="btn-toggle-camera-facing"
              onClick={toggleCameraFacing}
              className="px-2.5 py-1 text-slate-600 bg-white border border-slate-200 rounded-md hover:bg-slate-50 flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              Flip Camera
            </button>
          )}
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          {activeTab === 'camera' && (
            <div className="space-y-4">
              {/* Video Viewport with Targeting Reticle and Laser Animation */}
              <div className="relative w-full h-64 bg-slate-950 rounded-xl overflow-hidden border-2 border-slate-800 flex items-center justify-center">
                {cameraStream ? (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                    {/* Targeting Reticle */}
                    <div className="absolute inset-8 border-2 border-emerald-400/80 rounded-lg pointer-events-none flex flex-col justify-between p-2">
                      <div className="flex justify-between">
                        <div className="w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
                        <div className="w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
                      </div>
                      {/* Laser Barcode Sweep Animation */}
                      <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_rgba(52,211,153,1)] animate-pulse" />
                      <div className="flex justify-between">
                        <div className="w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
                        <div className="w-4 h-4 border-b-2 border-r-2 border-emerald-400" />
                      </div>
                    </div>
                    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-slate-900/80 backdrop-blur text-[11px] text-emerald-300 px-3 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1.5">
                      <Scan className="w-3 h-3 animate-spin" />
                      Align Barcode in viewfinder
                    </div>
                  </>
                ) : (
                  <div className="text-center p-6 text-slate-400 space-y-3">
                    <div className="w-12 h-12 rounded-full bg-slate-800/80 text-slate-400 flex items-center justify-center mx-auto">
                      <CameraOff className="w-6 h-6" />
                    </div>
                    <p className="text-sm font-medium text-slate-300">
                      {cameraError || 'Camera initializing or stream paused.'}
                    </p>
                    <button
                      id="btn-retry-camera"
                      onClick={startCamera}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow transition-colors inline-flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Activate Camera Stream
                    </button>
                  </div>
                )}
              </div>

              {/* Barcode Inputs for Triggering Scan Match */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-blue-600" />
                    1. Patient Wristband Barcode (MRN)
                  </label>
                  <input
                    id="input-patient-barcode"
                    type="text"
                    value={patientBarcodeInput}
                    onChange={(e) => setPatientBarcodeInput(e.target.value)}
                    placeholder="e.g. MC-2026-98124"
                    className="w-full text-xs font-mono px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                    <Pill className="w-3.5 h-3.5 text-emerald-600" />
                    2. Medication Package Barcode (NDC)
                  </label>
                  <input
                    id="input-medication-barcode"
                    type="text"
                    value={medicationBarcodeInput}
                    onChange={(e) => setMedicationBarcodeInput(e.target.value)}
                    placeholder="e.g. 0378-0145-01"
                    className="w-full text-xs font-mono px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'manual' && (
            <div className="space-y-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-800 flex items-start gap-2">
                <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p>
                  Manual mode allows handheld wireless wedge scanners or direct key entry for facilities operating without device webcams.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Patient Medical Record Number (MRN)
                  </label>
                  <input
                    id="manual-input-mrn"
                    type="text"
                    value={patientBarcodeInput}
                    onChange={(e) => setPatientBarcodeInput(e.target.value)}
                    placeholder="Scan or type patient MRN..."
                    className="w-full text-sm font-mono px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Medication Barcode / NDC Identifier
                  </label>
                  <input
                    id="manual-input-ndc"
                    type="text"
                    value={medicationBarcodeInput}
                    onChange={(e) => setMedicationBarcodeInput(e.target.value)}
                    placeholder="Scan or type medication NDC/barcode..."
                    className="w-full text-sm font-mono px-3.5 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-white"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'presets' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-600 font-medium">
                Click any pre-configured test barcode combination below to immediately simulate scanning against hospital records:
              </p>

              <div className="grid grid-cols-1 gap-2.5 max-h-60 overflow-y-auto pr-1">
                <div 
                  onClick={() => handleSimulatedScan('MC-2026-98124', '0378-0145-01')}
                  className="p-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-emerald-900">Eleanor Vance (MC-2026-98124)</span>
                      <span className="text-[10px] bg-emerald-200 text-emerald-800 px-1.5 py-0.5 rounded font-mono font-semibold">MATCH PASSED</span>
                    </div>
                    <p className="text-xs text-emerald-700 font-mono">Med: Lisinopril 10mg (NDC: 0378-0145-01)</p>
                  </div>
                  <button className="text-xs bg-emerald-600 text-white px-3 py-1.5 rounded-lg font-semibold shadow-sm">
                    Simulate Scan
                  </button>
                </div>

                <div 
                  onClick={() => handleSimulatedScan('MC-2026-98124', '0069-4210-30')}
                  className="p-3 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-amber-900">Eleanor Vance (MC-2026-98124)</span>
                      <span className="text-[10px] bg-amber-200 text-amber-800 px-1.5 py-0.5 rounded font-mono font-semibold">ALLERGY WARNING</span>
                    </div>
                    <p className="text-xs text-amber-700 font-mono">Med: Amoxicillin (Penicillin Allergy Contraindication!)</p>
                  </div>
                  <button className="text-xs bg-amber-600 text-white px-3 py-1.5 rounded-lg font-semibold shadow-sm">
                    Test Contraindication
                  </button>
                </div>

                <div 
                  onClick={() => handleSimulatedScan('MC-2026-77341', '0173-0682-20')}
                  className="p-3 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-blue-900">Marcus Thorne (MC-2026-77341)</span>
                      <span className="text-[10px] bg-blue-200 text-blue-800 px-1.5 py-0.5 rounded font-mono font-semibold">MATCH PASSED</span>
                    </div>
                    <p className="text-xs text-blue-700 font-mono">Med: Albuterol Sulfate Inhaler (NDC: 0173-0682-20)</p>
                  </div>
                  <button className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded-lg font-semibold shadow-sm">
                    Simulate Scan
                  </button>
                </div>

                <div 
                  onClick={() => handleSimulatedScan('MC-2026-98124', '9999-9999-99')}
                  className="p-3 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-rose-900">Unknown Drug Scan</span>
                      <span className="text-[10px] bg-rose-200 text-rose-800 px-1.5 py-0.5 rounded font-mono font-semibold">MISMATCH REJECTION</span>
                    </div>
                    <p className="text-xs text-rose-700 font-mono">Unregistered NDC (9999-9999-99)</p>
                  </div>
                  <button className="text-xs bg-rose-600 text-white px-3 py-1.5 rounded-lg font-semibold shadow-sm">
                    Test Rejection
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Action Trigger Button */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-200">
            <div className="text-xs text-slate-500">
              Staff Operator: <span className="font-semibold text-slate-800">{currentUser.name} ({currentUser.role})</span>
            </div>
            <button
              id="btn-verify-bcma-now"
              disabled={!patientBarcodeInput || !medicationBarcodeInput}
              onClick={() => handleExecuteVerification(patientBarcodeInput, medicationBarcodeInput)}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              Verify 5-Rights & Administer
            </button>
          </div>

          {/* Verification Result Banner */}
          {verificationResult && (
            <div 
              id="verification-result-box"
              className={`p-4 rounded-xl border transition-all ${
                verificationResult.success
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                  : 'bg-rose-50 border-rose-300 text-rose-900'
              }`}
            >
              <div className="flex items-start gap-3">
                {verificationResult.success ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold">
                      {verificationResult.success ? 'BCMA Verification Successful' : 'Safety Alert / Contraindication Detected'}
                    </h4>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {verificationResult.timestamp}
                    </span>
                  </div>
                  <p className="text-xs leading-relaxed">
                    {verificationResult.message}
                  </p>

                  {verificationResult.alerts.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {verificationResult.alerts.map((al, idx) => (
                        <div key={idx} className="text-xs font-semibold text-rose-700 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                          {al}
                        </div>
                      ))}
                    </div>
                  )}

                  {verificationResult.success && (
                    <div className="mt-2 text-[11px] text-emerald-800 font-medium flex items-center gap-1.5 bg-emerald-100/70 px-2.5 py-1 rounded-md">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                      Recorded to patient MAR & immutable HIPAA audit log.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
