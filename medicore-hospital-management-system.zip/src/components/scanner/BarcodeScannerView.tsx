import React, { useState } from 'react';
import { 
  Camera, 
  Scan, 
  ShieldCheck, 
  AlertOctagon, 
  CheckCircle2, 
  Clock, 
  Pill, 
  User, 
  Sparkles, 
  History, 
  FileText,
  Search,
  Filter,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { BarcodeScannerModal } from './BarcodeScannerModal';

export const BarcodeScannerView: React.FC = () => {
  const { 
    patients, 
    marRecords, 
    pharmacyPrescriptions,
    selectedPatient,
    setSelectedPatientId
  } = useHospital();

  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [targetPatientId, setTargetPatientId] = useState<string | undefined>(selectedPatient?.id);
  const [targetMedicationId, setTargetMedicationId] = useState<string | undefined>();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredMarRecords = marRecords.filter(r => 
    r.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.medicationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.patientMrn.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.administeredBy.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPassed = marRecords.filter(r => r.fiveRightsVerified).length;
  const totalWarnings = marRecords.filter(r => !r.fiveRightsVerified).length;

  return (
    <div id="barcode-scanner-view-container" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-100 text-emerald-700 rounded-xl border border-emerald-200">
              <Scan className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                Barcode Medication Administration (BCMA)
                <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full border border-emerald-200">
                  HIPAA & JCAHO Verified
                </span>
              </h1>
              <p className="text-xs text-slate-500">
                Optical device camera barcode verification against patient Electronic Medical Records (EMR).
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            id="btn-open-camera-scanner"
            onClick={() => {
              setTargetPatientId(selectedPatient?.id);
              setIsScannerOpen(true);
            }}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-2"
          >
            <Camera className="w-4 h-4" />
            Launch Camera Scanner
          </button>
        </div>
      </div>

      {/* Safety 5-Rights Banner */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {[
          { num: '1', title: 'Right Patient', desc: 'Wristband MRN match' },
          { num: '2', title: 'Right Drug', desc: 'NDC package scan' },
          { num: '3', title: 'Right Dose', desc: 'Prescribed strength' },
          { num: '4', title: 'Right Route', desc: 'Oral / IV / Top.' },
          { num: '5', title: 'Right Time', desc: 'Schedule adherence' }
        ].map((item, idx) => (
          <div key={idx} className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-bold text-sm flex items-center justify-center shrink-0">
              {item.num}
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">{item.title}</p>
              <p className="text-[11px] text-slate-500">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Real-time metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Verified Administrations</p>
            <p className="text-2xl font-black text-emerald-600 mt-1">{totalPassed}</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Contraindications Intercepted</p>
            <p className="text-2xl font-black text-rose-600 mt-1">{totalWarnings}</p>
          </div>
          <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
            <ShieldAlert className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Active Prescriptions in Pharmacy</p>
            <p className="text-2xl font-black text-blue-600 mt-1">{pharmacyPrescriptions.length}</p>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Pill className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Patient Medication Queue to Scan */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Pill className="w-4 h-4 text-emerald-600" />
              Patient Active Medication Schedules (Pending Administration)
            </h2>
            <p className="text-xs text-slate-500">
              Select a patient and medication to start camera optical verification
            </p>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {patients.map(patient => (
            <div key={patient.id} className="p-4 hover:bg-slate-50/80 transition-colors">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 text-slate-700 font-bold flex items-center justify-center text-sm">
                    {patient.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900">{patient.name}</h3>
                      <span className="text-[11px] font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                        {patient.mrn}
                      </span>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        patient.admissionStatus === 'Inpatient' ? 'bg-blue-100 text-blue-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {patient.admissionStatus}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">
                      Age: {patient.age} • Gender: {patient.gender} • Allergies: <span className="font-semibold text-rose-600">{patient.allergies?.map((a: any) => typeof a === 'string' ? a : a.allergen).join(', ') || 'NKDA'}</span>
                    </p>
                  </div>
                </div>

                <button
                  id={`btn-scan-patient-${patient.id}`}
                  onClick={() => {
                    setTargetPatientId(patient.id);
                    setTargetMedicationId(undefined);
                    setIsScannerOpen(true);
                  }}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 self-start md:self-auto"
                >
                  <Camera className="w-3.5 h-3.5" />
                  Scan Patient Wristband
                </button>
              </div>

              {/* Patient's Prescribed Meds */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 pl-0 md:pl-13">
                {(patient.medications || (patient as any).prescriptions || []).map((med: any) => (
                  <div 
                    key={med.id || med.barcode || med.name} 
                    className="p-3 bg-white rounded-xl border border-slate-200 hover:border-emerald-300 transition-colors flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-bold text-slate-800">{med.name} {med.dosage}</p>
                      <p className="text-[11px] text-slate-500">{med.frequency} • {med.route}</p>
                      <p className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded inline-block mt-1">
                        Barcode: {med.barcode || 'N/A'}
                      </p>
                    </div>
                    <button
                      id={`btn-scan-med-${med.id}`}
                      onClick={() => {
                        setTargetPatientId(patient.id);
                        setTargetMedicationId(med.id);
                        setIsScannerOpen(true);
                      }}
                      className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg border border-emerald-200 transition-colors"
                      title="Verify this medication with camera"
                    >
                      <Scan className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Medication Administration Record (MAR) History */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Medication Administration Record (eMAR) Audit History
              </h2>
              <p className="text-xs text-slate-500">
                Full cryptographic and barcode event log of administered doses.
              </p>
            </div>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search eMAR records..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Patient (MRN)</th>
                <th className="py-3 px-4">Medication & Dose</th>
                <th className="py-3 px-4">Administered By</th>
                <th className="py-3 px-4">Status & 5-Rights</th>
                <th className="py-3 px-4">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredMarRecords.map(record => (
                <tr key={record.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono text-slate-500 whitespace-nowrap">
                    {record.timestamp}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-slate-900">{record.patientName}</div>
                    <div className="font-mono text-[10px] text-slate-500">{record.patientMrn}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{record.medicationName}</div>
                    <div className="text-[11px] text-slate-500">{record.dose} • {record.route}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-slate-800">{record.administeredBy}</div>
                    <div className="text-[10px] text-slate-500">{record.nurseRole}</div>
                  </td>
                  <td className="py-3 px-4">
                    {record.fiveRightsVerified ? (
                      <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full text-[10px]">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        5-Rights Verified
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-800 font-semibold px-2 py-0.5 rounded-full text-[10px]">
                        <AlertOctagon className="w-3 h-3 text-rose-600" />
                        Verification Warning
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                    {record.notes}
                  </td>
                </tr>
              ))}

              {filteredMarRecords.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No eMAR administration records match the current filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        targetPatientId={targetPatientId}
        targetMedicationId={targetMedicationId}
      />
    </div>
  );
};
