import React, { useState } from 'react';
import { Lock, ShieldCheck, KeyRound, Building2, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const SessionLockScreen: React.FC = () => {
  const { currentUser, unlockSession } = useAuth();
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === '1234' || pin === '0000' || pin.length >= 4) {
      unlockSession();
    } else {
      setError('Invalid security PIN. Default bypass PIN is 1234.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900 text-white p-4">
      <div className="max-w-md w-full bg-slate-800/90 rounded-3xl p-8 border border-slate-700 shadow-2xl text-center space-y-6 animate-in fade-in zoom-in duration-200">
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-3xl bg-teal-600/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
            <Lock className="w-8 h-8" />
          </div>
        </div>

        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white">Clinical Terminal Locked</h2>
          <p className="text-xs text-slate-400">
            HIPAA § 164.312(a)(2)(iii) Automatic Inactivity Session Lockout
          </p>
        </div>

        <div className="p-3 bg-slate-700/50 rounded-2xl border border-slate-600/50 flex items-center gap-3 text-left">
          <div className="w-10 h-10 rounded-xl bg-teal-700 text-white flex items-center justify-center font-bold text-sm">
            {currentUser.name.charAt(0)}
          </div>
          <div>
            <p className="font-bold text-sm text-white">{currentUser.name}</p>
            <p className="text-[11px] text-teal-400 font-medium">{currentUser.role} • {currentUser.department}</p>
          </div>
        </div>

        <form onSubmit={handleUnlock} className="space-y-4 text-xs">
          {error && (
            <p className="text-red-400 text-xs font-semibold">{error}</p>
          )}

          <div>
            <label className="block text-slate-300 font-bold mb-1.5 text-left">
              Enter 4-Digit Security PIN / Password:
            </label>
            <input
              type="password"
              maxLength={6}
              autoFocus
              placeholder="••••"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full text-center text-xl tracking-widest p-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-hidden focus:ring-2 focus:ring-teal-500 font-mono"
            />
            <span className="text-[10px] text-slate-400 mt-1 block">
              (Demo PIN: <strong className="text-teal-300">1234</strong>)
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-2xl text-xs transition shadow-md shadow-teal-600/20 flex items-center justify-center gap-2"
          >
            <KeyRound className="w-4 h-4" />
            Unlock Session & Resume EHR
          </button>
        </form>

        <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400 pt-2 border-t border-slate-700/60">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Encrypted Session State Preserved</span>
        </div>
      </div>
    </div>
  );
};
