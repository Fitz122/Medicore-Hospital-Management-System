import React, { useState } from 'react';
import { ShieldCheck, Lock, KeyRound, Smartphone, AlertTriangle, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useHospital } from '../../context/HospitalContext';

export const MfaModal: React.FC = () => {
  const { isMfaModalOpen, closeMfaModal, verifyMfa, currentUser } = useAuth();
  const { logAuditAction } = useHospital();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [authMethod, setAuthMethod] = useState<'app' | 'sms' | 'biometric'>('app');

  if (!isMfaModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length < 4) {
      setError('Please enter a valid 6-digit or security code.');
      return;
    }

    const success = verifyMfa(code);
    if (success) {
      logAuditAction('MFA_AUTHENTICATED', `User ${currentUser.name} passed Multi-Factor Authentication challenge via ${authMethod.toUpperCase()}`);
      setCode('');
      setError('');
    } else {
      setError('Invalid code. Please try again.');
    }
  };

  const handleSimulateQuickCode = () => {
    const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
    setCode(randomCode);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-150">
        <div className="bg-gradient-to-r from-teal-700 to-cyan-800 p-6 text-white relative">
          <button 
            onClick={closeMfaModal} 
            className="absolute top-4 right-4 p-1.5 text-teal-100 hover:text-white hover:bg-white/10 rounded-lg transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-xl backdrop-blur-xs">
              <ShieldCheck className="w-7 h-7 text-teal-200" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">Two-Factor Authentication</h3>
              <p className="text-xs text-teal-100">HIPAA Security Rule § 164.312(d)</p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-5">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <p className="text-slate-500">Authenticated Account:</p>
              <p className="font-semibold text-slate-800">{currentUser.name}</p>
            </div>
            <span className="px-2.5 py-1 bg-teal-100 text-teal-800 rounded-full font-medium">
              {currentUser.role}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs">
            <button
              type="button"
              onClick={() => setAuthMethod('app')}
              className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 transition font-medium ${
                authMethod === 'app'
                  ? 'border-teal-600 bg-teal-50 text-teal-800'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>Auth App</span>
            </button>
            <button
              type="button"
              onClick={() => setAuthMethod('sms')}
              className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 transition font-medium ${
                authMethod === 'sms'
                  ? 'border-teal-600 bg-teal-50 text-teal-800'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>SMS Code</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMethod('biometric');
                handleSimulateQuickCode();
              }}
              className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 transition font-medium ${
                authMethod === 'biometric'
                  ? 'border-teal-600 bg-teal-50 text-teal-800'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Lock className="w-4 h-4" />
              <span>Biometric / FIDO</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-xs font-semibold text-slate-700">
                  Verification Passcode:
                </label>
                <button
                  type="button"
                  onClick={handleSimulateQuickCode}
                  className="text-xs text-teal-700 hover:underline font-medium"
                >
                  Generate Test Token
                </button>
              </div>
              <input
                type="text"
                maxLength={6}
                value={code}
                onChange={(e) => {
                  setCode(e.target.value);
                  setError('');
                }}
                placeholder="e.g. 748291"
                className="w-full text-center tracking-widest text-xl font-mono font-bold py-3 px-4 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                autoFocus
              />
              {error && (
                <p className="text-xs text-red-600 mt-1.5 flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {error}
                </p>
              )}
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={closeMfaModal}
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 font-medium text-sm transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-medium text-sm shadow-sm transition flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" />
                Verify & Continue
              </button>
            </div>
          </form>

          <p className="text-center text-[11px] text-slate-400">
            Hardware security keys (YubiKey / WebAuthn) and TOTP authenticator tokens supported.
          </p>
        </div>
      </div>
    </div>
  );
};

export const GlassBreakModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { triggerGlassBreak, currentUser } = useAuth();
  const { logAuditAction } = useHospital();
  const [reason, setReason] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleActivate = () => {
    if (!reason.trim()) {
      setError('A clinical justification is required for emergency audit compliance.');
      return;
    }
    if (!confirmed) {
      setError('You must acknowledge the legal HIPAA audit notification.');
      return;
    }

    triggerGlassBreak(reason);
    logAuditAction(
      'EMERGENCY_GLASS_BREAK',
      `EMERGENCY GLASS-BREAK OVERRIDE: ${reason}`,
      undefined,
      undefined,
      true,
      reason
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-red-950/70 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border-2 border-red-500 overflow-hidden animate-in fade-in zoom-in duration-150">
        <div className="bg-red-600 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 rounded-xl">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Emergency Glass-Break Access</h3>
              <p className="text-xs text-red-100">HIPAA Emergency Override Protocol</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-red-100 hover:text-white hover:bg-white/10 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="p-3.5 bg-red-50 rounded-xl border border-red-200 text-xs text-red-900 space-y-1.5">
            <p className="font-semibold">⚠️ Strict HIPAA Audit Notice</p>
            <p>
              Glass-Break mode temporarily grants elevated access to all EHR records, bypassing standard department restrictions for life-threatening clinical emergencies.
            </p>
            <p className="text-red-700 font-medium">
              Every action taken while in Glass-Break mode is immutably logged with your ID ({currentUser.name}) and audited by the Compliance Committee.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Clinical Justification & Case / Room Details (Required):
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => {
                setReason(e.target.value);
                setError('');
              }}
              placeholder="e.g., Code Blue resuscitation in Trauma Bay 1. Emergency patient unconscious without identifiable proxy; STAT allergy and medication history needed."
              className="w-full text-sm p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-red-500 focus:border-red-500"
            />
          </div>

          <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-700">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
              className="mt-0.5 rounded-sm border-slate-300 text-red-600 focus:ring-red-500"
            />
            <span>
              I certify under penalty of medical licensure and HIPAA federal penalties that this override is strictly required for immediate patient emergency care.
            </span>
          </label>

          {error && (
            <p className="text-xs text-red-600 font-medium">{error}</p>
          )}

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 px-4 rounded-xl border border-slate-200 text-slate-700 font-medium text-sm hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleActivate}
              className="flex-1 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-md transition flex items-center justify-center gap-2"
            >
              <AlertTriangle className="w-4 h-4" />
              Activate Override
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const SessionLockScreen: React.FC = () => {
  const { isSessionLocked, unlockSession, currentUser } = useAuth();
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  if (!isSessionLocked) return null;

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length >= 4) {
      unlockSession();
      setPin('');
      setError('');
    } else {
      setError('Please enter your 4-digit clinical PIN or password.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/90 backdrop-blur-md p-4">
      <div className="bg-white rounded-3xl max-w-sm w-full p-8 text-center shadow-2xl border border-slate-100 space-y-5 animate-in fade-in zoom-in duration-200">
        <div className="w-16 h-16 mx-auto bg-teal-100 text-teal-800 rounded-2xl flex items-center justify-center">
          <Lock className="w-8 h-8" />
        </div>
        
        <div>
          <h2 className="text-xl font-bold text-slate-900">Session Auto-Locked</h2>
          <p className="text-xs text-slate-500 mt-1">HIPAA Idle Inactivity Protection</p>
        </div>

        <div className="flex items-center justify-center gap-3 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
          <img src={currentUser.avatar} alt={currentUser.name} className="w-8 h-8 rounded-full object-cover" />
          <div className="text-left text-xs">
            <p className="font-semibold text-slate-800">{currentUser.name}</p>
            <p className="text-slate-500">{currentUser.role}</p>
          </div>
        </div>

        <form onSubmit={handleUnlock} className="space-y-4">
          <div>
            <input
              type="password"
              placeholder="Enter PIN (e.g. 1234)"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full text-center text-lg tracking-widest font-mono py-2.5 px-4 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-teal-600"
              autoFocus
            />
            {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 bg-teal-700 hover:bg-teal-800 text-white font-semibold rounded-xl text-sm transition shadow-sm"
          >
            Unlock Session
          </button>
        </form>
      </div>
    </div>
  );
};
