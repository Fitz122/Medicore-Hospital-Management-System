import React, { useState } from 'react';
import { ShieldAlert, AlertOctagon, X, Lock, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useHospital } from '../../context/HospitalContext';

interface GlassBreakModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GlassBreakModal: React.FC<GlassBreakModalProps> = ({ isOpen, onClose }) => {
  const { isGlassBreakActive, triggerGlassBreak, revokeGlassBreak, currentUser } = useAuth();
  const { logAuditAction } = useHospital();
  const [reason, setReason] = useState('');
  const [patientIdInput, setPatientIdInput] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('Emergency justification is mandatory under HIPAA § 164.312(a)(2)(ii).');
      return;
    }

    triggerGlassBreak(reason, patientIdInput || undefined);
    logAuditAction(
      'EMERGENCY_GLASS_BREAK',
      `EMERGENCY GLASS-BREAK OVERRIDE: ${reason}`,
      patientIdInput || undefined,
      undefined,
      true,
      reason
    );
    onClose();
  };

  const handleRevoke = () => {
    revokeGlassBreak();
    logAuditAction('EMERGENCY_GLASS_BREAK', 'Emergency glass-break access revoked by staff member.');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-red-500 overflow-hidden animate-in fade-in zoom-in duration-150">
        <div className="bg-red-600 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 rounded-2xl">
              <ShieldAlert className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">Emergency Glass-Break Access</h3>
              <p className="text-xs text-red-100">HIPAA Emergency Override Protocol</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-red-100 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs">
          <div className="p-3.5 bg-red-50 border-l-4 border-red-600 rounded-r-xl text-red-900 leading-relaxed">
            <strong className="font-bold">LEGAL & REGULATORY NOTICE:</strong> Break-Glass mode overrides standard role-based access to facilitate immediate, life-saving clinical interventions. Every document accessed, modified, or exported during this session is flagged and subjected to mandatory HIPAA compliance audit review.
          </div>

          {isGlassBreakActive ? (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-emerald-900 space-y-1">
                <p className="font-bold flex items-center gap-1.5 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Glass-Break Protocol is Currently ACTIVE
                </p>
                <p className="text-[11px] text-emerald-700">
                  Authorized clinician: {currentUser.name} ({currentUser.role})
                </p>
              </div>

              <button
                type="button"
                onClick={handleRevoke}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-xs transition"
              >
                Revoke & End Emergency Override Session
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 bg-red-50 text-red-700 rounded-xl border border-red-200 font-semibold">
                  {error}
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Target Patient MRN / ID (Optional):
                </label>
                <input
                  type="text"
                  placeholder="e.g. MRN-784920 (Leave blank for general emergency triage)"
                  value={patientIdInput}
                  onChange={(e) => setPatientIdInput(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Clinical Justification / Emergency Reason (Required):
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="e.g. Acute trauma patient arrival, unconscious, immediate blood type and allergy verification required for transfusion."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-md shadow-red-600/20"
                >
                  Authorize Break-Glass Override
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
