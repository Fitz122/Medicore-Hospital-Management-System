import React, { useState } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Search, 
  Download, 
  Filter, 
  Lock, 
  FileText, 
  CheckCircle2, 
  AlertCircle,
  Database,
  Calendar
} from 'lucide-react';
import { useHospital } from '../../context/HospitalContext';
import { useAuth } from '../../context/AuthContext';
import { HipaaAuditLog } from '../../types';

export const HipaaAuditTrail: React.FC = () => {
  const { auditLogs } = useHospital();
  const { currentUser } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAction, setFilterAction] = useState<string>('ALL');

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = 
      log.performedBy.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.patientName && log.patientName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesAction = filterAction === 'ALL' || log.action === filterAction;
    return matchesSearch && matchesAction;
  });

  const exportAuditLog = () => {
    const csvHeader = 'Timestamp,User,Role,Action,Patient,Details,IP_Address,Compliance_Seal\n';
    const csvRows = filteredLogs.map(l => 
      `"${l.timestamp}","${l.performedBy}","${l.userRole}","${l.action}","${l.patientName || 'N/A'}","${l.details.replace(/"/g, '""')}","${l.ipAddress}","${l.complianceSeal}"`
    ).join('\n');

    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `HIPAA_Audit_Trail_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* HIPAA Certification Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-3xl border border-slate-800 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base sm:text-lg text-white">
                  HIPAA Security Rule § 164.312(b) Audit Controls & PHI Ledger
                </h2>
                <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-[10px] font-mono font-bold">
                  Immutable
                </span>
              </div>
              <p className="text-xs text-slate-400">
                All electronic protected health information (ePHI) accesses are immutably signed with SHA-256 integrity checksums.
              </p>
            </div>
          </div>

          <button
            onClick={exportAuditLog}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-xs shrink-0"
          >
            <Download className="w-4 h-4" />
            Export Compliance CSV
          </button>
        </div>

        {/* Security Telemetry */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-800 text-xs">
          <div>
            <span className="text-[10px] text-slate-400">Total Audit Events</span>
            <p className="font-mono font-bold text-sm text-white">{auditLogs.length} Logged</p>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Encryption Method</span>
            <p className="font-bold text-teal-300">AES-256-GCM</p>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Session Isolation</span>
            <p className="font-bold text-emerald-400">Zero-Trust RBAC</p>
          </div>
          <div>
            <span className="text-[10px] text-slate-400">Backup Retention</span>
            <p className="font-bold text-slate-300">7 Years Fed Standard</p>
          </div>
        </div>
      </div>

      {/* Logs Table Card */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search by User, Action, Patient, or Details..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-slate-900"
            />
          </div>

          <div className="flex gap-2">
            <select
              value={filterAction}
              onChange={(e) => setFilterAction(e.target.value)}
              className="text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 font-semibold text-slate-700"
            >
              <option value="ALL">All Actions ({auditLogs.length})</option>
              <option value="LOGIN">LOGIN</option>
              <option value="PATIENT_RECORD_VIEW">PATIENT_RECORD_VIEW</option>
              <option value="VITALS_RECORDED">VITALS_RECORDED</option>
              <option value="CLINICAL_NOTE_ADDED">CLINICAL_NOTE_ADDED</option>
              <option value="MEDICATION_PRESCRIBED">MEDICATION_PRESCRIBED</option>
              <option value="LAB_RESULT_ADDED">LAB_RESULT_ADDED</option>
              <option value="BILLING_INVOICE_CREATED">BILLING_INVOICE_CREATED</option>
              <option value="EMERGENCY_BROADCAST_SENT">EMERGENCY_BROADCAST_SENT</option>
              <option value="GLASS_BREAK_TRIGGERED">GLASS_BREAK_TRIGGERED</option>
            </select>
          </div>
        </div>

        {/* Logs Table */}
        <div className="border border-slate-200 rounded-2xl overflow-x-auto text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-100 text-slate-600 text-[10px] uppercase font-bold">
              <tr>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Staff Member & Role</th>
                <th className="p-3">HIPAA Action</th>
                <th className="p-3">Target Patient</th>
                <th className="p-3">Audit Details</th>
                <th className="p-3">Integrity Checksum</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="p-3 font-mono text-slate-600 whitespace-nowrap">{log.timestamp}</td>
                  <td className="p-3">
                    <p className="font-bold text-slate-900">{log.performedBy}</p>
                    <span className="text-[10px] text-slate-500">{log.userRole}</span>
                  </td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                      log.action.includes('GLASS') ? 'bg-red-100 text-red-800 font-extrabold' :
                      log.action.includes('BROADCAST') ? 'bg-amber-100 text-amber-800' :
                      log.action.includes('BILLING') ? 'bg-emerald-100 text-emerald-800' :
                      'bg-slate-200 text-slate-800'
                    }`}>
                      {log.action}
                    </span>
                  </td>
                  <td className="p-3 font-semibold text-slate-900">
                    {log.patientName || <span className="text-slate-400 italic">Facility Wide</span>}
                  </td>
                  <td className="p-3 text-slate-700 max-w-xs">{log.details}</td>
                  <td className="p-3 font-mono text-[10px] text-teal-800 font-bold whitespace-nowrap">
                    {log.complianceSeal}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
