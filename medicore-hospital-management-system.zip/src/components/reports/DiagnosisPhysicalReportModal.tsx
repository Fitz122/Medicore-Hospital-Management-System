import React, { useRef } from 'react';
import { 
  Printer, 
  FileText, 
  CheckCircle2, 
  ShieldCheck, 
  X, 
  Building2, 
  Calendar, 
  User, 
  Stethoscope, 
  FlaskConical, 
  Pill, 
  Award,
  Download,
  Copy
} from 'lucide-react';
import { Patient, DiagnosisPrintReport } from '../../types';

interface DiagnosisPhysicalReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: DiagnosisPrintReport | null;
  patient: Patient | null;
  onConfirmArchivalAndHandover?: () => void;
}

export const DiagnosisPhysicalReportModal: React.FC<DiagnosisPhysicalReportModalProps> = ({
  isOpen,
  onClose,
  report,
  patient,
  onConfirmArchivalAndHandover
}) => {
  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !report || !patient) return null;

  const handlePrint = () => {
    window.print();
    if (onConfirmArchivalAndHandover) {
      onConfirmArchivalAndHandover();
    }
  };

  return (
    <div id="diagnosis-report-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 overflow-y-auto print:p-0 print:bg-white">
      <div id="diagnosis-report-modal-card" className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200 print:shadow-none print:border-none print:max-w-full">
        
        {/* Modal Top Bar (hidden on print) */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-lg border border-indigo-500/30">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Specialist Diagnostic Report & Dual-Copy Print Engine
                <span className="text-[10px] uppercase font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                  Physical Storage + Patient Copy
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                1 copy archived in hospital records archive, 1 copy handed to patient, electronic record persisted in EHR.
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              id="btn-print-dual-report"
              onClick={handlePrint}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow transition-all flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print Dual-Copy (Physical & Patient)
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Area */}
        <div ref={printAreaRef} className="p-8 space-y-8 bg-white max-h-[80vh] overflow-y-auto print:max-h-none print:overflow-visible text-slate-900">
          
          {/* ================= COPY 1: HOSPITAL PHYSICAL ARCHIVE ================= */}
          <div className="border-2 border-slate-900 rounded-2xl p-6 relative space-y-6 bg-slate-50/40 print:border-slate-800 print:break-after-page">
            
            {/* Stamp / Archival Watermark Header */}
            <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-900 text-white rounded-xl">
                  <Building2 className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-lg font-black tracking-tight text-slate-900 uppercase">
                    MediCore University Hospital & Medical Center
                  </h1>
                  <p className="text-xs font-semibold text-slate-600">
                    Department of Specialist Consultations & Outpatient Medicine
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-block bg-slate-900 text-white text-[11px] font-black uppercase px-3 py-1 rounded tracking-wider">
                  COPY 1: HOSPITAL ARCHIVE (PHYSICAL FILE)
                </span>
                <p className="text-[10px] font-mono text-slate-500 mt-1">
                  Report ID: {report.reportId} • Date: {report.date}
                </p>
              </div>
            </div>

            {/* Patient & Specialist Info Header */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-white rounded-xl border border-slate-300 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Patient Name</span>
                <span className="font-bold text-slate-900 text-sm">{report.patientName}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold">MRN / Barcode</span>
                <span className="font-mono font-bold text-slate-900 text-sm">{report.patientMrn}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Attending Specialist</span>
                <span className="font-bold text-slate-900">{report.specialistName}</span>
                <span className="text-[10px] text-slate-500 block">{report.specialty}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Demographics</span>
                <span className="font-medium text-slate-800">Age: {patient.age} • {patient.gender}</span>
                <span className="text-[10px] text-slate-500 block">DOB: {patient.dateOfBirth}</span>
              </div>
            </div>

            {/* Specialist Clinical Findings */}
            <div className="space-y-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                <Stethoscope className="w-4 h-4 text-indigo-700" />
                1. Clinical Examination & Specialist Assessment
              </h3>
              <p className="text-xs text-slate-800 leading-relaxed font-medium bg-white p-3 rounded-xl border border-slate-200">
                {report.clinicalFindings}
              </p>
            </div>

            {/* Diagnostic Lab Findings Summary */}
            <div className="space-y-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                <FlaskConical className="w-4 h-4 text-indigo-700" />
                2. Corroborated Diagnostic Laboratory Findings
              </h3>
              <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs text-slate-800 space-y-1">
                <p className="font-semibold text-indigo-900">{report.labSummary}</p>
                <p className="text-[11px] text-slate-500">
                  Specimen processed in CAP/CLIA Accredited Hospital Central Laboratory.
                </p>
              </div>
            </div>

            {/* Official Diagnosis & Plan */}
            <div className="space-y-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                <Award className="w-4 h-4 text-indigo-700" />
                3. Final Specialist Diagnosis & Prescribed Regimen
              </h3>
              <div className="p-4 bg-indigo-50/70 border border-indigo-300 rounded-xl space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-indigo-950 uppercase">Primary Diagnosis:</span>
                  <span className="text-sm font-black text-indigo-900">{report.diagnosis}</span>
                </div>
                <div className="text-xs text-indigo-900">
                  <span className="font-bold">Prescribed Pharmacotherapy:</span>
                  <ul className="list-disc pl-5 mt-1 space-y-0.5">
                    {(report.prescribedMedications || []).map((med, idx) => (
                      <li key={`report-arch-med-${idx}-${med}`} className="font-semibold">{med}</li>
                    ))}
                  </ul>
                </div>
                <p className="text-[11px] text-indigo-800 pt-1">
                  Follow-up Instructions: {report.followUpInstructions}
                </p>
              </div>
            </div>

            {/* Signatures & Hospital Stamp */}
            <div className="pt-4 border-t-2 border-slate-900 grid grid-cols-2 gap-6 text-xs">
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-500">Attending Specialist Signature</p>
                <div className="mt-4 font-serif text-base italic text-indigo-950 font-bold border-b border-slate-400 pb-1">
                  {report.specialistName}, MD
                </div>
                <p className="text-[10px] text-slate-500 mt-1">License: MD-9912048-TX</p>
              </div>

              <div className="text-right">
                <p className="text-[10px] uppercase font-bold text-slate-500">Physical Vault Custodian</p>
                <div className="mt-4 text-xs font-bold text-slate-900 border-b border-slate-400 pb-1">
                  ARCHIVED IN VAULT #B-04 • EMR REVISION #1
                </div>
                <p className="text-[10px] text-emerald-700 font-bold mt-1">
                  ✓ VERIFIED & STORED IN PHYSICAL RECORD ARCHIVE
                </p>
              </div>
            </div>
          </div>

          {/* ================= COPY 2: PATIENT HANDOUT COPY ================= */}
          <div className="border-2 border-indigo-700 rounded-2xl p-6 relative space-y-6 bg-indigo-50/20 print:border-indigo-800">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b-2 border-indigo-700 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-700 text-white rounded-xl">
                  <Building2 className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-lg font-black tracking-tight text-slate-900 uppercase">
                    MediCore University Hospital
                  </h1>
                  <p className="text-xs font-semibold text-slate-600">
                    Patient Consultation Summary & Prescription Release Handout
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-block bg-indigo-700 text-white text-[11px] font-black uppercase px-3 py-1 rounded tracking-wider">
                  COPY 2: OFFICIAL PATIENT COPY (HAND TO PATIENT)
                </span>
                <p className="text-[10px] font-mono text-slate-500 mt-1">
                  MRN: {report.patientMrn} • Handed: {report.date}
                </p>
              </div>
            </div>

            {/* Quick Patient summary */}
            <div className="p-4 bg-white rounded-xl border border-indigo-200 text-xs space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="font-bold text-slate-900 text-sm">Patient: {report.patientName}</span>
                <span className="text-indigo-800 font-semibold">Specialist: {report.specialistName}</span>
              </div>
              <div className="p-2.5 bg-indigo-50 rounded-lg text-indigo-950 font-bold">
                Diagnosis: {report.diagnosis}
              </div>
              <p className="text-slate-700">
                <span className="font-bold">Summary of Findings:</span> {report.clinicalFindings}
              </p>
              <div className="pt-2 border-t border-slate-200">
                <span className="font-bold text-slate-900 block mb-1">Prescribed Medications to Collect at Pharmacy:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(report.prescribedMedications || []).map((m, i) => (
                    <div key={`report-handout-med-${i}-${m}`} className="p-2 bg-slate-50 rounded-lg border border-slate-200 text-slate-800 font-medium">
                      ✓ {m}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Clearance Instructions */}
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center justify-between">
              <div>
                <p className="font-bold">Outpatient Same-Day Clearance Notice</p>
                <p className="text-[11px] text-emerald-800">
                  Please proceed directly to the Central Pharmacy for medication collection, followed by the Cashier desk for final same-day receipt and clearance.
                </p>
              </div>
              <ShieldCheck className="w-8 h-8 text-emerald-600 shrink-0 ml-3" />
            </div>

            {/* Handover Signoff */}
            <div className="pt-3 border-t border-indigo-300 flex items-center justify-between text-xs text-slate-600">
              <span>Authorized by MediCore Specialist Outpatient Service</span>
              <span className="font-bold text-slate-800">Hospital Copy Stored & Patient Copy Handed In Person</span>
            </div>
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Digital electronic record simultaneously updated in Hospital EMR.</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-xl"
            >
              Close Preview
            </button>
            <button
              onClick={handlePrint}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print & Archive Both Copies
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
