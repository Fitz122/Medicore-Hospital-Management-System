import React from 'react';
import { 
  Printer, 
  Download, 
  X, 
  Building2, 
  ShieldCheck, 
  FileText, 
  User, 
  Calendar, 
  Activity, 
  Stethoscope, 
  Pill, 
  FlaskConical 
} from 'lucide-react';
import { Patient } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useHospital } from '../../context/HospitalContext';
import { printPatientCompleteRecord } from '../../utils/printEngine';

interface ConsultationReportModalProps {
  patient: Patient;
  isOpen: boolean;
  onClose: () => void;
}

export const ConsultationReportModal: React.FC<ConsultationReportModalProps> = ({ patient, isOpen, onClose }) => {
  const { currentUser } = useAuth();
  const { logAuditAction } = useHospital();

  if (!isOpen || !patient) return null;

  const allergies = patient.allergies || [];
  const chronicConditions = patient.chronicConditions || patient.conditions || [];
  const vitals = patient.vitals || [];
  const latestVital = vitals[0];
  const medications = patient.medications || [];
  const labResults = patient.labResults || [];
  const clinicalNotes = patient.clinicalNotes || [];

  const handlePrint = () => {
    logAuditAction('REPORT_EXPORTED', `Printed Physician Consultation & Clinical Summary for ${patient.name} (MRN: ${patient.mrn})`, patient.id, patient.name);
    printPatientCompleteRecord(patient, currentUser);
  };

  const handleDownloadText = () => {
    const reportText = `
================================================================================
                    MEDICORE UNIVERSITY HEALTH SYSTEM
             Comprehensive Physician Consultation & Clinical Summary
                   HIPAA Confirmed & 256-bit Encrypted Record
================================================================================
PATIENT DEMOGRAPHICS:
  Name: ${patient.name}
  MRN: ${patient.mrn}
  DOB: ${patient.dob || patient.dateOfBirth || 'N/A'} (Age: ${patient.age}y / Gender: ${patient.gender})
  Blood Type: ${patient.bloodType || 'N/A'}
  Phone: ${patient.phone || 'N/A'}
  Address: ${patient.address || 'N/A'}
  Primary Insurance: ${patient.insurance?.provider || 'Self-Pay'} (Policy: ${patient.insurance?.policyNumber || 'N/A'})
  Emergency Contact: ${patient.emergencyContact?.name || 'N/A'} (${patient.emergencyContact?.relationship || 'Next of Kin'}) - ${patient.emergencyContact?.phone || 'N/A'}

CURRENT CLINICAL STATUS:
  Ward / Bed: ${patient.assignedWard || 'Outpatient'} - ${patient.assignedBed || 'N/A'}
  Admission Status: ${patient.admissionStatus} (${patient.admissionDate || 'N/A'})

ALLERGIES & ADVERSE REACTIONS:
${allergies.length > 0 ? allergies.map(a => `  - ${typeof a === 'string' ? a : a.allergen} [Severity: ${typeof a === 'string' ? 'RECORDED' : a.severity}] -> Reaction: ${typeof a === 'string' ? 'Reaction on file' : a.reaction}`).join('\n') : '  - No Known Drug Allergies (NKDA)'}

ACTIVE DIAGNOSES & CHRONIC CONDITIONS:
${chronicConditions.length > 0 ? chronicConditions.map(c => `  - ${c}`).join('\n') : '  - General Assessment / Routine Screening'}

LATEST VITAL SIGNS (Recorded: ${latestVital?.recordedAt || 'N/A'} by ${latestVital?.recordedBy || 'N/A'}):
  Blood Pressure: ${latestVital?.bloodPressure || 'N/A'} mmHg
  Heart Rate: ${latestVital?.heartRate || 'N/A'} bpm
  Temperature: ${latestVital?.temperature || 'N/A'} °C
  SpO2: ${latestVital?.spo2 || 'N/A'} %
  Respiratory Rate: ${latestVital?.respiratoryRate || 'N/A'} /min
  BMI: ${latestVital?.bmi || 'N/A'} (Height: ${latestVital?.heightCm || 'N/A'}cm, Weight: ${latestVital?.weightKg || 'N/A'}kg)

ACTIVE PHARMACEUTICAL REGIMEN:
${medications.length > 0 ? medications.map(m => `  - ${m.name} ${m.dosage} (${m.frequency}, ${m.route}) - Prescribed by: ${m.prescribingDoctor}\n    Instructions: ${m.instructions}`).join('\n') : '  - No active medications'}

DIAGNOSTIC LAB FINDINGS:
${labResults.length > 0 ? labResults.map(l => `  - ${l.testName} (${l.date}): ${l.resultValue} ${l.unit} [Ref Range: ${l.referenceRange}] -> Status: ${l.status}`).join('\n') : '  - No diagnostic lab results'}

PHYSICIAN CLINICAL NOTES & IMPRESSIONS:
${clinicalNotes.length > 0 ? clinicalNotes.map(n => `  [${n.date} - ${n.category}] Author: ${n.authorName} (${n.authorRole})\n  ${n.content || n.note || ''}\n  ICD Codes: ${n.icdCodes?.join(', ') || 'N/A'}`).join('\n\n') : '  - No clinical notes recorded'}

================================================================================
Attending Physician Verification:
  Clinician: ${currentUser.name} (${currentUser.role})
  License: ${currentUser.licenseNumber || 'Verified Staff ID'}
  Date of Export: ${new Date().toLocaleString()}
  Audit Hash: SHA256:${Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}
================================================================================
`;

    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Consultation_Report_${patient.mrn}_${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    logAuditAction('REPORT_EXPORTED', `Exported Clinical Summary TXT file for ${patient.name}`, patient.id, patient.name);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in duration-150">
        {/* Modal Action Header (Excluded during print) */}
        <div className="no-print bg-slate-900 text-white p-4 sm:px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-600/30 text-teal-300 rounded-xl">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                Physician Consultation & EHR Export Report
              </h3>
              <p className="text-xs text-slate-400">
                Official Clinical Summary • Prepared for Physician Referrals & Records
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
            >
              <Printer className="w-4 h-4" />
              Print Directly to Printer
            </button>
            <button
              onClick={handleDownloadText}
              className="hidden sm:flex px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              Export Text
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Hospital Document Body */}
        <div className="p-6 sm:p-10 space-y-6 text-slate-900 bg-white" id="printable-report">
          {/* Hospital Letterhead */}
          <div className="flex items-start justify-between border-b-2 border-slate-900 pb-5">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-teal-800 flex items-center justify-center text-white font-bold">
                <Building2 className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  MEDICORE HEALTH SYSTEM
                </h1>
                <p className="text-xs text-slate-600 font-medium">
                  Department of Clinical Affairs & Integrated Health Informatics
                </p>
                <p className="text-[11px] text-slate-500 font-mono">
                  75 Francis Street, Boston, MA 02115 • Direct: +1 (555) 720-4000
                </p>
              </div>
            </div>

            <div className="text-right text-xs">
              <div className="inline-flex items-center gap-1 px-2 py-0.5 bg-teal-50 text-teal-800 border border-teal-200 rounded-md font-bold text-[10px] uppercase">
                <ShieldCheck className="w-3 h-3 text-teal-600" /> HIPAA Certified
              </div>
              <p className="text-slate-500 mt-1">Date: <strong className="text-slate-800">{new Date().toLocaleDateString()}</strong></p>
              <p className="text-slate-500">Document ID: <strong className="font-mono text-slate-800">DOC-CR-{patient.mrn}</strong></p>
            </div>
          </div>

          {/* Patient Bio Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs">
            <div>
              <p className="text-slate-500 font-medium">Patient Full Name:</p>
              <p className="text-sm font-bold text-slate-900">{patient.name}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">Medical Record # (MRN):</p>
              <p className="text-sm font-mono font-bold text-teal-800">{patient.mrn}</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">DOB / Age / Gender:</p>
              <p className="text-sm font-bold text-slate-900">{patient.dob || patient.dateOfBirth || 'N/A'} ({patient.age}y / {patient.gender?.[0] || 'U'})</p>
            </div>
            <div>
              <p className="text-slate-500 font-medium">Blood Type:</p>
              <p className="text-sm font-bold text-rose-700">{patient.bloodType || 'N/A'}</p>
            </div>

            <div className="sm:col-span-2">
              <p className="text-slate-500 font-medium">Primary Health Plan:</p>
              <p className="font-semibold text-slate-900">{patient.insurance?.provider || 'Self-Pay / Private'} (Policy: {patient.insurance?.policyNumber || 'N/A'})</p>
            </div>
            <div className="sm:col-span-2">
              <p className="text-slate-500 font-medium">Current Location / Ward:</p>
              <p className="font-semibold text-slate-900">{patient.assignedWard || 'Outpatient Follow-up'} {patient.assignedBed ? `• ${patient.assignedBed}` : ''}</p>
            </div>
          </div>

          {/* Allergies Alert Banner */}
          <div className="p-3.5 bg-rose-50 border-l-4 border-rose-600 rounded-r-xl">
            <h4 className="text-xs font-bold text-rose-900 uppercase tracking-wider mb-1">
              Allergies & Adverse Drug Sensitivities:
            </h4>
            <div className="flex flex-wrap gap-2">
              {allergies.length > 0 ? (
                allergies.map(a => (
                  <span key={typeof a === 'string' ? a : a.id} className="text-xs px-2.5 py-1 bg-white border border-rose-300 text-rose-800 font-semibold rounded-md">
                    {typeof a === 'string' ? a : `${a.allergen} (${a.reaction} - ${a.severity})`}
                  </span>
                ))
              ) : (
                <span className="text-xs text-slate-600 italic">No Known Drug Allergies (NKDA)</span>
              )}
            </div>
          </div>

          {/* Vitals Biometrics Box */}
          {latestVital && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-teal-700" />
                Latest Vital Signs ({latestVital.recordedAt})
              </h4>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-xs">
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500">Blood Pressure</span>
                  <p className="font-mono font-bold text-sm text-slate-900">{latestVital.bloodPressure}</p>
                  <span className="text-[9px] text-slate-400">mmHg</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500">Heart Rate</span>
                  <p className="font-mono font-bold text-sm text-slate-900">{latestVital.heartRate}</p>
                  <span className="text-[9px] text-slate-400">bpm</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500">Temperature</span>
                  <p className="font-mono font-bold text-sm text-slate-900">{latestVital.temperature}</p>
                  <span className="text-[9px] text-slate-400">°C</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500">Pulse Ox (SpO2)</span>
                  <p className="font-mono font-bold text-sm text-emerald-700">{latestVital.spo2}%</p>
                  <span className="text-[9px] text-slate-400">Room Air</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500">Resp Rate</span>
                  <p className="font-mono font-bold text-sm text-slate-900">{latestVital.respiratoryRate}</p>
                  <span className="text-[9px] text-slate-400">/min</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] text-slate-500">BMI</span>
                  <p className="font-mono font-bold text-sm text-slate-900">{latestVital.bmi}</p>
                  <span className="text-[9px] text-slate-400">{latestVital.weightKg} kg</span>
                </div>
              </div>
            </div>
          )}

          {/* Active Diagnoses & Medications */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                <Stethoscope className="w-4 h-4 text-teal-700" />
                Active Clinical Diagnoses (ICD-10)
              </h4>
              <ul className="text-xs space-y-1">
                {chronicConditions.length > 0 ? (
                  chronicConditions.map((cond, i) => (
                    <li key={i} className="font-semibold text-slate-800 flex items-start gap-1.5">
                      <span className="text-teal-700 font-bold">•</span>
                      <span>{cond}</span>
                    </li>
                  ))
                ) : (
                  <li className="text-slate-500 italic">Routine Medical Assessment</li>
                )}
              </ul>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-indigo-700" />
                Prescribed Pharmaceutical Regimen
              </h4>
              <ul className="text-xs space-y-1.5">
                {medications.length > 0 ? (
                  medications.map((m) => (
                    <li key={m.id} className="text-slate-800">
                      <div className="font-bold text-slate-900">{m.name} — {m.dosage}</div>
                      <div className="text-[11px] text-slate-500">{m.frequency} ({m.route}) • Prescriber: {m.prescribingDoctor}</div>
                    </li>
                  ))
                ) : (
                  <li className="text-slate-500 italic">No active pharmaceuticals</li>
                )}
              </ul>
            </div>
          </div>

          {/* Diagnostic Lab Tests */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <FlaskConical className="w-4 h-4 text-cyan-700" />
              Diagnostic Laboratory Panels
            </h4>
            <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-100 text-slate-600 text-[11px] uppercase">
                  <tr>
                    <th className="p-2.5">Test Name</th>
                    <th className="p-2.5">Date</th>
                    <th className="p-2.5">Result</th>
                    <th className="p-2.5">Reference Range</th>
                    <th className="p-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {labResults.length > 0 ? (
                    labResults.map((lab) => (
                      <tr key={lab.id} className="hover:bg-slate-50">
                        <td className="p-2.5 font-bold text-slate-900">{lab.testName}</td>
                        <td className="p-2.5 text-slate-600">{lab.date}</td>
                        <td className="p-2.5 font-mono font-bold text-slate-900">{lab.resultValue} {lab.unit}</td>
                        <td className="p-2.5 text-slate-500 font-mono">{lab.referenceRange}</td>
                        <td className="p-2.5">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            lab.status === 'NORMAL' ? 'bg-emerald-100 text-emerald-800' :
                            lab.status === 'CRITICAL' ? 'bg-rose-100 text-rose-800 font-extrabold' : 'bg-amber-100 text-amber-800'
                          }`}>
                            ${lab.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} className="p-3 text-center text-slate-400 italic">No laboratory tests on file</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Clinical Progress Notes */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-teal-700" />
              Attending Physician Clinical Notes & Plan
            </h4>
            {clinicalNotes.length > 0 ? (
              clinicalNotes.map((note) => (
                <div key={note.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-500 text-[11px] pb-1 border-b border-slate-200">
                    <span className="font-bold text-slate-800">{note.category} • {note.authorName} ({note.authorRole})</span>
                    <span>{note.date}</span>
                  </div>
                  <p className="text-slate-800 leading-relaxed font-sans">{note.content || note.note || ''}</p>
                  {note.icdCodes && note.icdCodes.length > 0 && (
                    <div className="flex gap-1.5 pt-1">
                      {note.icdCodes.map((code, idx) => (
                        <span key={idx} className="text-[10px] font-mono bg-white px-2 py-0.5 rounded-md border border-slate-300 font-medium">
                          {code}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))
            ) : (
              <p className="text-slate-400 italic text-xs">No clinical notes recorded.</p>
            )}
          </div>

          {/* Physician Signature Block */}
          <div className="pt-8 border-t-2 border-slate-300 grid grid-cols-2 gap-8 text-xs print-break-inside-avoid">
            <div>
              <p className="text-slate-500 mb-6">Attending Physician Electronic Signature:</p>
              <div className="font-mono text-base font-bold text-teal-900 border-b border-slate-900 pb-1">
                /s/ {currentUser.name}, {currentUser.role === 'PHYSICIAN' ? 'MD' : 'Clinical Administrator'}
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                NPI / Medical Lic: {currentUser.licenseNumber || 'MD-MED-889104'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-slate-500 mb-6">HIPAA Security Verification Seal:</p>
              <div className="inline-block p-2 bg-slate-100 rounded-lg border border-slate-300 font-mono text-[9px] text-slate-600 text-left">
                VERIFIED HASH: SHA256:7f83b1657ff1fc53<br/>
                TIMESTAMP: {new Date().toISOString()}<br/>
                VAULT: MEDICORE-CLINICAL-SECURE
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

